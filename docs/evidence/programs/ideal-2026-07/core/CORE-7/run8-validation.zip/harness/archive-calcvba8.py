from pathlib import Path
import hashlib, json, re, subprocess, sys, zipfile
from datetime import datetime, timezone

ROOT = Path(r'C:\Work\DnaCalc\OxVba')
RUNS = Path(r'C:\Work\DnaCalc\codex-runs')
HERE = ROOT / 'docs/evidence/programs/ideal-2026-07/core/CORE-7'
BASELINE = '6d63a3c27afd415a025722492a04deb667c68fbb'

def sha(data):
    return hashlib.sha256(data).hexdigest()

files = {}
def put(path, name):
    path = Path(path)
    assert path.is_file(), path
    assert name not in files, name
    files[name] = path.read_bytes()

# Retain all Rust compilation inputs in the two source trees, plus exact build
# metadata and the Lean/oracle sources. No DNA prediction path is enumerated.
source = set()
for tree in ['crates', 'adapters']:
    for path in (ROOT / tree).rglob('*'):
        if path.is_file() and (path.suffix == '.rs' or path.name == 'Cargo.toml'):
            source.add(path.relative_to(ROOT).as_posix())
source.update(['Cargo.toml', '.cargo/config.toml'])
source.update(p.relative_to(ROOT).as_posix() for p in (ROOT/'formal/lean/OxVba').glob('*.lean'))
source.update([
    'scripts/run-worksheet-errors-oracle.ps1',
    'scripts/run-excel-vba-oracle.ps1',
    'scripts/meta-check.ps1',
    'docs/evidence/programs/ideal-2026-07/windows-x64/WIN-4/worksheet-errors.bas',
    'docs/evidence/programs/ideal-2026-07/core/CORE-7/verify-run8.py',
    'docs/spec/HOSTING_AND_EARLY_BINDING.md',
])
source_hashes = {name:sha((ROOT/name).read_bytes()) for name in sorted(source)}
frozen_path = RUNS/'calcvba8-source-frozen.json'
if '--freeze' in sys.argv:
    frozen_path.write_text(json.dumps({'utc':datetime.now(timezone.utc).isoformat(),
        'source_sha256':source_hashes,'build_inputs_sha256':{'Cargo.lock':sha((ROOT/'Cargo.lock').read_bytes())}},indent=2)+'\n',encoding='utf-8',newline='\n')
    print(f'froze {len(source_hashes)} source files')
    sys.exit(0)
frozen = json.loads(frozen_path.read_text(encoding='utf-8'))
assert frozen['source_sha256'] == source_hashes
assert frozen['build_inputs_sha256']['Cargo.lock'] == sha((ROOT/'Cargo.lock').read_bytes())
put(ROOT/'Cargo.lock', 'build/Cargo.lock')
for name in sorted(source):
    put(ROOT / name, 'source/' + name)
for path in sorted(RUNS.glob('calcvba8-*')):
    if path.is_file():
        put(path, 'raw/' + path.name)
    elif path.name == 'calcvba8-lean':
        for child in sorted(path.rglob('*')):
            if child.is_file():
                put(child, 'raw/' + child.relative_to(RUNS).as_posix())
for run in ['calcvba8-object-inspection', 'calcvba8-owning-oracle', 'calcvba8-final-source', 'calcvba8-final-parameter-source']:
    directory = ROOT / 'artifacts/windows-x64/worksheet-errors' / run
    for child in sorted(directory.rglob('*')):
        if child.is_file():
            put(child, 'raw/' + child.relative_to(ROOT).as_posix())
put(RUNS/'archive-calcvba8.py', 'harness/archive-calcvba8.py')
put(RUNS/'calcvba-report-7.md', 'context/calcvba-report-7.md')
for name in ['SYNTHESIS.md', 'EXCEL_CALC_PROBES.md']:
    put(Path(r'C:\Work\DnaCalc\DnaCalc-cfml\docs\architecture')/name, 'context/'+name)

meta_name = 'raw/calcvba8-meta-validated.log'
meta = files[meta_name].decode('utf-8-sig')
assert '[oxvba] meta check complete' in meta
counts = [tuple(map(int, x)) for x in re.findall(
    r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out', meta)]
assert counts and sum(x[1] for x in counts) == 0
miri = files['raw/calcvba8-miri-final.log'].decode('utf-8-sig')
assert '11 passed; 0 failed' in miri
strict = files['raw/calcvba8-miri-strict-object-only.log'].decode('utf-8-sig')
assert '1 passed; 0 failed' in strict
assert '1 passed; 0 failed' in files['raw/calcvba8-miri-strict-parameters.log'].decode('utf-8-sig')
status = json.loads(files['raw/calcvba8-miri-status.json'].decode('utf-8-sig'))
assert status['default_exit'] == status['strict_object_exit'] == status['strict_parameter_exit'] == 0
assert status['strict_globals_exit'] != 0 and status['strict_globals_credit'] is False
assert 'unsupported operation' in files['raw/calcvba8-miri-strict-frame.log'].decode('utf-8-sig').lower()
for name in ['no-jit', 'wasm', 'truth-final']:
    assert 'raw/calcvba8-' + name + '.log' in files
live_base = 'raw/artifacts/windows-x64/worksheet-errors/calcvba8-final-parameter-source/'
live = json.loads(files[live_base+'windows-scalar-interop/engine-range-test.json'])
assert live['exit_code'] == 0 and live['excel_pid'] != 3144
receipt = json.loads(files[live_base+'results.json'])
assert receipt['passed']
assert all(c['cleanup_status'] == 'owned-process-zero' for c in receipt['cases'])
fixture_name = 'docs/evidence/programs/ideal-2026-07/windows-x64/WIN-4/worksheet-errors.bas'
assert files['source/'+fixture_name].decode('utf-8').strip() == files[live_base+'windows-scalar-interop/OracleSelfTest.bas'].decode('utf-8-sig').strip()

archive = HERE / 'run8-validation.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
    for name, data in sorted(files.items()):
        bundle.writestr(name, data)
manifest = {
    'schema': 'oxvba.run8.development-evidence.v1',
    'created_utc': datetime.now(timezone.utc).isoformat(),
    'baseline_commit': BASELINE,
    'bounded_delivery_beads': ['bd-59co.2.10.10','bd-59co.2.9.13','bd-59co.2.10.11'],
    'broader_open_beads': ['bd-59co.2.9.9','bd-59co.2.10.7','bd-59co.2.10.12'],
    'archive': archive.name,
    'archive_sha256': sha(archive.read_bytes()),
    'source_sha256': {n:sha(files['source/'+n]) for n in sorted(source)},
    'archive_members_sha256': {n:sha(d) for n,d in sorted(files.items())},
    'build_inputs_sha256': {'Cargo.lock':sha(files['build/Cargo.lock'])},
    'reproduce_build':'Restore build/Cargo.lock from the archive to the workspace root before rerunning Cargo commands.',
    'repository_check': {
        'command':'./scripts/meta-check.ps1 -Fast -NoArtifacts -NoRegistry -RunId calcvba8-validated',
        'result':'passed', 'log':meta_name,
        'suites':len(counts),
        'counts':dict(zip(['passed','failed','ignored','measured','filtered_out'], map(sum, zip(*counts)))),
        'registry_writing_tests_excluded':4,
        'excluded_tests_receive_passing_credit':False,
    },
    'formal': {
        'lean_models':8,
        'default_miri':{'result':'passed','tests':11,'log':'raw/calcvba8-miri-final.log',
            'warning':'Existing Variant byte carrier uses exposed-provenance pointer recovery.'},
        'strict_object_only':{'result':'passed','tests':1,'log':'raw/calcvba8-miri-strict-object-only.log'},
        'strict_parameters':{'result':'passed','tests':1,'log':'raw/calcvba8-miri-strict-parameters.log'},
        'strict_globals':{'result':'unsupported-operation','passing_credit':False,
            'log':'raw/calcvba8-miri-strict-frame.log'},
        'jit_machine_code_proved':False,
        'concrete_cfg_alias_signature_refinement_proved':False,
    },
    'live_excel':dict(live, results=live_base+'results.json',
        observation='Range|Range|True|True|43|Range|True|13|7|7', module_matches_current_fixture_after_outer_whitespace_normalization=True, certifying=False),
    'blind_round10':{'evidence_commit':'51bed087','calls':88,'exact_semantic_rows':72,
        'literal_transport_audits':16,'changed_literal_input_obligations':14,
        'prediction_contents_inspected':False},
    'limits':'Bounded typed Functions/Property Gets only; synchronous callbacks complete before suspension. General stack/ByRef/handler continuations, strings/arrays and DNA Calc glue remain open. No Windows certification.',
}
(HERE/'run8-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'members':len(files),'source_files':len(source),'archive_bytes':archive.stat().st_size,
    'check':manifest['repository_check']},indent=2))
