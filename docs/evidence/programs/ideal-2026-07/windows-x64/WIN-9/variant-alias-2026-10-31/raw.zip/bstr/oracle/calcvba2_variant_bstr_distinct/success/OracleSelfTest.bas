Option Explicit
Private Declare PtrSafe Function NativeAlias Lib "C:/Work/DnaCalc/codex-runs/calcvba-2-variant-alias/bstr/native_variant_alias.dll" Alias "AliasVariantString" (ByRef first As Variant, ByRef second As Variant) As Long

Public Function RunProbe() As String
    Dim first As Variant
    Dim second As Variant
    Dim result As Long
    Dim savedError As Long
    first = "old owned string"
    second = first
    result = NativeAlias(first, second)
    savedError = Err.LastDllError
    RunProbe = CStr(result) & "|" & first & "|" & CStr(Len(second)) & "|" & Replace(second, Chr(0), ":") & "|" & CStr(savedError)
End Function
