Option Explicit

Public Function RunProbe() As String
    RunProbe = "success-ok"
End Function
