Option Explicit
Private Declare PtrSafe Function NativeOrdinal Lib "kernel32" Alias "#1x" () As Long

Public Function RunProbe() As String
    RunProbe = "ordinal-compile-ok"
End Function
