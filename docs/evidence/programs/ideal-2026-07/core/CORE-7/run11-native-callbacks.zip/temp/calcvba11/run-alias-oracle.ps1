$ErrorActionPreference='Stop'
$rootScripts=(Resolve-Path scripts).Path
$script:aliasSource=Get-Content -Raw -LiteralPath temp/calcvba11/alias-callback.bas
$supervisor=Get-Content -Raw -LiteralPath (Join-Path $rootScripts 'run-excel-vba-oracle.ps1')
$anchor='. (Join-Path $PSScriptRoot "excel-vba-oracle-bootstrap.ps1")'
$override=@'
$script:aliasDescriptor=@(Get-ExcelOracleHarnessCases | Where-Object id -eq 'windows-scalar-interop')[0]
$script:aliasDescriptor.module_source=$script:aliasSource
$script:aliasDescriptor.expected_value='13:13'
$script:aliasDescriptor.purpose='Native exact-Long ByRef visibility during callback development observation'
function Get-ExcelOracleHarnessCases { return @($script:aliasDescriptor) }
'@
$supervisor=$supervisor.Replace($anchor,$anchor+[Environment]::NewLine+$override)
$supervisor=$supervisor.Replace('$PSScriptRoot',("'"+$rootScripts.Replace("'","''")+"'"))
& ([scriptblock]::Create($supervisor)) -EnvironmentId 'win-x64-dev-oracle-2026-07' -NoMatrixUpdate -SafeMode -DiagnosticCaseId 'windows-scalar-interop' -RunId 'calcvba11-live-byref-oracle' -OutputRoot 'temp/calcvba11/oracle' -TimeoutSeconds 180
