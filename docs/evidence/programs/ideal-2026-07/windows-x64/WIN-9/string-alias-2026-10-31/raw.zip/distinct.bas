Option Explicit
Private Declare PtrSafe Function NativeProbe Lib "C:/Work/DnaCalc/codex-runs/calcvba-2-string-alias/native_string_alias.dll" Alias "ObserveAnsiRef" (ByRef first As String, ByRef second As String) As Long

Public Function RunProbe() As String
    Dim first As String, second As String
    Dim result As Long, savedError As Long
    first = "abcd"
    second = first
    result = NativeProbe(first, second)
    savedError = Err.LastDllError
    RunProbe = CStr(result) & "|" & first & "|" & second & "|" & CStr(savedError)
End Function