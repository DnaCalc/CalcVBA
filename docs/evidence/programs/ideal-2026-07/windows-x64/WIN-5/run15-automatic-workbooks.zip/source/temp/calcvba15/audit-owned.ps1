$ErrorActionPreference='Stop'
$records=@()
foreach ($directory in Get-ChildItem -LiteralPath 'temp/calcvba15/oracle' -Directory | Where-Object Name -like 'run15-*') {
    foreach ($name in @('owned-processes.jsonl','owned-helper-processes.jsonl')) {
        $ledger=Join-Path $directory.FullName $name
        if (Test-Path -LiteralPath $ledger) {
            foreach ($line in [IO.File]::ReadAllLines($ledger)) {
                if ($line.Trim()) {$records+=,$($line | ConvertFrom-Json)}
            }
        }
    }
}
$seen=[Collections.Generic.HashSet[string]]::new()
if (@($records | Where-Object {[int]$_.pid -eq 3144}).Count -gt 0) {throw 'Protected PID 3144 unexpectedly appears in an ownership ledger'}
$observations=@()
$exact=@()
$uncertain=@()
foreach ($record in $records) {
    $key=[string]$record.pid+'|'+[string]$record.process_start_utc
    if (-not $seen.Add($key)) {continue}
    $process=Get-Process -Id ([int]$record.pid) -ErrorAction SilentlyContinue
    $state='missing'
    $observedStart=''
    if ($process) {
        try {
            if ($process.HasExited) {$state='exited'}
            else {
                $recorded=[DateTime]::Parse([string]$record.process_start_utc,[Globalization.CultureInfo]::InvariantCulture,[Globalization.DateTimeStyles]::RoundtripKind).ToUniversalTime()
                if ($process.StartTime.ToUniversalTime().ToFileTimeUtc() -ne $recorded.ToFileTimeUtc()) {$state='pid-reused'}
                else {$state='exact-live';$exact+=,$record}
            }
        }
        catch {
            # A recycled protected service PID can deny Diagnostics.Process.
            # Read its creation date through CIM; never acquire kill authority.
            $current=Get-CimInstance Win32_Process -Filter ('ProcessId='+[int]$record.pid)
            $recorded=[DateTime]::Parse([string]$record.process_start_utc,[Globalization.CultureInfo]::InvariantCulture,[Globalization.DateTimeStyles]::RoundtripKind).ToUniversalTime()
            if (-not $current) {$state='missing'}
            elseif ($current.CreationDate -and $current.CreationDate.ToUniversalTime().ToFileTimeUtc() -ne $recorded.ToFileTimeUtc()) {
                $state='pid-reused';$observedStart=$current.CreationDate.ToUniversalTime().ToString('o')
            }
            else {$state='unverified';$uncertain+=,$record}
        }
    }
    $observations+=,[ordered]@{run=[string]$record.run_id;pid=[int]$record.pid;recorded_start_utc=[string]$record.process_start_utc;observed_reused_start_utc=$observedStart;process_name=[string]$record.process_name;state=$state}
}
$result=[ordered]@{captured_utc=[DateTime]::UtcNow.ToString('o');recorded_identities=$observations.Count;exact_live_owned_processes=@($exact);unverified_live_processes=@($uncertain);observations=$observations;protected_pid_3144_was_never_targeted=$true;termination_actions=@()}
[IO.File]::WriteAllText((Join-Path (Get-Location) 'temp/calcvba15/final-owned-audit.json'),($result | ConvertTo-Json -Depth 15)+"`n",[Text.UTF8Encoding]::new($false))
if ($exact.Count -gt 0 -or $uncertain.Count -gt 0) {throw 'Recorded owned identities remain live or unverified; inspect exact identities before cleanup'}
Write-Output "Owned identity audit: $($observations.Count) recorded identities; zero live owned processes; no termination actions"
