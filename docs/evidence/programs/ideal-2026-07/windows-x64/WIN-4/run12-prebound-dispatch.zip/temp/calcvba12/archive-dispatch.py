from pathlib import Path
import hashlib, json, re, subprocess, zipfile

repo = Path.cwd()
root = repo / 'docs/evidence/programs/ideal-2026-07/windows-x64/WIN-4'
archive = root / 'run12-prebound-dispatch.zip'
manifest = root / 'run12-prebound-dispatch.json'
files = set(subprocess.check_output(['git', 'diff', 'HEAD', '--name-only'], text=True).splitlines())
files.update(subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], text=True).splitlines())
files = {p for p in files if not p.startswith('.beads/') or p == '.beads/issues.jsonl'}
files.update(['Cargo.toml', 'Cargo.lock', '.cargo/config.toml',
              'crates/oxvba-com/src/typed_slots.rs', 'crates/oxvba-com/src/typed_slots/library.rs',
              'crates/oxvba-com/src/windows_variant.rs', 'crates/oxvba-rt-abi/src/host_entry/value.rs',
              'scripts/run-excel-vba-oracle.ps1', 'scripts/excel-vba-oracle-worker.ps1',
              'scripts/excel-vba-oracle-contract.ps1', 'scripts/excel-vba-oracle-guardian.ps1'])
files.update(f'formal/lean/OxVba/{model}.lean' for model in ['RefCount','TypedContinuation','TypedReentry','ProcedureHandles'])
files.update(str(p.relative_to(repo)).replace('\\', '/') for p in (repo/'temp/calcvba12/oracle').rglob('*') if p.is_file())
files.update(str(p.relative_to(repo)).replace('\\', '/') for p in (repo/'temp/calcvba12').glob('*')
             if p.is_file() and p.suffix in {'.log','.txt','.bas','.json','.jsonl','.py'})
files = {p for p in files if (repo/p).is_file() and (repo/p) not in [archive, manifest]}
check = (repo/'temp/calcvba12/dispatch-meta-final.log').read_text()
assert '[oxvba] meta check complete' in check
rows = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', check)
counts = {'passed':sum(int(v[0]) for v in rows), 'failed':sum(int(v[1]) for v in rows), 'ignored':sum(int(v[2]) for v in rows), 'suites':len(rows)}
assert counts['failed'] == 0
oracle_root = repo/'temp/calcvba12/oracle/calcvba12-prebound-final-cells'
oracle = json.loads((oracle_root/'results.json').read_text(encoding='utf-8-sig'))
assert oracle['cases'][0]['compile_status'] == 'ok' and oracle['cases'][0]['run_status'] == 'ok'
native = json.loads((oracle_root/'windows-scalar-interop/engine-prebound-test.json').read_text(encoding='utf-8-sig'))
assert native['exit_code'] == 0
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as z:
    for name in sorted(files): z.write(repo/name, name)
    z.writestr('source.patch', subprocess.check_output(['git','diff','HEAD','--binary']))
    z.writestr('commands.txt', 'cargo test -p oxvba-embed --test typed_prebound_dispatch --test typed_native_com\npwsh -NoProfile -File scripts/run-typed-prebound-oracle.ps1 -RunId calcvba12-prebound-final-cells -RuntimeTestExecutable target/debug/deps/typed_native_com-e271c130634d645b.exe\npwsh -NoProfile -File scripts/meta-check.ps1 -Fast -NoArtifacts -NoRegistry -RunId calcvba12-prebound-final-state\nThe meta check uses the existing br 0.1.34 backup in process-local PATH pending ordered tracker repair. No global installation changed.\n')
manifest.write_bytes((json.dumps({
    'schema':'oxvba.run12.prebound-dispatch.development-evidence.v1',
    'delivery':'bd-59co.3.5.9',
    'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
    'archive':archive.name, 'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
    'files_sha256':{name:hashlib.sha256((repo/name).read_bytes()).hexdigest() for name in sorted(files)},
    'check':counts,
    'native_test':native,
    'vba_value':oracle['cases'][0]['run_value'],
    'backends':['VM3 owning typed','native JIT owning typed'],
    'transport':'one retained IID/DISPID/accessor Invoke for pure dispinterfaces; native dual slots never retry; controlled name/type-info counts zero',
    'formal':'installed RefCount/TypedContinuation/TypedReentry/ProcedureHandles abstractions pass; concrete native/proxy/provenance refinement unproved',
    'residuals':['bd-59co.2.9.20','bd-59co.3.5.10','bd-59co.3.5.3','bd-59co.3.6.4'],
    'certification_credit':False,
},indent=2)+'\n').encode())
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name in files: assert hashlib.sha256(z.read(name)).hexdigest() == hashlib.sha256((repo/name).read_bytes()).hexdigest()
print(json.dumps(counts))
