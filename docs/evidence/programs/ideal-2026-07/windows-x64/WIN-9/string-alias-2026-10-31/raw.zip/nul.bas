Option Explicit
Private Declare PtrSafe Function NativeProbe Lib "C:/Work/DnaCalc/codex-runs/calcvba-2-string-alias/native_string_alias.dll" Alias "ObserveAnsiRef" (ByRef first As String, ByRef second As String) As Long

Public Function RunProbe() As String
    Dim value As String
    Dim result As Long, savedError As Long
    value = "ab" & Chr(0) & "d"
    result = NativeProbe(value, value)
    savedError = Err.LastDllError
    RunProbe = CStr(result) & "|" & CStr(Len(value)) & "|" & Replace(value, Chr(0), ":") & "|" & CStr(savedError)
End Function