#[cfg(all(target_os = "windows", target_arch = "x86_64"))]
mod windows_native_declare_string_e2e {
    use oxvba_hal::model::HostPolicy;
    use oxvba_host::{DiagnosticPhase, Engine, HostConfig};
    use oxvba_runtime::Variant;

    fn run_windows_host_backed(
        source: &str,
        jit_requested: bool,
        jit_decline: Option<&str>,
    ) -> Option<Vec<Variant>> {
        if let (true, Some(expected_decline)) = (jit_requested, jit_decline) {
            let mut engine = Engine::new(HostConfig::jit());
            engine.set_host_policy(HostPolicy::interactive_dev());
            let err = engine
                .execute_source_with_variant_snapshot_clean(source)
                .expect_err("pointer-helper writeback should remain an explicit JIT decline");
            let diagnostic = err.diagnostic();
            assert_eq!(err.phase(), DiagnosticPhase::Runtime);
            assert_eq!(diagnostic.code.as_str(), "RUN-E-JIT-UNSUPPORTED");
            assert_eq!(diagnostic.phase.as_str(), "runtime");
            assert_eq!(diagnostic.severity.as_str(), "error");
            assert_eq!(diagnostic.vba_error_number, None);
            assert!(
                err.message().contains(expected_decline),
                "unexpected decline: {err}"
            );
            return None;
        }

        let mut engine = Engine::new(if jit_requested {
            HostConfig::jit()
        } else {
            HostConfig::vm3()
        });
        engine.set_host_policy(HostPolicy::interactive_dev());
        Some(
            engine
                .execute_source_with_variant_snapshot_clean(source)
                .expect("native declare probe should execute"),
        )
    }

    fn non_zero_i64(value: &Variant) -> Option<i64> {
        value.as_i64().filter(|value| *value != 0)
    }

    fn contains_string(snapshot: &[Variant], expected: &str) -> bool {
        snapshot.iter().any(|value| {
            value
                .as_bstr()
                .is_some_and(|text| text.as_str() == expected)
        })
    }

    #[test]
    fn loadlibrarya_byval_string_marshals_ansi_path_on_vm3_and_jit() {
        let source = r#"
Private Declare PtrSafe Function LoadLibrary Lib "kernel32" Alias "LoadLibraryA" (ByVal lpLibFileName As String) As LongPtr
Private Declare PtrSafe Function FreeLibrary Lib "kernel32" (ByVal hLibModule As LongPtr) As Long

Sub Main()
    Dim moduleHandle As LongPtr
    moduleHandle = LoadLibrary("kernel32.dll")
    If moduleHandle <> 0 Then
        Call FreeLibrary(moduleHandle)
    End If
End Sub
"#;

        for jit_requested in [false, true] {
            let Some(snapshot) = run_windows_host_backed(source, jit_requested, None) else {
                continue;
            };
            let handle = snapshot
                .iter()
                .find_map(non_zero_i64)
                .expect("snapshot should contain a non-zero module handle");
            assert_ne!(
                handle, 0,
                "LoadLibraryA should succeed for jit_requested={jit_requested}"
            );
        }
    }

    #[test]
    fn getmodulehandleexw_byref_longptr_writeback_marshals_native_out_pointer_in_vm_and_rejects_jit()
     {
        let source = r#"
Private Declare PtrSafe Function GetModuleHandleExW Lib "kernel32" (ByVal dwFlags As Long, ByVal lpModuleName As LongPtr, ByRef phModule As LongPtr) As Long
Private Declare PtrSafe Function FreeLibrary Lib "kernel32" (ByVal hLibModule As LongPtr) As Long

Sub Main()
    Dim moduleHandle As LongPtr
    Dim ok As Long

    ok = GetModuleHandleExW(0, StrPtr("kernel32.dll"), moduleHandle)
    If ok <> 0 And moduleHandle <> 0 Then
        Call FreeLibrary(moduleHandle)
    End If
End Sub
"#;

        for jit_requested in [false, true] {
            let Some(snapshot) = run_windows_host_backed(source, jit_requested, Some("Ptr {"))
            else {
                continue;
            };
            let handle = snapshot
                .iter()
                .find_map(non_zero_i64)
                .expect("snapshot should contain a non-zero module handle");
            assert_ne!(
                handle, 0,
                "GetModuleHandleExW should populate ByRef LongPtr output for jit_requested={jit_requested}"
            );
        }
    }

    #[test]
    fn multibytetowidechar_strptr_target_writes_back_string_slot_in_vm_and_rejects_jit() {
        let source = r#"
Private Const CP_UTF8 As Long = 65001
Private Declare PtrSafe Function MultiByteToWideChar Lib "kernel32" (ByVal CodePage As Long, ByVal dwFlags As Long, ByVal lpMultiByteStr As LongPtr, ByVal cbMultiByte As Long, ByVal lpWideCharStr As LongPtr, ByVal cchWideChar As Long) As Long

Sub Main()
    Dim utf8(0 To 5) As Byte
    Dim resultText As String
    Dim written As Long

    utf8(0) = 97
    utf8(1) = 108
    utf8(2) = 112
    utf8(3) = 104
    utf8(4) = 97
    utf8(5) = 0
    resultText = String(5, 42)
    written = MultiByteToWideChar(CP_UTF8, 0, VarPtr(utf8(0)), -1, StrPtr(resultText), 6)
End Sub
"#;

        for jit_requested in [false, true] {
            let Some(snapshot) = run_windows_host_backed(source, jit_requested, Some("Ptr {"))
            else {
                continue;
            };
            assert!(
                contains_string(&snapshot, "alpha"),
                "MultiByteToWideChar should write back through StrPtr target for jit_requested={jit_requested}; snapshot={snapshot:?}"
            );
        }
    }

    #[test]
    fn strptr_target_writeback_is_driven_by_expression_shape_not_declared_name() {
        let source = r#"
Private Const CP_UTF8 As Long = 65001
Private Declare PtrSafe Function OxDecodeUtf8Buffer Lib "kernel32" Alias "MultiByteToWideChar" (ByVal CodePage As Long, ByVal dwFlags As Long, ByVal lpMultiByteStr As LongPtr, ByVal cbMultiByte As Long, ByVal lpWideCharStr As LongPtr, ByVal cchWideChar As Long) As Long

Sub Main()
    Dim utf8(0 To 5) As Byte
    Dim resultText As String
    Dim written As Long

    utf8(0) = 97
    utf8(1) = 108
    utf8(2) = 112
    utf8(3) = 104
    utf8(4) = 97
    utf8(5) = 0
    resultText = String(5, 42)
    written = OxDecodeUtf8Buffer(CP_UTF8, 0, VarPtr(utf8(0)), -1, StrPtr(resultText), 6)
End Sub
"#;

        for jit_requested in [false, true] {
            let Some(snapshot) = run_windows_host_backed(source, jit_requested, Some("Ptr {"))
            else {
                continue;
            };
            assert!(
                contains_string(&snapshot, "alpha"),
                "StrPtr writeback should not depend on the declared API name for jit_requested={jit_requested}; snapshot={snapshot:?}"
            );
        }
    }

    #[test]
    fn sysreallocstring_varptr_string_target_writes_back_string_slot_in_vm_and_rejects_jit() {
        let source = r#"
Private Declare PtrSafe Function SysReAllocString Lib "oleaut32" (ByVal pbstr As LongPtr, ByVal psz As LongPtr) As Long

Sub Main()
    Dim textValue As String
    Dim status As Long

    textValue = "*****"
    status = SysReAllocString(VarPtr(textValue), StrPtr("alpha"))
End Sub
"#;

        for jit_requested in [false, true] {
            let Some(snapshot) = run_windows_host_backed(source, jit_requested, Some("Ptr {"))
            else {
                continue;
            };
            assert!(
                contains_string(&snapshot, "alpha"),
                "SysReAllocString should write back through VarPtr(String) for jit_requested={jit_requested}; snapshot={snapshot:?}"
            );
        }
    }

    #[test]
    fn widechartomultibyte_varptr_buffer_target_writes_back_array_slot_in_vm_and_rejects_jit() {
        let source = r#"
Private Const CP_UTF8 As Long = 65001
Private Declare PtrSafe Function WideCharToMultiByte Lib "kernel32" (ByVal CodePage As Long, ByVal dwFlags As Long, ByVal lpWideCharStr As LongPtr, ByVal cchWideChar As Long, ByVal lpMultiByteStr As LongPtr, ByVal cbMultiByte As Long, ByVal lpDefaultChar As LongPtr, ByVal lpUsedDefaultChar As LongPtr) As Long
Private Declare PtrSafe Function lstrlenA Lib "kernel32" (ByVal lpString As LongPtr) As Long

Sub Main()
    Dim textValue As String
    Dim buf() As Byte
    Dim size As Long
    Dim actualLength As Long

    textValue = "@A"
    size = WideCharToMultiByte(CP_UTF8, 0, StrPtr(textValue), -1, 0, 0, 0, 0)
    ReDim buf(size)
    Call WideCharToMultiByte(CP_UTF8, 0, StrPtr(textValue), -1, VarPtr(buf(0)), size, 0, 0)
    actualLength = lstrlenA(VarPtr(buf(0)))
End Sub
"#;

        for jit_requested in [false, true] {
            let Some(snapshot) = run_windows_host_backed(source, jit_requested, Some("Ptr {"))
            else {
                continue;
            };
            assert!(
                snapshot.iter().any(|value| value.as_i32() == Some(2)),
                "WideCharToMultiByte should write a 2-byte C string into the array slot for jit_requested={jit_requested}; snapshot={snapshot:?}"
            );
        }
    }

    #[test]
    fn varptr_buffer_writeback_is_driven_by_expression_shape_not_declared_name() {
        let source = r#"
Private Const CP_UTF8 As Long = 65001
Private Declare PtrSafe Function OxEncodeWideToUtf8 Lib "kernel32" Alias "WideCharToMultiByte" (ByVal CodePage As Long, ByVal dwFlags As Long, ByVal lpWideCharStr As LongPtr, ByVal cchWideChar As Long, ByVal lpMultiByteStr As LongPtr, ByVal cbMultiByte As Long, ByVal lpDefaultChar As LongPtr, ByVal lpUsedDefaultChar As LongPtr) As Long
Private Declare PtrSafe Function lstrlenA Lib "kernel32" (ByVal lpString As LongPtr) As Long

Sub Main()
    Dim textValue As String
    Dim buf() As Byte
    Dim size As Long
    Dim actualLength As Long

    textValue = "@A"
    size = OxEncodeWideToUtf8(CP_UTF8, 0, StrPtr(textValue), -1, 0, 0, 0, 0)
    ReDim buf(size)
    Call OxEncodeWideToUtf8(CP_UTF8, 0, StrPtr(textValue), -1, VarPtr(buf(0)), size, 0, 0)
    actualLength = lstrlenA(VarPtr(buf(0)))
End Sub
"#;

        for jit_requested in [false, true] {
            let Some(snapshot) = run_windows_host_backed(source, jit_requested, Some("Ptr {"))
            else {
                continue;
            };
            assert!(
                snapshot.iter().any(|value| value.as_i32() == Some(2)),
                "VarPtr buffer writeback should not depend on the declared API name for jit_requested={jit_requested}; snapshot={snapshot:?}"
            );
        }
    }

    #[test]
    fn msvcrt_sqrt_round_trips_double_value_on_vm3_and_jit() {
        let source = r#"
Private Declare PtrSafe Function sqrt Lib "msvcrt" (ByVal x As Double) As Double

Sub Main()
    Dim resultValue As Double
    resultValue = sqrt(156.25)
End Sub
"#;

        for jit_requested in [false, true] {
            let Some(snapshot) = run_windows_host_backed(source, jit_requested, None) else {
                continue;
            };
            assert!(
                snapshot.iter().any(|value| value.as_f64() == Some(12.5)),
                "sqrt should return 12.5 through the native Double lane for jit_requested={jit_requested}; snapshot={snapshot:?}"
            );
        }
    }

    #[test]
    fn oleaut32_varcyfromi4_byref_currency_writeback_round_trips_on_vm3_and_jit() {
        let source = r#"
Private Declare PtrSafe Function VarCyFromI4 Lib "oleaut32" (ByVal inputValue As Long, ByRef outValue As Currency) As Long

Sub Main()
    Dim status As Long
    Dim outValue As Currency

    status = VarCyFromI4(123, outValue)
End Sub
"#;

        for jit_requested in [false, true] {
            let Some(snapshot) = run_windows_host_backed(source, jit_requested, None) else {
                continue;
            };
            assert!(
                snapshot
                    .iter()
                    .any(|value| value.as_currency_scaled_i64() == Some(1_230_000)),
                "VarCyFromI4 should populate ByRef Currency output for jit_requested={jit_requested}; snapshot={snapshot:?}"
            );
        }
    }

    #[test]
    fn oleaut32_varboolfromi4_byref_boolean_writeback_round_trips_on_vm3_and_jit() {
        let source = r#"
Private Declare PtrSafe Function VarBoolFromI4 Lib "oleaut32" (ByVal inputValue As Long, ByRef outValue As Boolean) As Long

Sub Main()
    Dim outValue As Boolean
    Dim status As Long
    status = VarBoolFromI4(123, outValue)
End Sub
"#;

        for jit_requested in [false, true] {
            let Some(snapshot) = run_windows_host_backed(source, jit_requested, None) else {
                continue;
            };
            assert!(
                snapshot.contains(&Variant::from_bool(true)),
                "VarBoolFromI4 should populate ByRef Boolean output for jit_requested={jit_requested}; snapshot={snapshot:?}"
            );
        }
    }

    #[test]
    fn oleaut32_varr8fromi4_byref_double_writeback_round_trips_on_vm3_and_jit() {
        let source = r#"
Private Declare PtrSafe Function VarR8FromI4 Lib "oleaut32" (ByVal inputValue As Long, ByRef outValue As Double) As Long

Sub Main()
    Dim outValue As Double
    Dim status As Long
    status = VarR8FromI4(123, outValue)
End Sub
"#;

        for jit_requested in [false, true] {
            let Some(snapshot) = run_windows_host_backed(source, jit_requested, None) else {
                continue;
            };
            assert!(
                snapshot.iter().any(|value| value.as_f64() == Some(123.0)),
                "VarR8FromI4 should populate ByRef Double output for jit_requested={jit_requested}; snapshot={snapshot:?}"
            );
        }
    }

    #[test]
    fn oleaut32_varr4fromi4_byref_single_writeback_round_trips_on_vm3_and_jit() {
        let source = r#"
Private Declare PtrSafe Function VarR4FromI4 Lib "oleaut32" (ByVal inputValue As Long, ByRef outValue As Single) As Long

Sub Main()
    Dim outValue As Single
    Dim status As Long
    status = VarR4FromI4(123, outValue)
End Sub
"#;

        for jit_requested in [false, true] {
            let Some(snapshot) = run_windows_host_backed(source, jit_requested, None) else {
                continue;
            };
            assert!(
                snapshot.iter().any(|value| value.as_f32() == Some(123.0)),
                "VarR4FromI4 should populate ByRef Single output for jit_requested={jit_requested}; snapshot={snapshot:?}"
            );
        }
    }

    #[test]
    fn oleaut32_vari2fromi4_byref_integer_writeback_round_trips_on_vm3_and_jit() {
        let source = r#"
Private Declare PtrSafe Function VarI2FromI4 Lib "oleaut32" (ByVal inputValue As Long, ByRef outValue As Integer) As Long

Sub Main()
    Dim outValue As Integer
    Dim status As Long
    status = VarI2FromI4(123, outValue)
End Sub
"#;

        for jit_requested in [false, true] {
            let Some(snapshot) = run_windows_host_backed(source, jit_requested, None) else {
                continue;
            };
            assert!(
                snapshot.contains(&Variant::from_i16(123)),
                "VarI2FromI4 should populate ByRef Integer output for jit_requested={jit_requested}; snapshot={snapshot:?}"
            );
        }
    }

    #[test]
    fn getdiskfreespaceexw_byref_longlong_writeback_round_trips_in_vm_and_rejects_jit() {
        let source = r#"
Private Declare PtrSafe Function GetDiskFreeSpaceExW Lib "kernel32" (ByVal lpDirectoryName As LongPtr, ByRef lpFreeBytesAvailableToCaller As LongLong, ByRef lpTotalNumberOfBytes As LongLong, ByRef lpTotalNumberOfFreeBytes As LongLong) As Long

Sub Main()
    Dim freeBytes As LongLong
    Dim totalBytes As LongLong
    Dim totalFreeBytes As LongLong
    Dim status As Long
    status = GetDiskFreeSpaceExW(StrPtr("C:\"), freeBytes, totalBytes, totalFreeBytes)
End Sub
"#;

        for jit_requested in [false, true] {
            let Some(snapshot) = run_windows_host_backed(source, jit_requested, Some("Ptr {"))
            else {
                continue;
            };
            assert!(
                snapshot
                    .iter()
                    .any(|value| value.as_i64().is_some_and(|raw| raw > 0)),
                "GetDiskFreeSpaceExW should populate ByRef LongLong outputs for jit_requested={jit_requested}; snapshot={snapshot:?}"
            );
        }
    }

    #[test]
    fn oleaut32_vardatefromstr_byref_date_writeback_round_trips_in_vm_and_rejects_jit() {
        let source = r#"
Private Declare PtrSafe Function VarDateFromStr Lib "oleaut32" (ByVal inputText As LongPtr, ByVal lcid As Long, ByVal flags As Long, ByRef outValue As Date) As Long

Sub Main()
    Dim status As Long
    Dim outValue As Date

    status = VarDateFromStr(StrPtr("January 1, 2000"), 1033, 0, outValue)
End Sub
"#;

        for jit_requested in [false, true] {
            let Some(snapshot) = run_windows_host_backed(source, jit_requested, Some("Ptr {"))
            else {
                continue;
            };
            assert!(
                snapshot
                    .iter()
                    .any(|value| value.as_date_f64() == Some(36526.0)),
                "VarDateFromStr should populate ByRef Date output for jit_requested={jit_requested}; snapshot={snapshot:?}"
            );
        }
    }

    #[test]
    fn lstrcpya_byval_string_buffer_writes_back_on_vm3_and_jit() {
        // The VBA pre-sized-buffer idiom: a `ByVal … As String` argument marshals
        // as a system-codepage ANSI copy, and the callee-mutated buffer converts
        // BACK into the variable after the call — `ByVal` notwithstanding.
        // lstrcpyA writes "alpha\0" over the front of the 10-char buffer; the
        // write-back must preserve the buffer's full length (`Len` stays 10, the
        // "*" tail survives past the embedded NUL). Inspect the complete buffer
        // as well as its known five-character prefix.
        let source = r#"
Private Declare PtrSafe Function lstrcpyA Lib "kernel32" (ByVal dst As String, ByVal src As String) As LongPtr

Sub Main()
    Dim buffer As String
    Dim copied As String
    Dim keptLen As Long

    buffer = String(10, 42)
    lstrcpyA buffer, "alpha"
    keptLen = Len(buffer)
    copied = Left(buffer, 5)
End Sub
"#;

        for jit_requested in [false, true] {
            let Some(snapshot) = run_windows_host_backed(source, jit_requested, None) else {
                continue;
            };
            assert!(
                contains_string(&snapshot, "alpha"),
                "lstrcpyA should write back through the ByVal String buffer for jit_requested={jit_requested}; snapshot={snapshot:?}"
            );
            assert!(
                contains_string(&snapshot, "alpha\0****"),
                "full buffer changed: {snapshot:?}"
            );
            assert!(
                snapshot.iter().any(|value| value.as_i32() == Some(10)),
                "the write-back should keep the full ANSI buffer length for jit_requested={jit_requested}; snapshot={snapshot:?}"
            );
        }
    }

    #[test]
    fn get_pgmptr_byref_string_reads_replaced_pointer_on_vm3_and_jit() {
        // `ByRef … As String` passes an `LPSTR*` cell. `_get_pgmptr` REPLACES the
        // pointer with a CRT-owned copy of the program path, so the read-back must
        // follow the replacement pointer (NUL-terminated ANSI) rather than the
        // original buffer — and must not free the CRT's memory.
        let source = r#"
Private Declare PtrSafe Function GetProgramPath Lib "msvcrt" Alias "_get_pgmptr" (ByRef path As String) As Long

Sub Main()
    Dim path As String
    Dim status As Long
    Dim exeAt As Long

    status = GetProgramPath(path)
    exeAt = InStr(1, LCase(path), ".exe")
End Sub
"#;

        for jit_requested in [false, true] {
            let Some(snapshot) = run_windows_host_backed(source, jit_requested, None) else {
                continue;
            };
            assert!(
                snapshot
                    .iter()
                    .any(|value| value.as_i32().is_some_and(|at| at > 0)),
                "_get_pgmptr should populate the ByRef String with the .exe path for jit_requested={jit_requested}; snapshot={snapshot:?}"
            );
        }
    }

    #[test]
    fn sysallocstringbytelen_string_return_unmarshals_ansi_bstr_on_vm3_and_jit() {
        // The VB contract for `Declare Function … As String`: the callee returns a
        // BSTR holding ANSI bytes; the runtime decodes it to Unicode and frees it.
        // SysAllocStringByteLen is that contract's own constructor — it copies the
        // 5 ANSI bytes of "alpha" (marshaled in from the ByVal String argument)
        // into a fresh ANSI BSTR and returns it.
        let source = r#"
Private Declare PtrSafe Function MakeAnsiBstr Lib "oleaut32" Alias "SysAllocStringByteLen" (ByVal source As String, ByVal byteLength As Long) As String

Sub Main()
    Dim made As String
    made = MakeAnsiBstr("alpha", 5)
End Sub
"#;

        for jit_requested in [false, true] {
            let Some(snapshot) = run_windows_host_backed(source, jit_requested, None) else {
                continue;
            };
            assert!(
                contains_string(&snapshot, "alpha"),
                "a String-returning Declare should decode the ANSI BSTR for jit_requested={jit_requested}; snapshot={snapshot:?}"
            );
        }
    }

    #[test]
    fn err_lastdllerror_reads_os_error_after_native_declare_on_vm3_and_jit() {
        // `SetLastError(N)` sets the thread's Win32 last-error to N; the HAL captures
        // `GetLastError` immediately after the native call, and `Err.LastDllError` reads
        // it back — proving the capture is wired end to end (not a constant 0).
        let source = r#"
Private Declare PtrSafe Sub SetLastError Lib "kernel32" (ByVal dwErrCode As Long)

Sub Main()
    Dim captured As Long
    SetLastError 12345
    captured = Err.LastDllError
End Sub
"#;

        for jit_requested in [false, true] {
            let Some(snapshot) = run_windows_host_backed(source, jit_requested, None) else {
                continue;
            };
            assert!(
                snapshot.iter().any(|value| value.as_i32() == Some(12345)),
                "Err.LastDllError should read the SetLastError value for jit_requested={jit_requested}; snapshot={snapshot:?}"
            );
        }
    }
}
