Option Explicit
Private Declare PtrSafe Function NativeProbe Lib "C:/Work/DnaCalc/codex-runs/calcvba-2-string-alias/native_string_alias.dll" Alias "ObserveAnsiRef" (ByRef first As String, ByRef second As String) As Long

Private Function Forward(ByRef first As String, ByRef second As String) As Long
    Forward = NativeProbe(first, second)
End Function

Public Function RunProbe() As String
    Dim value As String
    Dim result As Long
    Dim savedError As Long
    value = "abcd"
    result = Forward(value, value)
    savedError = Err.LastDllError
    RunProbe = CStr(result) & "|" & value & "|" & CStr(savedError)
End Function