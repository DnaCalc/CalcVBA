Option Explicit

Public Function RunProbe() As String
    Dim capturedDescription As String

    On Error GoTo Handler
    Application.Run "OracleSelfTest.MissingMacro"
    RunProbe = "unexpected-success"
    Exit Function

Handler:
    capturedDescription = Err.Description
    MsgBox capturedDescription, vbOKOnly, "Microsoft Excel"
    RunProbe = "oracle-ambiguous-entry-observed:" & capturedDescription
End Function
