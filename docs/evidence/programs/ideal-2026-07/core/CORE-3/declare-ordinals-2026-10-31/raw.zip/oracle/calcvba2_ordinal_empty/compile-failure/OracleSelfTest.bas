Option Explicit
Private Declare PtrSafe Function NativeOrdinal Lib "kernel32" Alias "#" () As Long

Public Function RunProbe() As String
    RunProbe = "ordinal-compile-ok"
End Function
