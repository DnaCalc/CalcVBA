Public Sub FormatCell(ByVal target As Object, ByVal text As String)
    target.NumberFormat = text
End Sub
Public Function FormatInfo(ByVal target As Object) As String
    FormatInfo = target.NumberFormat
End Function
' Failed native setup sequence on owned A1:
' FormatCell(range, "$0.00"); native typed WriteValue2(range, 1.234567)
' FormatInfo returns "$0.00"; native ReadRange returns Double.
' VBA RunProbe setting that same format/value returns Currency.
' Native reads of VBA-prepared D1 also return Currency. Root cause unproved.
