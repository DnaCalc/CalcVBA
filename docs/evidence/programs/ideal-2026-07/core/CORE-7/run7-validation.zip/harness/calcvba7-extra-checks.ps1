$ErrorActionPreference='Stop'
$PSNativeCommandUseErrorActionPreference=$true
Set-Location C:/Work/DnaCalc/OxVba
$env:CARGO_BUILD_JOBS='2'
$env:CARGO_PROFILE_TEST_DEBUG='0'
cargo fmt --all --check
cargo clippy --workspace --all-targets -- -D warnings *> artifacts/calcvba7/clippy-final.log
cargo test -p oxvba-embed --no-default-features *> artifacts/calcvba7/no-jit.log
cargo check -p calcvba-host-api -p oxvba-embed --no-default-features --target wasm32-unknown-unknown *> artifacts/calcvba7/wasm-check.log
$env:MIRIFLAGS='-Zmiri-strict-provenance'
cargo +nightly miri test -p calcvba-host-api native_unknown_prefix_retains_the_exact_object_until_last_release *> artifacts/calcvba7/miri-prefix-final.log
cargo +nightly miri test -p oxvba-embed --no-default-features --test typed_host_callbacks -- --test-threads=1 *> artifacts/calcvba7/miri-callbacks-final.log
Remove-Item Env:MIRIFLAGS
cargo run --release -p oxvba-embed --example host_call_cost *> artifacts/calcvba7/host-call-cost.log
Get-FileHash target/release/examples/host_call_cost.exe -Algorithm SHA256 | ConvertTo-Json > artifacts/calcvba7/host-call-cost-executable.json
cargo test -p oxvba-embed --test native_host --no-run --message-format=json > artifacts/calcvba7/native-final-build.jsonl
$artifact=Get-Content artifacts/calcvba7/native-final-build.jsonl | ConvertFrom-Json | Where-Object {$_.reason -eq 'compiler-artifact' -and $_.target.name -eq 'native_host' -and $_.executable} | Select-Object -Last 1
./scripts/run-worksheet-errors-oracle.ps1 -RunId calcvba7-final-source-range -RuntimeTestExecutable $artifact.executable -RuntimeTestName host_injected_owned_excel_range_uses_default_without_losing_identity *> artifacts/calcvba7/live-range-final.log
rustc -Vv > artifacts/calcvba7/rust-version.txt
cargo -V >> artifacts/calcvba7/rust-version.txt
cargo +nightly miri --version >> artifacts/calcvba7/rust-version.txt
$os=Get-CimInstance Win32_OperatingSystem
$cpu=Get-CimInstance Win32_Processor | Select-Object -First 1
[ordered]@{utc=[DateTime]::UtcNow.ToString('o');os=$os.Caption;version=$os.Version;build=$os.BuildNumber;cpu=$cpu.Name;process_architecture=[Runtime.InteropServices.RuntimeInformation]::ProcessArchitecture.ToString();cargo_jobs=2;test_debug=0;registry_changes_permitted=$false} | ConvertTo-Json > artifacts/calcvba7/environment.json
Get-Content artifacts/calcvba7/host-call-cost.log -Tail 6
Get-Content artifacts/calcvba7/miri-callbacks-final.log -Tail 4
Get-Content artifacts/calcvba7/live-range-final.log -Tail 3

'extra checks complete' | Set-Content artifacts/calcvba7/extra-complete.txt -Encoding utf8NoBOM
