from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, re, subprocess, sys, zipfile

root = Path.cwd()
base = root / 'temp/calcvba15/oracle'
evidence = root / 'docs/evidence/programs/ideal-2026-07/windows-x64/WIN-5'
check_path = Path(sys.argv[1])
check = check_path.read_text(encoding='utf-8-sig')
check_complete = '[oxvba] meta check complete' in check
assert check_complete or '--allow-incomplete-check' in sys.argv[2:]
counts = [tuple(map(int, pair)) for pair in re.findall(r'test result: ok\. (\d+) passed; \d+ failed; (\d+) ignored;', check)]
assert counts
catalog = json.loads((root/'crates/oxvba-embed/tests/support/xlsm/cases.json').read_text(encoding='utf8'))
cases = [c['id'] for c in catalog if c['id'] != 'enum-constants']
assert len(cases) >= 25 and len(cases) == len(set(cases))

def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

selected = {}
for path in sorted(base.glob('run15-*/results.json'), key=lambda p: p.stat().st_mtime):
    result = read(path)
    if not result.get('passed') or not (path.parent/'transcript.json').is_file():
        continue
    for case in cases:
        if (path.parent/'windows-scalar-interop'/f'{case}.xlsm').is_file() or (path.parent/'runtime-unhandled-modal'/f'{case}.xlsm').is_file():
            # Final m binary only; no earlier binary contributes passing credit.
            directory = path.parent / result['cases'][0]['id']
            comparisons = read(directory/'comparisons.json')
            if all(c['engine_sha256'] == sha(root/'temp/calcvba15/xlsm-m.exe') for c in comparisons):
                selected[case] = path.parent.name
assert set(selected) == set(cases), (set(cases)-set(selected))
proofs = []
runs = ['run15-m-automatic'] + [selected[c] for c in cases]
for run in runs:
    path = base/run
    result = read(path/'results.json')
    assert result['passed'] and (path/'transcript.json').is_file(), run
    case = result['cases'][0]
    assert case['cleanup_status'] == 'owned-process-zero' and case['compile_status'] == 'ok', run
    proof = dict(run=run, excel_pid=case['owned_excel_pid'], cleanup=case['cleanup_status'], run_status=case['run_status'], vba_return=case['run_value'])
    directory = path/case['id']
    if run == 'run15-m-automatic':
        engine = read(directory/'engine-automatic-test.json')
        assert engine['exit_code'] == 0
        log = (directory/'engine-automatic-test.log').read_text(encoding='utf-8-sig')
        assert 'Interpreter native idle event: 1:DZ1;' in log and 'Jit native idle event: 1:DZ1;' in log
        proof['engine'] = engine
    else:
        identity = next(c for c, r in selected.items() if r == run)
        comparisons = read(directory/'comparisons.json')
        assert len(comparisons) == 2 and {c['backend'] for c in comparisons} == {'vm3', 'jit'}
        assert all(c['returned_value_equal'] and c['all_used_cells_equal'] and c['exit_code'] == 0 for c in comparisons)
        snapshot = read(directory/'project.json')
        assert snapshot['name'] == 'VBAProject'
        config = next((c for c in catalog if c['id'] == identity), {})
        fixtures = root/'crates/oxvba-embed/tests/support'
        expected = {'Api': fixtures/('automatic/Api.bas' if identity in ['events','mixed'] else 'application/Api.bas' if identity == 'application' else 'xlsm/'+identity+'-entry.bas')}
        if identity in ['events', 'mixed']:
            expected.update({name: fixtures/'automatic'/file for name, file in [('Watcher','Watcher.cls'),('Sheet1','Sheet1.cls'),('ThisWorkbook','ThisWorkbook.cls')]})
        if identity in ['chains', 'mixed']: expected['ChainOps'] = fixtures/'excel_chains.bas'
        if identity == 'mixed': expected['WorkbookMain'] = fixtures/'xlsm/mixed-entry.bas'
        if identity == 'application': expected.update({'AppWatcher': fixtures/'application/AppWatcher.cls', 'ThisWorkbook': fixtures/'application/ThisWorkbook.cls'})
        expected.update({name: fixtures/'xlsm'/file for name, file in config.get('documents', {}).items()})
        expected.update({extra['name']: fixtures/'xlsm'/extra['file'] for extra in config.get('extras', [])})
        assert set(expected).issubset({module['name'] for module in snapshot['modules']}), identity
        assert all(not reference['broken'] for reference in snapshot['references']), identity
        def normalize(text):
            return text.replace('\r\n','\n').rstrip('\n')
        def identifier_case_only(text):
            token = re.compile(r'"(?:[^"\n]|"")*"|\x27[^\n]*|\bRem[ \t][^\n]*|[A-Za-z_][A-Za-z_0-9]*', re.IGNORECASE)
            def fold(match):
                value = match.group()
                return value if value.startswith(('"', "'")) or re.match(r'(?i)Rem[ \t]', value) else value.lower()
            return token.sub(fold, normalize(text))
        recasing = []
        for module in snapshot['modules']:
            source = expected[module['name']].read_text(encoding='utf8') if module['name'] in expected else ''
            assert identifier_case_only(source) == identifier_case_only(module['source']), (identity, module['name'])
            if normalize(source) != normalize(module['source']): recasing.append(module['name'])
        cells = read(directory/'excel-cells.json')
        proof.update(workbook=identity, cells_per_backend=sum(len(s['cells']) for s in cells), comparisons=comparisons, vbe_identifier_recasing_only=recasing, module_sources={m['name']: hashlib.sha256(m['source'].encode('utf8')).hexdigest() for m in snapshot['modules']})
        package = directory/f'{identity}.xlsm'
        with zipfile.ZipFile(package) as book:
            binary = book.read('xl/vbaProject.bin')
            assert binary
            proof['vba_project_bin_sha256'] = hashlib.sha256(binary).hexdigest()
        proof['xlsm_sha256'] = sha(package)
        assert all(c['workbook_sha256'] == proof['xlsm_sha256'] for c in comparisons)
    proofs.append(proof)

paths = subprocess.check_output(['git','diff','HEAD','--name-only']).decode('utf8').splitlines()
paths += subprocess.check_output(['git','ls-files','--others','--exclude-standard']).decode('utf8').splitlines()
paths = [p for p in paths if p.endswith(('.rs','.ps1','.bas','.cls','.toml','.lock','.lean'))]
paths += ['Cargo.toml','Cargo.lock','crates/oxvba-embed/tests/support/xlsm/cases.json','crates/oxvba-embed/tests/support/owned_excel.rs']
paths += [p.relative_to(root).as_posix() for p in (root/'scripts').glob('excel-vba-oracle-*.ps1')]
paths += ['scripts/run-excel-vba-oracle.ps1','scripts/meta-check.ps1','temp/calcvba15/archive.py','temp/calcvba15/audit-owned.ps1']
paths = sorted(set(paths))
inputs = {p: sha(root/p) for p in paths}
prior = []
for path in sorted(base.glob('run15-*/results.json')):
    result = read(path)
    prior.append(dict(run=path.parent.name, passed=result.get('passed'), cases=[{k:c.get(k) for k in ['id','passed','owned_excel_pid','cleanup_status','compile_status','run_status','failure']} for c in (result.get('cases') or [])]))
audit_path = root/'temp/calcvba15/final-owned-audit.json'
audit = read(audit_path)
assert not audit['exact_live_owned_processes'] and not audit['unverified_live_processes']
manifest = dict(schema='calcvba.run15.automatic-and-xlsm.v1', created_utc=datetime.now(timezone.utc).isoformat(), base_commit=subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(), status='bounded development execution proof; broader event/carrier/workbook parity in-progress', inputs=inputs, proofs=proofs, repository_check=dict(command='scripts/meta-check.ps1 -Fast -NoArtifacts -NoRegistry', status='passed' if check_complete else 'failed on dynamic fixture; focused correction passes; full rerun pending', complete=check_complete, passed=sum(p for p,i in counts), ignored=sum(i for p,i in counts), suites=len(counts), excluded_registry_writers=4), fresh_eyes='Reviewed callback epoch/reset/reload identity, fault-before-caller-error ordering and Boolean writeback, document visibility/default Nothing, checked Preserve coordinates/type inheritance, typed UDT array projections, COM constant provenance and immutable native binaries. Native observations and targeted regressions repaired the detected mismatches; broader carrier/event refinement remains open.', formal='Installed Lean 4.29.1 DocumentEvents, RefCount, TypedReentry, TypedContinuation and ProcedureHandles pass; concrete native/array refinement and Miri unproved', prior_attempt_receipts=prior, owned_process_audit=audit)
archive = evidence/'run15-automatic-workbooks.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as output:
    for run in runs:
        for path in (base/run).rglob('*'):
            if path.is_file(): output.write(path, 'oracle/'+run+'/'+path.relative_to(base/run).as_posix())
    for path in paths: output.write(root/path, 'source/'+path)
    for directory in base.glob('run15-*'):
        if directory.is_dir() and directory.name not in runs:
            for name in ['results.json','owned-processes.jsonl','owned-helper-processes.jsonl','transcript.json']:
                item = directory/name
                if item.is_file(): output.write(item, 'prior-attempts/'+directory.name+'/'+name)
    for path in (base/'run15-final-udt-1').rglob('*'):
        if path.is_file(): output.write(path, 'detected-mismatch/udt/'+path.relative_to(base/'run15-final-udt-1').as_posix())
    for path in [check_path, audit_path, root/'temp/calcvba15/oracle-contract.log', root/'temp/calcvba15/build-environment.json', root/'temp/calcvba15/formal-document-events.log', root/'temp/calcvba15/formal-observation.json', root/'temp/calcvba15/record-carriers2.log', root/'temp/calcvba15/redim-carrier-regression.log', root/'temp/calcvba15/mixed-comparison-final.log', root/'temp/calcvba15/colon-boundary.log', root/'temp/calcvba15/unsupported-child-final.log', root/'temp/calcvba15/meta-check6.log', root/'temp/calcvba15/owning-m.log', root/'temp/calcvba15/dynamic-flags-final.log']:
        output.write(path, 'checks/'+path.name)
manifest['archive_sha256'] = sha(archive)
(evidence/'run15-automatic-workbooks.json').write_bytes((json.dumps(manifest, indent=2)+'\n').encode('utf8'))
with zipfile.ZipFile(archive) as checked:
    for path, digest in inputs.items(): assert hashlib.sha256(checked.read('source/'+path)).hexdigest() == digest
    assert checked.testzip() is None
print(manifest['repository_check'])
print('workbooks', len(cases), 'compared_cells', sum(p.get('cells_per_backend',0)*2 for p in proofs))
print('archive_sha256', manifest['archive_sha256'])
