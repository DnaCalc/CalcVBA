#![allow(unsafe_op_in_unsafe_fn)]
//! Native dynamic library loading and invocation bridge for Declare Function/Sub.
//!
//! On Windows: LoadLibraryW / GetProcAddress / stdcall invocation.
//! On Linux/macOS: dlopen / dlsym / C-ABI invocation.

use std::ffi::c_void;

#[cfg(target_os = "windows")]
use libffi::middle::{
    Arg as LibffiArg, Cif as LibffiCif, CodePtr as LibffiCodePtr, Type as LibffiType,
};
#[cfg(target_os = "windows")]
use std::collections::HashMap;
#[cfg(target_os = "windows")]
use std::sync::Mutex;

#[cfg(all(not(target_os = "windows"), not(target_os = "wasi")))]
use std::collections::HashMap;
#[cfg(all(not(target_os = "windows"), not(target_os = "wasi")))]
use std::sync::Mutex;

// ── FFI argument types ──

/// Represents a marshalled argument for a native DLL call.
#[derive(Debug, Clone)]
pub enum FfiArg {
    Long(i32),
    Integer(i16),
    Byte(u8),
    Boolean(i16),
    Double(f64),
    Single(f32),
    LongLong(i64),
    AnsiString(Vec<u8>), // null-terminated narrow string
    String(Vec<u16>),    // null-terminated wide string
    Pointer(*mut c_void),
}

/// Represents the expected return type from a native DLL call.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum FfiReturnType {
    Void,
    Long,
    Integer,
    Byte,
    Boolean,
    Double,
    Single,
    LongLong,
    LongPtr,
}

#[cfg(all(target_os = "windows", target_arch = "x86_64"))]
#[derive(Debug, Clone, Copy)]
enum PreparedX64Arg {
    Long(i32),
    Integer(i16),
    Byte(u8),
    Boolean(i16),
    Double(f64),
    Single(f32),
    LongLong(i64),
    Pointer(*mut c_void),
}

#[cfg(all(target_os = "windows", target_arch = "x86_64"))]
impl PreparedX64Arg {
    fn from_ffi_arg(arg: &FfiArg) -> Self {
        match arg {
            FfiArg::Long(v) => Self::Long(*v),
            FfiArg::Integer(v) => Self::Integer(*v),
            FfiArg::Byte(v) => Self::Byte(*v),
            FfiArg::Boolean(v) => Self::Boolean(*v),
            FfiArg::Double(v) => Self::Double(*v),
            FfiArg::Single(v) => Self::Single(*v),
            FfiArg::LongLong(v) => Self::LongLong(*v),
            FfiArg::AnsiString(v) => Self::Pointer(v.as_ptr().cast_mut().cast::<c_void>()),
            FfiArg::String(v) => Self::Pointer(v.as_ptr().cast_mut().cast::<c_void>()),
            FfiArg::Pointer(v) => Self::Pointer(*v),
        }
    }

    fn ffi_type(&self) -> LibffiType {
        match self {
            Self::Long(_) => LibffiType::i32(),
            Self::Integer(_) => LibffiType::i16(),
            Self::Byte(_) => LibffiType::u8(),
            Self::Boolean(_) => LibffiType::i16(),
            Self::Double(_) => LibffiType::f64(),
            Self::Single(_) => LibffiType::f32(),
            Self::LongLong(_) => LibffiType::i64(),
            Self::Pointer(_) => LibffiType::pointer(),
        }
    }

    fn as_arg(&self) -> LibffiArg<'_> {
        match self {
            Self::Long(v) => LibffiArg::new(v),
            Self::Integer(v) => LibffiArg::new(v),
            Self::Byte(v) => LibffiArg::new(v),
            Self::Boolean(v) => LibffiArg::new(v),
            Self::Double(v) => LibffiArg::new(v),
            Self::Single(v) => LibffiArg::new(v),
            Self::LongLong(v) => LibffiArg::new(v),
            Self::Pointer(v) => LibffiArg::new(v),
        }
    }
}

#[cfg(all(target_os = "windows", target_arch = "x86_64"))]
fn x64_return_type(return_type: FfiReturnType) -> LibffiType {
    match return_type {
        FfiReturnType::Void => LibffiType::void(),
        FfiReturnType::Long => LibffiType::i32(),
        FfiReturnType::Integer => LibffiType::i16(),
        FfiReturnType::Byte => LibffiType::u8(),
        FfiReturnType::Boolean => LibffiType::i16(),
        FfiReturnType::Double => LibffiType::f64(),
        FfiReturnType::Single => LibffiType::f32(),
        FfiReturnType::LongLong => LibffiType::i64(),
        FfiReturnType::LongPtr => LibffiType::pointer(),
    }
}

/// Shared libffi CIF-construction-and-call core, used by both the `Declare`
/// stdcall path ([`invoke_stdcall_x64`]) and the COM vtable this-call path
/// ([`crate::windows_vtable::vtable_invoke`]). Builds a Win64 CIF from each
/// argument's runtime type and calls `proc_addr` with a typed return, packing
/// the result into the raw `i64` carrier the callers interpret per
/// `return_type` (floats via `to_bits`, pointers via `as isize`).
///
/// # Safety
/// `proc_addr` must be a callable function pointer whose true ABI matches the
/// CIF this builds from `args` + `return_type`; every pointer-bearing argument
/// (string buffers borrowed from `args`, `Pointer` pins) must stay alive for the
/// duration of the call. The caller upholds the ABI/signature contract.
#[cfg(all(target_os = "windows", target_arch = "x86_64"))]
pub(crate) unsafe fn call_via_libffi(
    proc_addr: usize,
    args: &[FfiArg],
    return_type: FfiReturnType,
) -> i64 {
    // SAFETY: forwarded ABI and argument-lifetime contract above.
    unsafe { call_via_libffi_with_last_error(proc_addr, args, return_type) }.0
}

#[cfg(all(target_os = "windows", target_arch = "x86_64"))]
unsafe fn call_via_libffi_with_last_error(
    proc_addr: usize,
    args: &[FfiArg],
    return_type: FfiReturnType,
) -> (i64, u32) {
    let prepared_args: Vec<PreparedX64Arg> =
        args.iter().map(PreparedX64Arg::from_ffi_arg).collect();
    let cif = LibffiCif::new(
        prepared_args.iter().map(PreparedX64Arg::ffi_type),
        x64_return_type(return_type),
    );
    let ffi_args: Vec<LibffiArg<'_>> = prepared_args.iter().map(PreparedX64Arg::as_arg).collect();
    let code_ptr = LibffiCodePtr::from_ptr(proc_addr as *const c_void);

    let result = match return_type {
        FfiReturnType::Void => {
            cif.call::<()>(code_ptr, &ffi_args);
            0
        }
        FfiReturnType::Long => cif.call::<i32>(code_ptr, &ffi_args) as i64,
        FfiReturnType::Integer => cif.call::<i16>(code_ptr, &ffi_args) as i64,
        FfiReturnType::Byte => cif.call::<u8>(code_ptr, &ffi_args) as i64,
        FfiReturnType::Boolean => cif.call::<i16>(code_ptr, &ffi_args) as i64,
        FfiReturnType::Double => cif.call::<f64>(code_ptr, &ffi_args).to_bits() as i64,
        FfiReturnType::Single => cif.call::<f32>(code_ptr, &ffi_args).to_bits() as i64,
        FfiReturnType::LongLong => cif.call::<i64>(code_ptr, &ffi_args),
        FfiReturnType::LongPtr => cif.call::<*mut c_void>(code_ptr, &ffi_args) as isize as i64,
    };
    // SAFETY: GetLastError reads this thread's OS error state. Capture before
    // CIF/argument cleanup, whose allocator calls may change that state.
    let last_error = unsafe { GetLastError() };
    (result, last_error)
}

#[cfg(all(target_os = "windows", target_arch = "x86_64"))]
unsafe fn invoke_stdcall_x64(proc_addr: usize, args: &[FfiArg], return_type: FfiReturnType) -> i64 {
    // SAFETY: forwarded caller contract — invoke_stdcall_x64's own callers
    // uphold the ABI/signature + argument-lifetime invariants call_via_libffi
    // requires (documented on its `# Safety`); this is a pure extraction of the
    // former inline body with identical behavior.
    unsafe { call_via_libffi(proc_addr, args, return_type) }
}

// ══════════════════════════════════════════════════════════════════════
// Windows implementation
// ══════════════════════════════════════════════════════════════════════

#[cfg(target_os = "windows")]
struct DllCache {
    modules: HashMap<String, usize>, // library name -> HMODULE as usize
}

#[cfg(target_os = "windows")]
static DLL_CACHE: Mutex<Option<DllCache>> = Mutex::new(None);

#[cfg(target_os = "windows")]
// SAFETY: these declarations transcribe the documented Win32 ABI signatures of the
// kernel32 exports (LoadLibraryW/GetModuleHandleW/GetProcAddress and the
// WideCharToMultiByte/MultiByteToWideChar code-page converters) exactly.
unsafe extern "system" {
    fn GetLastError() -> u32;
    fn LoadLibraryW(lp_lib_file_name: *const u16) -> *mut c_void;
    fn FreeLibrary(h_module: *mut c_void) -> i32;
    fn GetModuleHandleW(lp_module_name: *const u16) -> *mut c_void;
    fn GetProcAddress(h_module: *mut c_void, lp_proc_name: *const u8) -> *mut c_void;
    fn WideCharToMultiByte(
        CodePage: u32,
        dwFlags: u32,
        lpWideCharStr: *const u16,
        cchWideChar: i32,
        lpMultiByteStr: *mut u8,
        cbMultiByte: i32,
        lpDefaultChar: *const u8,
        lpUsedDefaultChar: *mut i32,
    ) -> i32;
    fn MultiByteToWideChar(
        CodePage: u32,
        dwFlags: u32,
        lpMultiByteStr: *const u8,
        cbMultiByte: i32,
        lpWideCharStr: *mut u16,
        cchWideChar: i32,
    ) -> i32;
}

#[cfg(target_os = "windows")]
const CP_ACP: u32 = 0;

// ── Public API (Windows) ──

/// One owned Windows loader reference. Keep it alive while using its exports.
#[cfg(target_os = "windows")]
#[derive(Debug)]
pub struct OwnedLibrary(usize);

#[cfg(target_os = "windows")]
impl OwnedLibrary {
    pub fn load(library: &str) -> Result<Self, String> {
        for candidate in windows_library_candidates(library) {
            let wide: Vec<u16> = candidate.encode_utf16().chain(std::iter::once(0)).collect();
            // SAFETY: the terminated UTF-16 name is live for LoadLibraryW. A
            // successful call acquires one reference, including already loaded DLLs.
            let handle = unsafe { LoadLibraryW(wide.as_ptr()) };
            if !handle.is_null() {
                return Ok(Self(handle as usize));
            }
        }
        Err(format!("LoadLibraryW failed for `{library}`"))
    }

    pub fn handle(&self) -> usize {
        self.0
    }
}

#[cfg(target_os = "windows")]
impl Drop for OwnedLibrary {
    fn drop(&mut self) {
        // SAFETY: this value owns exactly the loader reference acquired by load.
        // Users keep the owner alive for every call through one of its exports.
        unsafe { FreeLibrary(self.0 as *mut c_void) };
    }
}

/// Loads a DLL by name. Returns an opaque module handle.
/// The module is cached so subsequent loads of the same DLL are fast.
#[cfg(target_os = "windows")]
pub fn load_library(library: &str) -> Result<usize, String> {
    let mut guard = DLL_CACHE
        .lock()
        .map_err(|_| "DLL cache lock poisoned".to_string())?;
    let cache = guard.get_or_insert_with(|| DllCache {
        modules: HashMap::new(),
    });

    let key = library.to_ascii_lowercase();
    if let Some(&handle) = cache.modules.get(&key) {
        return Ok(handle);
    }

    for candidate in windows_library_candidates(library) {
        let wide: Vec<u16> = candidate.encode_utf16().chain(std::iter::once(0)).collect();
        // SAFETY: `wide` is a NUL-terminated UTF-16 buffer built just above and alive
        // across the call; GetModuleHandleW only reads it and returns null on failure
        // (checked below).
        let existing = unsafe { GetModuleHandleW(wide.as_ptr()) };
        if !existing.is_null() {
            let handle_val = existing as usize;
            cache.modules.insert(key, handle_val);
            return Ok(handle_val);
        }
    }

    for candidate in windows_library_candidates(library) {
        let wide: Vec<u16> = candidate.encode_utf16().chain(std::iter::once(0)).collect();
        // SAFETY: `wide` is a NUL-terminated UTF-16 buffer built just above and alive
        // across the call; LoadLibraryW only reads it and returns null on failure
        // (checked below).
        let handle = unsafe { LoadLibraryW(wide.as_ptr()) };
        if !handle.is_null() {
            let handle_val = handle as usize;
            cache.modules.insert(key, handle_val);
            return Ok(handle_val);
        }
    }
    Err(format!("LoadLibraryW failed for `{}`", library))
}

#[cfg(target_os = "windows")]
fn windows_library_candidates(library: &str) -> Vec<String> {
    let trimmed = library.trim();
    if trimmed.is_empty() {
        return Vec::new();
    }
    let mut out = vec![trimmed.to_string()];
    if !trimmed.contains(['\\', '/']) && !trimmed.contains('.') {
        out.push(format!("{trimmed}.dll"));
    }
    out
}

#[cfg(target_os = "windows")]
pub fn ansi_c_string(text: &str) -> Vec<u8> {
    if text.is_empty() {
        return vec![0];
    }

    let wide: Vec<u16> = text.encode_utf16().collect();
    // SAFETY: `wide` is valid for `wide.len()` UTF-16 units for the duration of the
    // call, and a null output buffer with length 0 is the documented size-query mode
    // of WideCharToMultiByte (nothing is written).
    let required = unsafe {
        WideCharToMultiByte(
            CP_ACP,
            0,
            wide.as_ptr(),
            wide.len() as i32,
            std::ptr::null_mut(),
            0,
            std::ptr::null(),
            std::ptr::null_mut(),
        )
    };
    if required <= 0 {
        let mut fallback = text.as_bytes().to_vec();
        fallback.push(0);
        return fallback;
    }

    let mut bytes = vec![0u8; required as usize + 1];
    // SAFETY: `wide` is valid for `wide.len()` UTF-16 units and `bytes` was allocated
    // just above with `required + 1` bytes, so the `required`-byte output window the
    // converter may write is in bounds.
    let written = unsafe {
        WideCharToMultiByte(
            CP_ACP,
            0,
            wide.as_ptr(),
            wide.len() as i32,
            bytes.as_mut_ptr(),
            required,
            std::ptr::null(),
            std::ptr::null_mut(),
        )
    };
    if written <= 0 {
        let mut fallback = text.as_bytes().to_vec();
        fallback.push(0);
        return fallback;
    }
    bytes.truncate(written as usize + 1);
    bytes[written as usize] = 0;
    bytes
}

/// Decode system-codepage (CP_ACP) ANSI bytes to UTF-16 units — the inverse of
/// [`ansi_c_string`]. Embedded NULs are preserved (the byte length, not a NUL
/// scan, bounds the conversion), matching how VBA converts a `Declare` call's
/// ANSI string buffer back to Unicode at its full length.
#[cfg(target_os = "windows")]
pub fn utf16_from_ansi(bytes: &[u8]) -> Vec<u16> {
    if bytes.is_empty() {
        return Vec::new();
    }
    let len = i32::try_from(bytes.len()).unwrap_or(i32::MAX);
    // SAFETY: `bytes` is valid for `len` bytes (`len` is clamped to at most
    // `bytes.len()`), and a null output buffer with length 0 is the documented
    // size-query mode of MultiByteToWideChar (nothing is written).
    let required =
        unsafe { MultiByteToWideChar(CP_ACP, 0, bytes.as_ptr(), len, std::ptr::null_mut(), 0) };
    if required <= 0 {
        // Degenerate conversion failure: fall back to a Latin-1 widening so the
        // caller still gets a string of the right length.
        return bytes.iter().map(|b| u16::from(*b)).collect();
    }
    let mut units = vec![0u16; required as usize];
    // SAFETY: `bytes` is valid for `len` bytes and `units` was allocated just above
    // with exactly `required` u16 slots, so the output window passed to the converter
    // is in bounds.
    let written = unsafe {
        MultiByteToWideChar(CP_ACP, 0, bytes.as_ptr(), len, units.as_mut_ptr(), required)
    };
    if written <= 0 {
        return bytes.iter().map(|b| u16::from(*b)).collect();
    }
    units.truncate(written as usize);
    units
}

/// Resolves a function address from a loaded module.
#[cfg(target_os = "windows")]
pub fn get_proc_address(module: usize, name: &str) -> Result<usize, String> {
    let name_bytes: Vec<u8> = name.bytes().chain(std::iter::once(0)).collect();
    // SAFETY: callers retain an OwnedLibrary or a process-cached load_library
    // reference for this lookup and subsequent invocation; `name_bytes` is a
    // NUL-terminated buffer alive across the call that GetProcAddress only reads.
    let addr = unsafe { GetProcAddress(module as *mut c_void, name_bytes.as_ptr()) };
    if addr.is_null() {
        return Err(format!(
            "GetProcAddress failed for `{}` in module 0x{:X}",
            name, module
        ));
    }
    Ok(addr as usize)
}

/// Resolves a function by ordinal from a loaded module.
#[cfg(target_os = "windows")]
pub fn get_proc_address_ordinal(module: usize, ordinal: u16) -> Result<usize, String> {
    // SAFETY: callers retain an OwnedLibrary or process-cached loader reference
    // for the lookup and invocation; a u16 ordinal zero-extended into the
    // pointer's low word (high bits zero) is the documented GetProcAddress
    // by-ordinal lookup form, so no string is dereferenced.
    let addr = unsafe { GetProcAddress(module as *mut c_void, ordinal as usize as *const u8) };
    if addr.is_null() {
        return Err(format!(
            "GetProcAddress failed for ordinal {} in module 0x{:X}",
            ordinal, module
        ));
    }
    Ok(addr as usize)
}

/// Invokes a stdcall function and returns (raw value, Win32 LastError).
/// The x64 path snapshots the error before CIF and argument cleanup.
#[cfg(target_os = "windows")]
pub fn invoke_stdcall_with_last_error(
    proc_addr: usize,
    args: &[FfiArg],
    return_type: FfiReturnType,
) -> Result<(i64, u32), String> {
    if args.len() > 32 {
        return Err(format!(
            "too many arguments for stdcall invocation: {}",
            args.len()
        ));
    }
    #[cfg(target_arch = "x86_64")]
    {
        // SAFETY: the same resolved-export, true signature and live argument
        // storage contract as invoke_stdcall; cleanup follows the OS snapshot.
        Ok(unsafe { call_via_libffi_with_last_error(proc_addr, args, return_type) })
    }
    #[cfg(not(target_arch = "x86_64"))]
    {
        let result = invoke_stdcall(proc_addr, args, return_type)?;
        // SAFETY: reads only this thread's OS error state on the older raw path.
        Ok((result, unsafe { GetLastError() }))
    }
}

/// Invoke while discarding the captured OS error, for callers without VBA Err.
#[cfg(target_os = "windows")]
pub fn invoke_stdcall(
    proc_addr: usize,
    args: &[FfiArg],
    return_type: FfiReturnType,
) -> Result<i64, String> {
    // For safety, we limit to a reasonable argument count
    if args.len() > 32 {
        return Err(format!(
            "too many arguments for stdcall invocation: {}",
            args.len()
        ));
    }

    #[cfg(target_arch = "x86_64")]
    {
        // SAFETY: `proc_addr` is an export resolved by get_proc_address from a module
        // an OwnedLibrary or the process cache keeps loaded; libffi builds the Win64 CIF from each argument's
        // actual type, and every pointer-bearing argument (AnsiString/String buffers
        // borrowed from `args`, Pointer pins per
        // docs/spec/OXVBA_POINTER_HELPERS_CONTRACT_V1.md) stays alive until this
        // consuming native call returns. That the Declare signature matches the
        // export's true ABI is the guest's contract, exactly as in VBA 7.1
        // (HAL_DECLARE_ABI_SPEC_V1).
        let result = unsafe { invoke_stdcall_x64(proc_addr, args, return_type) };
        Ok(result)
    }

    #[cfg(not(target_arch = "x86_64"))]
    {
        if let Some(message) = raw_invoke_shape_error(args, return_type) {
            return Err(message);
        }
        // Marshal arguments to raw i64 values for the call on the integer-only path.
        let mut raw_args: Vec<i64> = Vec::with_capacity(args.len());
        for arg in args {
            match arg {
                FfiArg::Long(v) => raw_args.push(*v as i64),
                FfiArg::Integer(v) => raw_args.push(*v as i64),
                FfiArg::Byte(v) => raw_args.push(*v as i64),
                FfiArg::Boolean(v) => raw_args.push(*v as i64),
                FfiArg::Double(v) => raw_args.push(v.to_bits() as i64),
                FfiArg::Single(v) => raw_args.push(v.to_bits() as i64),
                FfiArg::LongLong(v) => raw_args.push(*v),
                FfiArg::AnsiString(v) => raw_args.push(v.as_ptr() as i64),
                FfiArg::String(v) => raw_args.push(v.as_ptr() as i64),
                FfiArg::Pointer(v) => raw_args.push(*v as i64),
            }
        }
        // SAFETY: raw_invoke_shape_error rejected (above) every shape the i64
        // register dispatch cannot express (float lanes, arity > 6); `proc_addr` is
        // an export resolved by get_proc_address from a module load_library keeps
        // loaded, and all pointer-bearing arguments (string buffers in `args`, helper
        // pins per docs/spec/OXVBA_POINTER_HELPERS_CONTRACT_V1.md) outlive the call.
        // The Declare signature matching the export's true ABI is the guest's
        // contract, exactly as in VBA 7.1 (HAL_DECLARE_ABI_SPEC_V1).
        let result = unsafe { invoke_stdcall_raw(proc_addr, &raw_args, return_type) };
        Ok(result)
    }
}

/// Shape guard for the raw (non-libffi) invocation paths: floating-point
/// argument/return lanes and arities beyond the 6 register-passed integer
/// slots cannot be expressed by the i64 transmute dispatch — on SysV
/// x86_64/AArch64 floats travel in vector registers and extra arguments on
/// the stack, so calling anyway computes garbage or worse. Fail
/// deterministically instead (HAL_DECLARE_ABI_SPEC_V1: invalid shapes fail
/// with no UB and no silent coercion). The libffi path (Windows x86_64) has
/// none of these limits; extending libffi to all targets is the tracked
/// follow-up in POST_CLEANUP.md.
#[cfg_attr(all(target_os = "windows", target_arch = "x86_64"), allow(dead_code))]
fn raw_invoke_shape_error(args: &[FfiArg], return_type: FfiReturnType) -> Option<String> {
    if args.len() > 6 {
        return Some(format!(
            "native call with {} arguments is not supported on this platform's raw FFI path \
             (integer-register dispatch handles at most 6)",
            args.len()
        ));
    }
    if args
        .iter()
        .any(|a| matches!(a, FfiArg::Double(_) | FfiArg::Single(_)))
    {
        return Some(
            "floating-point Declare arguments are not supported on this platform's raw FFI path"
                .into(),
        );
    }
    if matches!(return_type, FfiReturnType::Double | FfiReturnType::Single) {
        return Some(
            "floating-point Declare returns are not supported on this platform's raw FFI path"
                .into(),
        );
    }
    None
}

/// Raw stdcall invocation. This dispatches based on argument count
/// for the register-passed arities; larger calls are rejected by
/// [`raw_invoke_shape_error`] before reaching here.
#[cfg(target_os = "windows")]
#[cfg(not(target_arch = "x86_64"))]
unsafe fn invoke_stdcall_raw(proc_addr: usize, args: &[i64], _return_type: FfiReturnType) -> i64 {
    // On x86_64 Windows, the calling convention is actually __fastcall (first 4 args in registers).
    // We handle common arities explicitly for safety.
    type Fn0 = unsafe extern "system" fn() -> i64;
    type Fn1 = unsafe extern "system" fn(i64) -> i64;
    type Fn2 = unsafe extern "system" fn(i64, i64) -> i64;
    type Fn3 = unsafe extern "system" fn(i64, i64, i64) -> i64;
    type Fn4 = unsafe extern "system" fn(i64, i64, i64, i64) -> i64;
    type Fn5 = unsafe extern "system" fn(i64, i64, i64, i64, i64) -> i64;
    type Fn6 = unsafe extern "system" fn(i64, i64, i64, i64, i64, i64) -> i64;

    let f = proc_addr;
    match args.len() {
        0 => std::mem::transmute::<usize, Fn0>(f)(),
        1 => std::mem::transmute::<usize, Fn1>(f)(args[0]),
        2 => std::mem::transmute::<usize, Fn2>(f)(args[0], args[1]),
        3 => std::mem::transmute::<usize, Fn3>(f)(args[0], args[1], args[2]),
        4 => std::mem::transmute::<usize, Fn4>(f)(args[0], args[1], args[2], args[3]),
        5 => std::mem::transmute::<usize, Fn5>(f)(args[0], args[1], args[2], args[3], args[4]),
        6 => std::mem::transmute::<usize, Fn6>(f)(
            args[0], args[1], args[2], args[3], args[4], args[5],
        ),
        // INVARIANT: raw_invoke_shape_error rejected arity > 6 before this call.
        _ => unreachable!("raw stdcall dispatch guarded to at most 6 arguments"),
    }
}

// ══════════════════════════════════════════════════════════════════════
// Linux / macOS implementation (dlopen / dlsym / C-ABI)
// ══════════════════════════════════════════════════════════════════════

#[cfg(all(not(target_os = "windows"), not(target_os = "wasi")))]
struct SoCache {
    modules: HashMap<String, usize>, // library name -> dlopen handle as usize
}

#[cfg(all(not(target_os = "windows"), not(target_os = "wasi")))]
static SO_CACHE: Mutex<Option<SoCache>> = Mutex::new(None);

/// Translates a VBA-style library name to a platform-appropriate shared library path.
///
/// VBA `Declare` statements reference Windows DLL names like `"kernel32"` or
/// `"user32.dll"`. On Linux/macOS we attempt a best-effort mapping:
///   - If the name already contains a path separator or a `.so` / `.dylib` suffix, use it as-is.
///   - Strip a trailing `.dll` (case-insensitive) and prepend `lib`, append `.so` (Linux)
///     or `.dylib` (macOS).
///   - For well-known system libraries (`libc`, `libm`, `libpthread`, `libdl`),
///     return the platform canonical name.
#[cfg(all(not(target_os = "windows"), not(target_os = "wasi")))]
fn translate_library_name(library: &str) -> String {
    // Already looks like a Unix shared library path
    if library.contains('/')
        || library.ends_with(".so")
        || library.ends_with(".dylib")
        || library.contains(".so.")
    {
        return library.to_string();
    }

    let base = library
        .strip_suffix(".dll")
        .or_else(|| library.strip_suffix(".DLL"))
        .or_else(|| library.strip_suffix(".Dll"))
        .unwrap_or(library);

    let lower = base.to_ascii_lowercase();

    // Well-known system library mappings
    match lower.as_str() {
        "msvcrt" | "ucrtbase" | "libc" => {
            if cfg!(target_os = "macos") {
                "libSystem.B.dylib".to_string()
            } else {
                "libc.so.6".to_string()
            }
        }
        "libm" => {
            if cfg!(target_os = "macos") {
                "libSystem.B.dylib".to_string()
            } else {
                "libm.so.6".to_string()
            }
        }
        "libpthread" | "pthread" => {
            if cfg!(target_os = "macos") {
                "libSystem.B.dylib".to_string()
            } else {
                "libpthread.so.0".to_string()
            }
        }
        "libdl" | "dl" => {
            if cfg!(target_os = "macos") {
                "libSystem.B.dylib".to_string()
            } else {
                "libdl.so.2".to_string()
            }
        }
        _ => {
            let ext = if cfg!(target_os = "macos") {
                "dylib"
            } else {
                "so"
            };
            // Prepend "lib" if not already present
            if lower.starts_with("lib") {
                format!("{}.{}", base, ext)
            } else {
                format!("lib{}.{}", base, ext)
            }
        }
    }
}

/// Returns the last dlopen/dlsym error as a String, or a generic message.
#[cfg(all(not(target_os = "windows"), not(target_os = "wasi")))]
fn dlerror_string() -> String {
    // SAFETY: dlerror takes no arguments and returns either null or a pointer to the
    // thread's pending NUL-terminated error string; calling it is always sound.
    let err = unsafe { libc::dlerror() };
    if err.is_null() {
        "unknown dl error".to_string()
    } else {
        // SAFETY: `err` was checked non-null above, and dlerror's string stays valid
        // until the next dl* call on this thread; it is copied out immediately below
        // (`into_owned`) before any further dl* call can occur.
        let cstr = unsafe { std::ffi::CStr::from_ptr(err) };
        cstr.to_string_lossy().into_owned()
    }
}

/// Loads a shared library by name using `dlopen`. Returns an opaque module handle.
/// The module is cached so subsequent loads of the same library are fast.
///
/// The library name is translated from VBA/Windows conventions to Unix conventions:
/// e.g. `"mylib.dll"` becomes `"libmylib.so"` on Linux or `"libmylib.dylib"` on macOS.
#[cfg(all(not(target_os = "windows"), not(target_os = "wasi")))]
pub fn load_library(library: &str) -> Result<usize, String> {
    let mut guard = SO_CACHE
        .lock()
        .map_err(|_| "shared library cache lock poisoned".to_string())?;
    let cache = guard.get_or_insert_with(|| SoCache {
        modules: HashMap::new(),
    });

    let key = library.to_ascii_lowercase();
    if let Some(&handle) = cache.modules.get(&key) {
        return Ok(handle);
    }

    let translated = translate_library_name(library);
    let c_name = std::ffi::CString::new(translated.as_str())
        .map_err(|_| format!("library name `{}` contains null byte", library))?;

    // Clear any prior error
    // SAFETY: dlerror takes no arguments and only reads/clears the thread's pending
    // dl error state; calling it is always sound.
    unsafe {
        libc::dlerror();
    }

    // SAFETY: `c_name` is a live NUL-terminated CString that outlives the call;
    // dlopen only reads it and returns null on failure (checked below).
    let handle = unsafe { libc::dlopen(c_name.as_ptr(), libc::RTLD_NOW | libc::RTLD_LOCAL) };
    if handle.is_null() {
        let err = dlerror_string();
        return Err(format!(
            "dlopen failed for `{}` (translated to `{}`): {}",
            library, translated, err
        ));
    }
    let handle_val = handle as usize;
    cache.modules.insert(key, handle_val);
    Ok(handle_val)
}

/// Resolves a function address from a loaded module using `dlsym`.
#[cfg(target_os = "wasi")]
pub fn load_library(library: &str) -> Result<usize, String> {
    Err(format!(
        "dynamic library loading is not available on wasm32/WASI for `{library}`"
    ))
}

#[cfg(all(not(target_os = "windows"), not(target_os = "wasi")))]
pub fn get_proc_address(module: usize, name: &str) -> Result<usize, String> {
    let c_name = std::ffi::CString::new(name)
        .map_err(|_| format!("symbol name `{}` contains null byte", name))?;

    // Clear any prior error
    // SAFETY: dlerror takes no arguments and only reads/clears the thread's pending
    // dl error state; calling it is always sound.
    unsafe {
        libc::dlerror();
    }

    // SAFETY: callers obtain `module` from load_library, whose cache never
    // dlclose's handles, so the dlopen handle stays live; `c_name` is a live
    // NUL-terminated CString that dlsym only reads.
    let addr = unsafe { libc::dlsym(module as *mut c_void, c_name.as_ptr()) };
    if addr.is_null() {
        let err = dlerror_string();
        return Err(format!(
            "dlsym failed for `{}` in module 0x{:X}: {}",
            name, module, err
        ));
    }
    Ok(addr as usize)
}

/// Ordinal-based symbol resolution is not supported on Unix platforms.
/// Shared libraries on Linux/macOS do not use ordinal exports.
#[cfg(target_os = "wasi")]
pub fn get_proc_address(_module: usize, name: &str) -> Result<usize, String> {
    Err(format!(
        "dynamic symbol lookup is not available on wasm32/WASI for `{name}`"
    ))
}

#[cfg(not(target_os = "windows"))]
pub fn get_proc_address_ordinal(_module: usize, ordinal: u16) -> Result<usize, String> {
    Err(format!(
        "ordinal-based symbol resolution (ordinal {}) is not supported on Unix platforms; \
         use named symbol exports instead",
        ordinal
    ))
}

/// Invokes a C-ABI function pointer with the given arguments.
/// Returns the raw i64 return value (caller interprets based on return type).
///
/// On Linux/macOS the platform calling convention is the System V AMD64 ABI (on x86_64)
/// or the standard C ABI on other architectures. We use `extern "C"` function pointer
/// transmutes over integer-register arguments only; shapes the dispatch cannot express
/// (floating-point lanes, arity > 6) are rejected deterministically by
/// [`raw_invoke_shape_error`] rather than miscalled.
#[cfg(not(target_os = "windows"))]
pub fn invoke_stdcall(
    proc_addr: usize,
    args: &[FfiArg],
    return_type: FfiReturnType,
) -> Result<i64, String> {
    if let Some(message) = raw_invoke_shape_error(args, return_type) {
        return Err(message);
    }

    let mut raw_args: Vec<i64> = Vec::with_capacity(args.len());
    for arg in args {
        match arg {
            FfiArg::Long(v) => raw_args.push(*v as i64),
            FfiArg::Integer(v) => raw_args.push(*v as i64),
            FfiArg::Byte(v) => raw_args.push(*v as i64),
            FfiArg::Boolean(v) => raw_args.push(*v as i64),
            FfiArg::Double(v) => raw_args.push(v.to_bits() as i64),
            FfiArg::Single(v) => raw_args.push(v.to_bits() as i64),
            FfiArg::LongLong(v) => raw_args.push(*v),
            FfiArg::AnsiString(v) => raw_args.push(v.as_ptr() as i64),
            FfiArg::String(v) => raw_args.push(v.as_ptr() as i64),
            FfiArg::Pointer(v) => raw_args.push(*v as i64),
        }
    }

    // SAFETY: raw_invoke_shape_error rejected (above) every shape the i64 register
    // dispatch cannot express (float lanes, arity > 6); `proc_addr` is a symbol
    // resolved by get_proc_address from a handle load_library keeps open, and all
    // pointer-bearing arguments (string buffers in `args`, helper pins per
    // docs/spec/OXVBA_POINTER_HELPERS_CONTRACT_V1.md) outlive the call. The Declare
    // signature matching the symbol's true C ABI is the guest's contract, exactly as
    // in VBA 7.1 (HAL_DECLARE_ABI_SPEC_V1).
    let result = unsafe { invoke_c_abi_raw(proc_addr, &raw_args, return_type) };
    Ok(result)
}

/// Raw C-ABI invocation using `extern "C"` function pointers.
/// Dispatches based on argument count for common arities.
#[cfg(not(target_os = "windows"))]
unsafe fn invoke_c_abi_raw(proc_addr: usize, args: &[i64], _return_type: FfiReturnType) -> i64 {
    type Fn0 = unsafe extern "C" fn() -> i64;
    type Fn1 = unsafe extern "C" fn(i64) -> i64;
    type Fn2 = unsafe extern "C" fn(i64, i64) -> i64;
    type Fn3 = unsafe extern "C" fn(i64, i64, i64) -> i64;
    type Fn4 = unsafe extern "C" fn(i64, i64, i64, i64) -> i64;
    type Fn5 = unsafe extern "C" fn(i64, i64, i64, i64, i64) -> i64;
    type Fn6 = unsafe extern "C" fn(i64, i64, i64, i64, i64, i64) -> i64;

    let f = proc_addr;
    match args.len() {
        0 => std::mem::transmute::<usize, Fn0>(f)(),
        1 => std::mem::transmute::<usize, Fn1>(f)(args[0]),
        2 => std::mem::transmute::<usize, Fn2>(f)(args[0], args[1]),
        3 => std::mem::transmute::<usize, Fn3>(f)(args[0], args[1], args[2]),
        4 => std::mem::transmute::<usize, Fn4>(f)(args[0], args[1], args[2], args[3]),
        5 => std::mem::transmute::<usize, Fn5>(f)(args[0], args[1], args[2], args[3], args[4]),
        6 => std::mem::transmute::<usize, Fn6>(f)(
            args[0], args[1], args[2], args[3], args[4], args[5],
        ),
        // INVARIANT: raw_invoke_shape_error rejected arity > 6 before this call.
        _ => unreachable!("raw C-ABI dispatch guarded to at most 6 arguments"),
    }
}

// ══════════════════════════════════════════════════════════════════════
// Tests
// ══════════════════════════════════════════════════════════════════════

#[cfg(test)]
#[cfg(target_os = "windows")]
mod tests {
    use super::*;

    #[test]
    fn load_kernel32_and_resolve_get_tick_count() {
        let module = load_library("kernel32.dll").expect("kernel32.dll should load");
        assert!(module != 0, "module handle should be non-zero");
        let addr = get_proc_address(module, "GetTickCount").expect("GetTickCount should resolve");
        assert!(addr != 0, "proc address should be non-zero");
    }

    #[test]
    fn invoke_get_tick_count_returns_nonzero() {
        let module = load_library("kernel32.dll").expect("kernel32.dll should load");
        let addr = get_proc_address(module, "GetTickCount").expect("GetTickCount should resolve");
        let result = invoke_stdcall(addr, &[], FfiReturnType::Long).expect("invoke should succeed");
        assert!(result > 0, "GetTickCount should return positive value");
    }

    #[test]
    fn invoke_msvcrt_sqrt_round_trips_double_argument_and_return() {
        let module = load_library("msvcrt.dll").expect("msvcrt.dll should load");
        let addr = get_proc_address(module, "sqrt").expect("sqrt should resolve");
        let result = invoke_stdcall(addr, &[FfiArg::Double(156.25)], FfiReturnType::Double)
            .expect("invoke should succeed");
        let value = f64::from_bits(result as u64);
        assert!(
            (value - 12.5).abs() < 1.0e-10,
            "sqrt should round-trip the double lane; got {value}"
        );
    }

    #[test]
    fn raw_shape_guard_rejects_floats_and_large_arity() {
        // W1-com-006: the raw (non-libffi) paths must reject the shapes their
        // i64 transmute dispatch cannot express, not miscall with a wrong ABI.
        assert!(raw_invoke_shape_error(&[FfiArg::Double(1.0)], FfiReturnType::Long).is_some());
        assert!(raw_invoke_shape_error(&[FfiArg::Single(1.0)], FfiReturnType::Long).is_some());
        assert!(raw_invoke_shape_error(&[], FfiReturnType::Double).is_some());
        assert!(raw_invoke_shape_error(&[], FfiReturnType::Single).is_some());
        let seven: Vec<FfiArg> = (0..7).map(|_| FfiArg::Long(0)).collect();
        assert!(raw_invoke_shape_error(&seven, FfiReturnType::Long).is_some());
        let six: Vec<FfiArg> = (0..6).map(|_| FfiArg::Long(0)).collect();
        assert!(raw_invoke_shape_error(&six, FfiReturnType::Long).is_none());
        assert!(
            raw_invoke_shape_error(
                &[FfiArg::LongLong(1), FfiArg::Boolean(0)],
                FfiReturnType::Void
            )
            .is_none()
        );
    }

    #[test]
    fn invoke_msvcrt_wcstod_round_trips_double_return_with_pointer_arguments() {
        let module = load_library("msvcrt.dll").expect("msvcrt.dll should load");
        let addr = get_proc_address(module, "wcstod").expect("wcstod should resolve");
        let text: Vec<u16> = "123.5".encode_utf16().chain(std::iter::once(0)).collect();
        let result = invoke_stdcall(
            addr,
            &[
                FfiArg::Pointer(text.as_ptr().cast_mut().cast::<c_void>()),
                FfiArg::Pointer(std::ptr::null_mut()),
            ],
            FfiReturnType::Double,
        )
        .expect("invoke should succeed");
        let value = f64::from_bits(result as u64);
        assert!(
            (value - 123.5).abs() < 1.0e-10,
            "wcstod should round-trip the double return lane; got {value}"
        );
    }

    #[test]
    fn invoke_msvcrt_memmove_writes_through_pointer_arguments() {
        let module = load_library("msvcrt.dll").expect("msvcrt.dll should load");
        let addr = get_proc_address(module, "memmove").expect("memmove should resolve");
        let src: i32 = 0x11223344;
        let mut dst: i32 = 0;
        let result = invoke_stdcall(
            addr,
            &[
                FfiArg::Pointer((&mut dst as *mut i32).cast::<c_void>()),
                FfiArg::Pointer((&src as *const i32).cast_mut().cast::<c_void>()),
                FfiArg::LongLong(4),
            ],
            FfiReturnType::LongPtr,
        )
        .expect("invoke should succeed");
        assert_eq!(result as usize, (&mut dst as *mut i32) as usize);
        assert_eq!(dst, 0x11223344);
    }

    #[test]
    fn load_library_caches_modules() {
        let h1 = load_library("kernel32.dll").expect("first load");
        let h2 = load_library("kernel32.dll").expect("second load");
        assert_eq!(h1, h2, "same module should return same handle");
    }
}

#[cfg(test)]
#[cfg(not(target_os = "windows"))]
mod tests {
    use super::*;

    #[test]
    fn translate_library_name_strips_dll_suffix() {
        let result = translate_library_name("mylib.dll");
        assert!(
            result == "libmylib.so" || result == "libmylib.dylib",
            "got: {}",
            result
        );
    }

    #[test]
    fn translate_library_name_preserves_so_suffix() {
        assert_eq!(translate_library_name("libfoo.so"), "libfoo.so");
    }

    #[test]
    fn translate_library_name_preserves_dylib_suffix() {
        assert_eq!(translate_library_name("libfoo.dylib"), "libfoo.dylib");
    }

    #[test]
    fn translate_library_name_preserves_path() {
        assert_eq!(
            translate_library_name("/usr/lib/libfoo.so"),
            "/usr/lib/libfoo.so"
        );
    }

    #[test]
    fn translate_library_name_maps_msvcrt_to_libc() {
        let result = translate_library_name("msvcrt");
        assert!(
            result == "libc.so.6" || result == "libSystem.B.dylib",
            "got: {}",
            result
        );
    }

    #[test]
    fn translate_library_name_prepends_lib_prefix() {
        let result = translate_library_name("foo");
        assert!(
            result == "libfoo.so" || result == "libfoo.dylib",
            "got: {}",
            result
        );
    }

    #[test]
    fn translate_library_name_does_not_double_lib_prefix() {
        let result = translate_library_name("libbar");
        assert!(
            result == "libbar.so" || result == "libbar.dylib",
            "got: {}",
            result
        );
    }

    #[test]
    fn ordinal_resolution_returns_error() {
        let result = get_proc_address_ordinal(0, 42);
        assert!(result.is_err());
        assert!(result.unwrap_err().contains("ordinal"));
    }

    #[test]
    fn load_libc_and_resolve_getpid() {
        let libc_name = if cfg!(target_os = "macos") {
            "libSystem.B.dylib"
        } else {
            "libc.so.6"
        };
        let module = load_library(libc_name).expect("libc should load");
        assert!(module != 0, "module handle should be non-zero");
        let addr = get_proc_address(module, "getpid").expect("getpid should resolve");
        assert!(addr != 0, "proc address should be non-zero");
    }

    #[test]
    fn invoke_getpid_returns_positive() {
        let libc_name = if cfg!(target_os = "macos") {
            "libSystem.B.dylib"
        } else {
            "libc.so.6"
        };
        let module = load_library(libc_name).expect("libc should load");
        let addr = get_proc_address(module, "getpid").expect("getpid should resolve");
        let result = invoke_stdcall(addr, &[], FfiReturnType::Long).expect("invoke should succeed");
        assert!(result > 0, "getpid should return positive value");
    }

    #[test]
    fn load_library_caches_modules() {
        let libc_name = if cfg!(target_os = "macos") {
            "libSystem.B.dylib"
        } else {
            "libc.so.6"
        };
        let h1 = load_library(libc_name).expect("first load");
        let h2 = load_library(libc_name).expect("second load");
        assert_eq!(h1, h2, "same module should return same handle");
    }

    #[test]
    fn vba_style_msvcrt_resolves_getpid() {
        // Simulates a VBA Declare like: Declare Function getpid Lib "msvcrt" () As Long
        let module = load_library("msvcrt").expect("msvcrt (mapped to libc) should load");
        let addr = get_proc_address(module, "getpid").expect("getpid should resolve");
        assert!(addr != 0);
    }
}
