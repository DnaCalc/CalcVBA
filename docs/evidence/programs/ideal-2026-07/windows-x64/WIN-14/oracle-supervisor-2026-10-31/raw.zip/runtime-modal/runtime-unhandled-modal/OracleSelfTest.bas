Option Explicit

Public Sub RunProbe()
100 Err.Raise 13, "OracleUnhandledRuntime", "oracle-unhandled-runtime"
End Sub
