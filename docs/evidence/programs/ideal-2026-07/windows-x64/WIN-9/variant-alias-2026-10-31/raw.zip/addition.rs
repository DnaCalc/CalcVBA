
// Primitive VARIANT alias probe: the caller supplies two writable 24-byte
// Windows x64 VARIANT cells containing only I2/I4/R8 (no owned fields).
#[repr(C)]
pub struct PrimitiveVariant {
    vt: u16,
    reserved: [u16; 3],
    data: [u64; 2],
}
const _: () = assert!(std::mem::size_of::<PrimitiveVariant>() == 24);

#[unsafe(no_mangle)]
pub unsafe extern "system" fn AliasVariant(first: *mut PrimitiveVariant, second: *mut PrimitiveVariant) -> i32 {
    // SAFETY: both pointers refer to writable caller VARIANT cells containing
    // primitive values. Raw pointer access deliberately permits aliasing. No
    // owned value is replaced; no pointer escapes this call.
    unsafe {
        first.write(PrimitiveVariant { vt: 3, reserved: [0; 3], data: [19, 0] });
        let shared = first == second && (*second).vt == 3 && (*second).data[0] == 19;
        second.write(PrimitiveVariant { vt: 5, reserved: [0; 3], data: [42.5_f64.to_bits(), 0] });
        ALIAS_CALLS.fetch_add(1, std::sync::atomic::Ordering::Relaxed);
        SetLastError(4321);
        if shared { 42 } else { -1 }
    }
}
