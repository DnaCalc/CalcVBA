from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, re, subprocess, zipfile

root = Path.cwd()
base = root / 'temp/calcvba14/oracle'
evidence = root / 'docs/evidence/programs/ideal-2026-07/windows-x64/WIN-5'
check_path = root / 'temp/run14-check-10.log'
check = check_path.read_text(encoding='utf-8-sig')
assert '[oxvba] meta check complete' in check
counts = [tuple(map(int, pair)) for pair in re.findall(r'test result: ok\. (\d+) passed; \d+ failed; (\d+) ignored;',check)]
assert counts
cases = ['chains','events','mixed','documents','arrays','bounds','application']
runs = ['run14-sealed-automatic'] + ['run14-sealed-'+case for case in cases]
proofs = []
for run in runs:
    path = base / run
    result = json.loads((path/'results.json').read_text(encoding='utf-8-sig'))
    assert result['passed'],run
    assert (path/'transcript.json').is_file(),run
    case = result['cases'][0]
    assert case['cleanup_status']=='owned-process-zero'
    assert case['compile_status']=='ok' and case['run_status']=='ok'
    proof = dict(run=run,excel_pid=case['owned_excel_pid'],cleanup=case['cleanup_status'],vba_return=case['run_value'])
    case_dir = path/'windows-scalar-interop'
    if run.endswith('automatic'):
        engine = json.loads((case_dir/'engine-automatic-test.json').read_text(encoding='utf-8-sig'))
        assert engine['exit_code']==0
        proof['engine']=engine
    else:
        comparisons = json.loads((case_dir/'comparisons.json').read_text(encoding='utf-8-sig'))
        assert len(comparisons)==2
        assert {c['backend'] for c in comparisons}=={'vm3','jit'}
        assert all(c['returned_value_equal'] and c['all_used_cells_equal'] and c['exit_code']==0 for c in comparisons)
        snapshot = json.loads((case_dir/'project.json').read_text(encoding='utf-8-sig'))
        assert snapshot['name']=='VBAProject'
        fixture_root=root/'crates/oxvba-embed/tests/support'
        identity=run.removeprefix('run14-sealed-')
        expected={'Api':fixture_root/('automatic/Api.bas' if identity in ['events','mixed'] else 'application/Api.bas' if identity=='application' else 'xlsm/'+identity+'-entry.bas')}
        if identity in ['events','mixed']:
            expected.update({name:fixture_root/'automatic'/file for name,file in [('Watcher','Watcher.cls'),('Sheet1','Sheet1.cls'),('ThisWorkbook','ThisWorkbook.cls')]})
        if identity in ['chains','mixed']:expected['ChainOps']=fixture_root/'excel_chains.bas'
        if identity=='mixed':expected['WorkbookMain']=fixture_root/'xlsm/mixed-entry.bas'
        if identity=='application':expected.update({'AppWatcher':fixture_root/'application/AppWatcher.cls','ThisWorkbook':fixture_root/'application/ThisWorkbook.cls'})
        normalize=lambda text:text.replace('\r\n','\n').rstrip('\n')
        def identifier_case_only(text):
            # Preserve strings/comments/whitespace; VBE recases shared identifiers
            # when document event parameter names enter the same project.
            token=re.compile(r'"(?:[^"\n]|"")*"|\x27[^\n]*|\bRem[ \t][^\n]*|[A-Za-z_][A-Za-z_0-9]*',re.IGNORECASE)
            def fold(match):
                value=match.group()
                return value if value.startswith(('"',"'")) or re.match(r'(?i)Rem[ \t]',value) else value.lower()
            return token.sub(fold,normalize(text))
        recasing=[]
        for module in snapshot['modules']:
            source=expected[module['name']].read_text(encoding='utf-8') if module['name'] in expected else ''
            assert identifier_case_only(source)==identifier_case_only(module['source']),(identity,module['name'])
            if normalize(source)!=normalize(module['source']):recasing.append(module['name'])
        proof['vbe_identifier_recasing_only']=recasing
        cells = json.loads((case_dir/'excel-cells.json').read_text(encoding='utf-8-sig'))
        proof['cells_per_backend']=sum(len(sheet['cells']) for sheet in cells)
        proof['comparisons']=comparisons
        proof['module_sources']={m['name']:hashlib.sha256(m['source'].encode()).hexdigest() for m in snapshot['modules']}
        name=run.removeprefix('run14-sealed-')+'.xlsm'
        package=case_dir/name
        with zipfile.ZipFile(package) as workbook:
            binary=workbook.read('xl/vbaProject.bin')
            assert len(binary)>0
            proof['vba_project_bin_sha256']=hashlib.sha256(binary).hexdigest()
        proof['xlsm_sha256']=hashlib.sha256(package.read_bytes()).hexdigest()
        assert all(c['workbook_sha256']==proof['xlsm_sha256'] for c in comparisons)
    proofs.append(proof)

paths=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()
paths+=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines()
paths=[p for p in paths if p.endswith(('.rs','.ps1','.bas','.cls','.toml','.lock'))]
paths+=['Cargo.toml','Cargo.lock','crates/oxvba-embed/tests/support/owned_excel.rs']
paths += [p.relative_to(root).as_posix() for p in (root/'scripts').glob('excel-vba-oracle-*.ps1')]
paths += ['scripts/run-excel-vba-oracle.ps1','scripts/meta-check.ps1']
paths += ['temp/archive_run14_automatic.py','temp/audit_run14_owned.ps1']
paths=sorted(set(paths))
inputs={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
prior=[]
for path in sorted(base.glob('run14-*/results.json')):
    result=json.loads(path.read_text(encoding='utf-8-sig'))
    for case in result.get('cases',[]):
        prior.append(dict(run=path.parent.name,worker_passed=result.get('passed'),supervisor_transcript_retained=(path.parent/'transcript.json').is_file(),excel_pid=case.get('owned_excel_pid'),cleanup=case.get('cleanup_status')))
audit_path=root/'temp/run14-final-owned-audit.json'
audit=json.loads(audit_path.read_text(encoding='utf-8-sig'))
assert not audit['exact_live_owned_processes']
assert not audit['unverified_live_processes']
manifest=dict(schema='calcvba.run14.automatic-and-xlsm.v1',created_utc=datetime.now(timezone.utc).isoformat(),base_commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),status='bounded development execution proof; broader automatic events and workbook compatibility in-progress',inputs=inputs,proofs=proofs,repository_check=dict(command='scripts/meta-check.ps1 -Fast -NoArtifacts -NoRegistry',passed=sum(p for p,i in counts),ignored=sum(i for p,i in counts),suites=len(counts),excluded_registry_writers=4),formal='Installed Lean 4.29.1 RefCount TypedReentry TypedContinuation ProcedureHandles pass; concrete native/array refinement and Miri unproved',fresh_eyes='Found and repaired private Variant/object call conversion, native document identity, transposed array coordinates, conservative fixed allocation shape and saved project-name loading and missing unused/document interface metadata. Controlled idle callbacks pass on both backends. Reviewed stale generations, reentrant Unadvise, parked finalizers, reset and weak session lifetime. Broader errors/apartments/startup/reload/resurrection/structural events remain open.',prior_attempt_receipts=prior,owned_process_audit=audit)
archive=evidence/'run14-automatic-workbooks.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as out:
    for run in runs:
        for path in (base/run).rglob('*'):
            if path.is_file():out.write(path,'oracle/'+run+'/'+path.relative_to(base/run).as_posix())
    for path in paths:out.write(root/path,'source/'+path)
    for path in base.glob('run14-*/results.json'):
        if path.parent.name not in runs:out.write(path,'prior-attempts/'+path.parent.name+'/results.json')
    for path in [check_path,audit_path,root/'temp/run14-oracle-contract-03.log',root/'temp/run14-events-formal-final.log',root/'temp/run14-idle-events-03.log',root/'temp/run14-idle-clippy.log']:
        out.write(path,'checks/'+path.name)
manifest['archive_sha256']=hashlib.sha256(archive.read_bytes()).hexdigest()
(evidence/'run14-automatic-workbooks.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8',newline='\n')
with zipfile.ZipFile(archive) as check:
    for path,sha in inputs.items():assert hashlib.sha256(check.read('source/'+path)).hexdigest()==sha
    assert check.testzip() is None
print(manifest['repository_check'])
print('workbooks',len(cases),'compared_cells',sum(p.get('cells_per_backend',0)*2 for p in proofs))
print('archive_sha256',manifest['archive_sha256'])
