//! `oxvba-oxir` — OxIR, the typed, backend-neutral mid-level IR for OxVBA.
//!
//! OxIR is a **typed, basic-block CFG with typed locals/places** — MIR-like, *not*
//! authored SSA. It is produced from the resolved Core IR tree by an elaboration
//! pass, and it is the single canonical executable-semantic artifact: the new
//! interpreter `oxvba-vm3` executes it (and is its executable specification) and a
//! Cranelift backend lowers it to native code. The IR carries no backend types, so
//! future wasm / copy-and-patch / LLVM backends stay reachable behind one semantic
//! kernel.
//!
//! Layers:
//! - [`analysis`] — shared backend/verifier facts derived from canonical OxIR.
//! - [`passes`] — canonical behavior-preserving IR normalization passes.
//! - [`ty`] — the type lattice ([`OxTy`]): the static type each value/local carries
//!   (the information the legacy `linearize` discards).
//! - [`ids`] — structural index newtypes.
//! - [`value`] — operands, places, constants, and the operator enums.
//! - [`com`] — the typed COM model: the interface + method-descriptor tables and the
//!   IID / wire-shape vocabulary that keep COM calls typed end-to-end.
//! - [`inst`] — the typed instruction set, terminators, and basic blocks.
//! - [`program`] — functions, classes, and the whole compilation unit
//!   ([`OxProgram`]).
//! - [`verify`] — a structural verifier.
//! - [`elaborate`] — the `Core IR → OxIR` elaboration pass that produces these typed
//!   structures from the binder's resolved tree (landing incrementally, starting with
//!   the `VarTypeRef → OxTy` type lowering).

pub mod analysis;
pub mod com;
pub mod elaborate;
pub mod ids;
pub mod image;
pub mod inst;
pub mod passes;
pub mod program;
pub mod ty;
pub mod value;
pub mod verify;

pub use analysis::{EscapeFacts, apply_escape_analysis, escape_facts};
pub use com::{ComInterface, ComMethodRef, ProjectIfaceMethod, ProjectInterface};
pub use elaborate::{
    NameResolver, ResolvedTypeName, lower_declared_var_type_with_longptr_width,
    lower_var_type_with_longptr_width,
};
pub use ids::{BlockId, FuncId, GlobalId, ImportId, LocalId, TempId};
pub use image::{OX_IMAGE_FORMAT, OX_IMAGE_VERSION, OxImage, OxImageError};
pub use inst::{
    ErrorHandler, OxBlock, OxInst, OxTerminator, terminator_operands, terminator_successors,
};
pub use passes::normalize_assigns;
pub use program::{
    OxClass, OxClassField, OxClassMethod, OxFunc, OxGlobal, OxLocal, OxParamInfo, OxProgram,
};
pub use ty::{ArrayShape, ClassId, IfaceId, ObjClass, OxTy, RecordLayoutId};
pub use value::{
    ArithOp, BoundWhich, CmpOp, DeclarePtrWriteback, ErrField, LogicalOp, OxArg, OxCallArg,
    OxCoerceTarget, OxConst, OxNativeCallee, OxOperand, OxPlace, PtrKind, PtrWritebackKind,
};
pub use verify::{VerifyError, verify_program};

#[cfg(test)]
mod tests {
    use super::*;
    use oxvba_bundle::{NumericCoerceTarget, NumericMode, ProcedureKind, ProjectMemberKind};

    /// A small well-formed program: `Sub Main()` computing `n = (10 + 5) * 2` into a
    /// `Long` local, with a fault landing pad for the two checked-arithmetic ops.
    fn sample_program() -> OxProgram {
        let long = NumericMode::Checked(NumericCoerceTarget::Long);
        let n = LocalId(0);
        let t0 = TempId(0);

        // Block 0 (entry): the statement body; fallible ops fault to block 1.
        let entry = OxBlock {
            id: BlockId(0),
            instrs: vec![
                OxInst::StmtBoundary {
                    stmt: 0,
                    clear_temps_from: 0,
                },
                OxInst::Arith {
                    dst: OxPlace::Temp(t0),
                    op: ArithOp::Add,
                    lhs: OxOperand::Const(OxConst::I32(10)),
                    rhs: OxOperand::Const(OxConst::I32(5)),
                    mode: long,
                },
                OxInst::Arith {
                    dst: OxPlace::Local(n),
                    op: ArithOp::Mul,
                    lhs: OxOperand::temp(t0),
                    rhs: OxOperand::Const(OxConst::I32(2)),
                    mode: long,
                },
            ],
            fault_target: Some(BlockId(1)),
            terminator: OxTerminator::Jump(BlockId(2)),
        };
        // Block 1: the landing pad (no active handler ⇒ just return).
        let landing = OxBlock::new(BlockId(1), OxTerminator::Return);
        // Block 2: normal exit.
        let exit = OxBlock::new(BlockId(2), OxTerminator::Return);

        let main = OxFunc {
            name: "Main".to_string(),
            kind: ProcedureKind::Sub,
            locals: vec![OxLocal {
                name: "n".to_string(),
                ty: OxTy::Long,
                array_element: None,
                param: None,
                escaped: false,
            }],
            temps: vec![OxTy::Long],
            param_count: 0,
            return_local: None,
            blocks: vec![entry, landing, exit],
            entry: BlockId(0),
        };

        OxProgram {
            funcs: vec![main],
            entry: Some(FuncId(0)),
            unit_name: "Sample".to_string(),
            ..OxProgram::empty()
        }
    }

    #[test]
    fn sample_program_verifies() {
        let p = sample_program();
        assert_eq!(verify_program(&p), Ok(()));
    }

    #[test]
    fn structural_round_trip_through_json() {
        let p = sample_program();
        let json = serde_json::to_string(&p).expect("serialize");
        let back: OxProgram = serde_json::from_str(&json).expect("deserialize");
        assert_eq!(p, back, "OxProgram must round-trip structurally");
    }

    #[test]
    fn verifier_catches_dangling_entry() {
        let mut p = sample_program();
        p.funcs[0].entry = BlockId(99);
        let errs = verify_program(&p).expect_err("dangling entry must be rejected");
        assert!(
            errs.iter()
                .any(|e| matches!(e, VerifyError::BadEntry { entry: 99, .. })),
            "expected BadEntry, got {errs:?}"
        );
    }

    #[test]
    fn verifier_catches_out_of_range_program_entry() {
        // A program `entry` FuncId out of range is dereferenced directly when a
        // frame is built (Vm3::new_frame_in), so it must be rejected, not panic.
        let mut p = sample_program();
        p.entry = Some(FuncId(99));
        let errs = verify_program(&p).expect_err("out-of-range program entry must be rejected");
        assert!(
            errs.iter().any(|e| matches!(
                e,
                VerifyError::BadProgramEntry {
                    entry: 99,
                    funcs: 1
                }
            )),
            "expected BadProgramEntry, got {errs:?}"
        );
    }

    #[test]
    fn verifier_catches_out_of_range_global_initializer() {
        let mut p = sample_program();
        p.global_initializer = Some(FuncId(42));
        let errs =
            verify_program(&p).expect_err("out-of-range global_initializer must be rejected");
        assert!(
            errs.iter().any(|e| matches!(
                e,
                VerifyError::BadGlobalInitializer {
                    initializer: 42,
                    funcs: 1
                }
            )),
            "expected BadGlobalInitializer, got {errs:?}"
        );
    }

    #[test]
    fn verifier_catches_missing_fault_target() {
        let mut p = sample_program();
        // Drop the landing pad on the entry block; its checked-arith ops are fallible.
        p.funcs[0].blocks[0].fault_target = None;
        let errs =
            verify_program(&p).expect_err("fallible block without fault_target must be rejected");
        assert!(
            errs.iter()
                .any(|e| matches!(e, VerifyError::MissingFaultTarget { .. })),
            "expected MissingFaultTarget, got {errs:?}"
        );
    }

    #[test]
    fn verifier_catches_bad_successor() {
        let mut p = sample_program();
        p.funcs[0].blocks[0].terminator = OxTerminator::Jump(BlockId(42));
        let errs = verify_program(&p).expect_err("dangling jump must be rejected");
        assert!(
            errs.iter()
                .any(|e| matches!(e, VerifyError::BadSuccessor { target: 42, .. })),
            "expected BadSuccessor, got {errs:?}"
        );
    }

    #[test]
    fn verifier_catches_bad_fault_dispatch_seed() {
        let mut p = sample_program();
        p.funcs[0].blocks[1].terminator = OxTerminator::FaultDispatch {
            resume: BlockId(99),
            resume_next: BlockId(2),
        };
        let errs = verify_program(&p).expect_err("dangling fault seed must be rejected");
        assert!(
            errs.iter()
                .any(|e| matches!(e, VerifyError::BadSuccessor { target: 99, .. })),
            "expected BadSuccessor, got {errs:?}"
        );
    }

    #[test]
    fn verifier_catches_bad_gosub_return_target() {
        let mut p = sample_program();
        p.funcs[0].blocks[0].terminator = OxTerminator::GoSub {
            target: BlockId(1),
            ret: BlockId(99),
        };
        let errs = verify_program(&p).expect_err("dangling GoSub return must be rejected");
        assert!(
            errs.iter()
                .any(|e| matches!(e, VerifyError::BadSuccessor { target: 99, .. })),
            "expected BadSuccessor, got {errs:?}"
        );
    }

    #[test]
    fn verifier_catches_bad_temp_ref() {
        let mut p = sample_program();
        p.funcs[0].temps.clear();
        let errs = verify_program(&p).expect_err("dangling temp must be rejected");
        assert!(
            errs.iter().any(|e| matches!(
                e,
                VerifyError::BadTempRef {
                    temp: 0,
                    temps: 0,
                    ..
                }
            )),
            "expected BadTempRef, got {errs:?}"
        );
    }

    #[test]
    fn verifier_catches_bad_stmt_boundary_temp_floor() {
        let mut p = sample_program();
        p.funcs[0].blocks[0].instrs[0] = OxInst::StmtBoundary {
            stmt: 0,
            clear_temps_from: 99,
        };
        let errs = verify_program(&p).expect_err("out-of-range temp clear floor must be rejected");
        assert!(
            errs.iter().any(|e| matches!(
                e,
                VerifyError::BadStmtBoundaryTemp {
                    clear_temps_from: 99,
                    temps: 1,
                    ..
                }
            )),
            "expected BadStmtBoundaryTemp, got {errs:?}"
        );
    }

    #[test]
    fn verifier_catches_stale_escape_flag() {
        let mut p = sample_program();
        p.funcs[0].locals[0].escaped = true;
        let errs = verify_program(&p).expect_err("stale escape flag must be rejected");
        assert!(
            errs.iter().any(|e| matches!(
                e,
                VerifyError::BadEscapedLocal {
                    local: 0,
                    expected: false,
                    actual: true,
                    ..
                }
            )),
            "expected BadEscapedLocal, got {errs:?}"
        );
    }

    #[test]
    fn verifier_catches_raw_representation_changing_assign() {
        let mut p = sample_program();
        p.funcs[0].blocks[0].instrs[1] = OxInst::Assign {
            dst: OxPlace::Local(LocalId(0)),
            value: OxOperand::Const(OxConst::Str("7".to_string())),
        };
        let errs =
            verify_program(&p).expect_err("raw representation-changing Assign must be rejected");
        assert!(
            errs.iter().any(|e| matches!(
                e,
                VerifyError::BadAssignRepresentation {
                    dst: OxTy::Long,
                    src: OxTy::Str,
                    ..
                }
            )),
            "expected BadAssignRepresentation, got {errs:?}"
        );
    }

    // ── Project class metadata ──────────────────────────────────────────────

    fn sample_class_field_program() -> OxProgram {
        OxProgram {
            classes: vec![OxClass {
                name: "Widget".to_string(),
                predeclared: false,
                initialize: None,
                terminate: None,
                fields: vec![OxClassField {
                    externally_visible: true,
                    name: "child".to_string(),
                    token: 0,
                    ty: OxTy::Object(ObjClass::Class(ClassId(0))),
                    array_element: None,
                }],
                methods: Vec::new(),
                as_new_fields: vec![crate::program::OxClassAsNewField {
                    field: 0,
                    binding: crate::inst::OxAsNew::ProjectClass { class: ClassId(0) },
                }],
                implements: Vec::new(),
            }],
            unit_name: "ClassSample".to_string(),
            ..OxProgram::empty()
        }
    }

    fn class_receiver_func(name: &str) -> OxFunc {
        class_receiver_func_with_kind(name, ProcedureKind::Sub)
    }

    #[test]
    fn native_event_routes_roundtrip_and_reject_damaged_descriptors() {
        let mut handler = class_receiver_func("source_BeforeClose");
        handler.locals.push(OxLocal {
            name: "Cancel".into(),
            ty: OxTy::Bool,
            array_element: None,
            param: Some(OxParamInfo {
                optional: false,
                by_ref: true,
                variadic: false,
            }),
            escaped: false,
        });
        handler.param_count = 2;
        let route = oxvba_bundle::EventRoute {
            binding: 0,
            event: 1546,
            handler: 0,
            document_class: None,
            native: Some(oxvba_com::TypeLibEventMetadata {
                name: "BeforeClose".into(),
                token: 1546,
                callback_arity: 1,
                parameter_types: vec![oxvba_com::TypeLibParamType::ByRefBoolean],
                parameter_iids: vec![None],
                dispatch_path: oxvba_com::TypeLibEventDispatchPath::Dispatch,
                connection_point_iid: Some("00024412-0000-0000-C000-000000000046".into()),
                dispatch_member_id: Some(1546),
                coclass: Some("Workbook".into()),
            }),
        };
        let program = OxProgram {
            funcs: vec![handler],
            event_routes: vec![route],
            ..Default::default()
        };
        assert_eq!(verify_program(&program), Ok(()));
        let encoded = serde_json::to_string(&program).unwrap();
        let decoded: OxProgram = serde_json::from_str(&encoded).unwrap();
        assert_eq!(decoded, program);
        for mutation in 0..9 {
            let mut bad = program.clone();
            let route = &mut bad.event_routes[0];
            match mutation {
                0 => route.handler = 99,
                1 => route.document_class = Some(99),
                2 => route.native.as_mut().unwrap().callback_arity = 2,
                3 => {
                    route.native.as_mut().unwrap().connection_point_iid = Some("not-an-IID".into())
                }
                4 => route.native.as_mut().unwrap().dispatch_member_id = Some(1),
                5 => bad.funcs[0].locals[1].param.as_mut().unwrap().by_ref = false,
                7 => bad.funcs[0].locals[1].ty = OxTy::Long,
                8 => {
                    route.native.as_mut().unwrap().parameter_iids[0] = Some(
                        oxvba_com::ComInterfaceIid::parse("00024412-0000-0000-C000-000000000046")
                            .unwrap(),
                    )
                }
                _ => {
                    let duplicate = route.clone();
                    bad.event_routes.push(duplicate);
                }
            }
            assert!(
                verify_program(&bad)
                    .unwrap_err()
                    .iter()
                    .any(|e| matches!(e, VerifyError::BadEventRoute { .. })),
                "mutation {mutation}"
            );
        }
    }

    fn class_receiver_func_with_kind(name: &str, kind: ProcedureKind) -> OxFunc {
        OxFunc {
            name: name.to_string(),
            kind,
            locals: vec![OxLocal {
                name: "Me".to_string(),
                ty: OxTy::Variant,
                array_element: None,
                param: Some(OxParamInfo {
                    optional: false,
                    by_ref: false,
                    variadic: false,
                }),
                escaped: false,
            }],
            temps: Vec::new(),
            param_count: 1,
            return_local: None,
            blocks: vec![OxBlock::new(BlockId(0), OxTerminator::Return)],
            entry: BlockId(0),
        }
    }

    fn class_property_setter_func(name: &str, kind: ProcedureKind, value_by_ref: bool) -> OxFunc {
        OxFunc {
            name: name.to_string(),
            kind,
            locals: vec![
                OxLocal {
                    name: "Me".to_string(),
                    ty: OxTy::Variant,
                    array_element: None,
                    param: Some(OxParamInfo {
                        optional: false,
                        by_ref: false,
                        variadic: false,
                    }),
                    escaped: false,
                },
                OxLocal {
                    name: "value".to_string(),
                    ty: OxTy::Variant,
                    array_element: None,
                    param: Some(OxParamInfo {
                        optional: false,
                        by_ref: value_by_ref,
                        variadic: false,
                    }),
                    escaped: false,
                },
            ],
            temps: Vec::new(),
            param_count: 2,
            return_local: None,
            blocks: vec![OxBlock::new(BlockId(0), OxTerminator::Return)],
            entry: BlockId(0),
        }
    }

    #[test]
    fn class_field_as_new_metadata_verifies() {
        let p = sample_class_field_program();
        assert_eq!(verify_program(&p), Ok(()));
    }

    #[test]
    fn verifier_catches_duplicate_class_field_token() {
        let mut p = sample_class_field_program();
        p.classes[0].fields.push(OxClassField {
            externally_visible: true,
            name: "alias".to_string(),
            token: 0,
            ty: OxTy::Variant,
            array_element: None,
        });
        let errs = verify_program(&p).expect_err("duplicate class field token must be rejected");
        assert!(
            errs.iter().any(|e| matches!(
                e,
                VerifyError::DuplicateClassFieldToken {
                    class_index: 0,
                    field: 0
                }
            )),
            "expected DuplicateClassFieldToken, got {errs:?}"
        );
    }

    #[test]
    fn verifier_catches_as_new_field_missing_from_class_table() {
        let mut p = sample_class_field_program();
        p.classes[0].as_new_fields[0].field = 99;
        let errs = verify_program(&p).expect_err("stale As New field token must be rejected");
        assert!(
            errs.iter().any(|e| matches!(
                e,
                VerifyError::BadClassFieldAsNewFieldRef {
                    class_index: 0,
                    field: 99
                }
            )),
            "expected BadClassFieldAsNewFieldRef, got {errs:?}"
        );
    }

    #[test]
    fn verifier_catches_bad_class_initialize_proc_ref() {
        let mut p = sample_class_field_program();
        p.classes[0].initialize = Some(FuncId(99));
        let errs = verify_program(&p).expect_err("dangling Class_Initialize proc");
        assert!(
            errs.iter().any(|e| matches!(
                e,
                VerifyError::BadClassLifecycleProcRef {
                    class_index: 0,
                    hook: "Class_Initialize",
                    proc: 99,
                    funcs: 0
                }
            )),
            "expected BadClassLifecycleProcRef for initialize, got {errs:?}"
        );
    }

    #[test]
    fn verifier_catches_bad_class_terminate_proc_ref() {
        let mut p = sample_class_field_program();
        p.classes[0].terminate = Some(FuncId(99));
        let errs = verify_program(&p).expect_err("dangling Class_Terminate proc");
        assert!(
            errs.iter().any(|e| matches!(
                e,
                VerifyError::BadClassLifecycleProcRef {
                    class_index: 0,
                    hook: "Class_Terminate",
                    proc: 99,
                    funcs: 0
                }
            )),
            "expected BadClassLifecycleProcRef for terminate, got {errs:?}"
        );
    }

    #[test]
    fn verifier_accepts_class_method_with_hidden_me_receiver() {
        let mut p = sample_class_field_program();
        p.funcs.push(class_receiver_func("Touch"));
        p.classes[0].methods.push(OxClassMethod {
            externally_visible: true,
            name: "Touch".to_string(),
            kind: ProjectMemberKind::Method,
            proc: FuncId(0),
            dispid: None,
            vtable_slot: None,
            is_default_member: false,
            is_enumerator_member: false,
        });
        assert_eq!(verify_program(&p), Ok(()));
    }

    #[test]
    fn verifier_catches_class_lifecycle_without_hidden_me_receiver() {
        let mut p = sample_class_field_program();
        let mut proc_program = sample_program();
        p.funcs.push(proc_program.funcs.remove(0));
        p.classes[0].initialize = Some(FuncId(0));
        let errs = verify_program(&p).expect_err("class lifecycle proc missing Me");
        assert!(
            errs.iter().any(|e| matches!(
                e,
                VerifyError::BadClassLifecycleReceiver {
                    class_index: 0,
                    hook: "Class_Initialize",
                    proc: 0,
                    param_count: 0,
                    first_local: Some(name),
                } if name == "n"
            )),
            "expected BadClassLifecycleReceiver, got {errs:?}"
        );
    }

    #[test]
    fn verifier_catches_class_lifecycle_proc_kind_mismatch() {
        let mut p = sample_class_field_program();
        p.funcs.push(class_receiver_func_with_kind(
            "Class_Initialize",
            ProcedureKind::Function,
        ));
        p.classes[0].initialize = Some(FuncId(0));
        let errs = verify_program(&p).expect_err("class lifecycle proc must be Sub");
        assert!(
            errs.iter().any(|e| matches!(
                e,
                VerifyError::BadClassLifecycleProcKind {
                    class_index: 0,
                    hook: "Class_Initialize",
                    proc: 0,
                    kind: ProcedureKind::Function,
                }
            )),
            "expected BadClassLifecycleProcKind, got {errs:?}"
        );
    }

    #[test]
    fn verifier_catches_bad_class_method_proc_ref() {
        let mut p = sample_class_field_program();
        p.classes[0].methods.push(OxClassMethod {
            externally_visible: true,
            name: "Touch".to_string(),
            kind: ProjectMemberKind::Method,
            proc: FuncId(99),
            dispid: None,
            vtable_slot: None,
            is_default_member: false,
            is_enumerator_member: false,
        });
        let errs = verify_program(&p).expect_err("dangling class method proc");
        assert!(
            errs.iter().any(|e| matches!(
                e,
                VerifyError::BadClassMethodProcRef {
                    class_index: 0,
                    method_index: 0,
                    proc: 99,
                    funcs: 0
                }
            )),
            "expected BadClassMethodProcRef, got {errs:?}"
        );
    }

    #[test]
    fn verifier_catches_class_method_without_hidden_me_receiver() {
        let mut p = sample_class_field_program();
        let mut proc_program = sample_program();
        p.funcs.push(proc_program.funcs.remove(0));
        p.classes[0].methods.push(OxClassMethod {
            externally_visible: true,
            name: "Touch".to_string(),
            kind: ProjectMemberKind::Method,
            proc: FuncId(0),
            dispid: None,
            vtable_slot: None,
            is_default_member: false,
            is_enumerator_member: false,
        });
        let errs = verify_program(&p).expect_err("class method proc missing Me");
        assert!(
            errs.iter().any(|e| matches!(
                e,
                VerifyError::BadClassMethodReceiver {
                    class_index: 0,
                    method_index: 0,
                    proc: 0,
                    param_count: 0,
                    first_local: Some(name),
                } if name == "n"
            )),
            "expected BadClassMethodReceiver, got {errs:?}"
        );
    }

    #[test]
    fn verifier_catches_class_member_proc_kind_mismatch() {
        let mut p = sample_class_field_program();
        p.funcs.push(class_receiver_func("Value"));
        p.classes[0].methods.push(OxClassMethod {
            externally_visible: true,
            name: "Value".to_string(),
            kind: ProjectMemberKind::PropertyGet,
            proc: FuncId(0),
            dispid: None,
            vtable_slot: None,
            is_default_member: false,
            is_enumerator_member: false,
        });
        let errs = verify_program(&p).expect_err("property descriptor needs property proc");
        assert!(
            errs.iter().any(|e| matches!(
                e,
                VerifyError::BadClassMethodProcKind {
                    class_index: 0,
                    method_index: 0,
                    proc: 0,
                    member_kind: ProjectMemberKind::PropertyGet,
                    proc_kind: ProcedureKind::Sub,
                }
            )),
            "expected BadClassMethodProcKind, got {errs:?}"
        );
    }

    #[test]
    fn verifier_accepts_class_property_setter_byval_value_param() {
        let mut p = sample_class_field_program();
        p.funcs.push(class_property_setter_func(
            "Value",
            ProcedureKind::PropertyLet,
            false,
        ));
        p.classes[0].methods.push(OxClassMethod {
            externally_visible: true,
            name: "Value".to_string(),
            kind: ProjectMemberKind::PropertyLet,
            proc: FuncId(0),
            dispid: None,
            vtable_slot: None,
            is_default_member: false,
            is_enumerator_member: false,
        });
        assert_eq!(verify_program(&p), Ok(()));
    }

    #[test]
    fn verifier_catches_class_property_setter_without_value_param() {
        let mut p = sample_class_field_program();
        p.funcs.push(class_receiver_func_with_kind(
            "Value",
            ProcedureKind::PropertyLet,
        ));
        p.classes[0].methods.push(OxClassMethod {
            externally_visible: true,
            name: "Value".to_string(),
            kind: ProjectMemberKind::PropertyLet,
            proc: FuncId(0),
            dispid: None,
            vtable_slot: None,
            is_default_member: false,
            is_enumerator_member: false,
        });
        let errs = verify_program(&p).expect_err("setter descriptor needs value parameter");
        assert!(
            errs.iter().any(|e| matches!(
                e,
                VerifyError::BadClassPropertySetterValueParam {
                    class_index: 0,
                    method_index: 0,
                    proc: 0,
                    member_kind: ProjectMemberKind::PropertyLet,
                    visible_params: 0,
                    param_count: 1,
                    locals: 1,
                }
            )),
            "expected BadClassPropertySetterValueParam, got {errs:?}"
        );
    }

    #[test]
    fn verifier_catches_class_property_setter_byref_value_param() {
        let mut p = sample_class_field_program();
        p.funcs.push(class_property_setter_func(
            "Child",
            ProcedureKind::PropertySet,
            true,
        ));
        p.classes[0].methods.push(OxClassMethod {
            externally_visible: true,
            name: "Child".to_string(),
            kind: ProjectMemberKind::PropertySet,
            proc: FuncId(0),
            dispid: None,
            vtable_slot: None,
            is_default_member: false,
            is_enumerator_member: false,
        });
        let errs = verify_program(&p).expect_err("setter value parameter must be ByVal");
        assert!(
            errs.iter().any(|e| matches!(
                e,
                VerifyError::BadClassPropertySetterValueByRef {
                    class_index: 0,
                    method_index: 0,
                    proc: 0,
                    member_kind: ProjectMemberKind::PropertySet,
                    param_index: 1,
                    name,
                } if name == "value"
            )),
            "expected BadClassPropertySetterValueByRef, got {errs:?}"
        );
    }

    #[test]
    fn verifier_accepts_default_property_pair_and_enumerator_metadata() {
        let mut p = sample_class_field_program();
        p.funcs.push(class_receiver_func_with_kind(
            "Value",
            ProcedureKind::PropertyGet,
        ));
        p.funcs.push(class_property_setter_func(
            "Value",
            ProcedureKind::PropertyLet,
            false,
        ));
        p.funcs.push(class_receiver_func_with_kind(
            "NewEnum",
            ProcedureKind::PropertyGet,
        ));
        p.classes[0].methods.extend([
            OxClassMethod {
                externally_visible: true,
                name: "Value".to_string(),
                kind: ProjectMemberKind::PropertyGet,
                proc: FuncId(0),
                dispid: Some(0),
                vtable_slot: Some(7),
                is_default_member: true,
                is_enumerator_member: false,
            },
            OxClassMethod {
                externally_visible: true,
                name: "Value".to_string(),
                kind: ProjectMemberKind::PropertyLet,
                proc: FuncId(1),
                dispid: Some(0),
                vtable_slot: Some(8),
                is_default_member: true,
                is_enumerator_member: false,
            },
            OxClassMethod {
                externally_visible: true,
                name: "NewEnum".to_string(),
                kind: ProjectMemberKind::PropertyGet,
                proc: FuncId(2),
                dispid: Some(-4),
                vtable_slot: Some(9),
                is_default_member: false,
                is_enumerator_member: true,
            },
        ]);
        assert_eq!(verify_program(&p), Ok(()));
    }

    #[test]
    fn verifier_catches_ambiguous_class_default_member_names() {
        let mut p = sample_class_field_program();
        p.funcs.push(class_receiver_func_with_kind(
            "Value",
            ProcedureKind::PropertyGet,
        ));
        p.funcs.push(class_receiver_func_with_kind(
            "Caption",
            ProcedureKind::PropertyGet,
        ));
        p.classes[0].methods.extend([
            OxClassMethod {
                externally_visible: true,
                name: "Value".to_string(),
                kind: ProjectMemberKind::PropertyGet,
                proc: FuncId(0),
                dispid: Some(0),
                vtable_slot: None,
                is_default_member: true,
                is_enumerator_member: false,
            },
            OxClassMethod {
                externally_visible: true,
                name: "Caption".to_string(),
                kind: ProjectMemberKind::PropertyGet,
                proc: FuncId(1),
                dispid: Some(0),
                vtable_slot: None,
                is_default_member: true,
                is_enumerator_member: false,
            },
        ]);
        let errs = verify_program(&p).expect_err("only one logical default member");
        assert!(
            errs.iter().any(|e| matches!(
                e,
                VerifyError::AmbiguousClassDefaultMember {
                    class_index: 0,
                    method_index: 1,
                    first_name,
                    name,
                } if first_name == "Value" && name == "Caption"
            )),
            "expected AmbiguousClassDefaultMember, got {errs:?}"
        );
    }

    #[test]
    fn verifier_catches_default_member_nonzero_dispid() {
        let mut p = sample_class_field_program();
        p.funcs.push(class_receiver_func_with_kind(
            "Value",
            ProcedureKind::PropertyGet,
        ));
        p.classes[0].methods.push(OxClassMethod {
            externally_visible: true,
            name: "Value".to_string(),
            kind: ProjectMemberKind::PropertyGet,
            proc: FuncId(0),
            dispid: Some(42),
            vtable_slot: None,
            is_default_member: true,
            is_enumerator_member: false,
        });
        let errs = verify_program(&p).expect_err("default member dispid must be zero");
        assert!(
            errs.iter().any(|e| matches!(
                e,
                VerifyError::BadClassDefaultMemberDispid {
                    class_index: 0,
                    method_index: 0,
                    name,
                    kind: ProjectMemberKind::PropertyGet,
                    dispid: 42,
                } if name == "Value"
            )),
            "expected BadClassDefaultMemberDispid, got {errs:?}"
        );
    }

    #[test]
    fn verifier_catches_duplicate_class_enumerator_members() {
        let mut p = sample_class_field_program();
        p.funcs.push(class_receiver_func_with_kind(
            "NewEnum",
            ProcedureKind::PropertyGet,
        ));
        p.funcs.push(class_receiver_func_with_kind(
            "OtherEnum",
            ProcedureKind::PropertyGet,
        ));
        p.classes[0].methods.extend([
            OxClassMethod {
                externally_visible: true,
                name: "NewEnum".to_string(),
                kind: ProjectMemberKind::PropertyGet,
                proc: FuncId(0),
                dispid: Some(-4),
                vtable_slot: None,
                is_default_member: false,
                is_enumerator_member: true,
            },
            OxClassMethod {
                externally_visible: true,
                name: "OtherEnum".to_string(),
                kind: ProjectMemberKind::PropertyGet,
                proc: FuncId(1),
                dispid: Some(-4),
                vtable_slot: None,
                is_default_member: false,
                is_enumerator_member: true,
            },
        ]);
        let errs = verify_program(&p).expect_err("only one enumerator member");
        assert!(
            errs.iter().any(|e| matches!(
                e,
                VerifyError::DuplicateClassEnumeratorMember {
                    class_index: 0,
                    method_index: 1,
                    first_method_index: 0,
                    name,
                } if name == "OtherEnum"
            )),
            "expected DuplicateClassEnumeratorMember, got {errs:?}"
        );
    }

    #[test]
    fn verifier_catches_class_enumerator_setter_kind() {
        let mut p = sample_class_field_program();
        p.funcs.push(class_property_setter_func(
            "NewEnum",
            ProcedureKind::PropertyLet,
            false,
        ));
        p.classes[0].methods.push(OxClassMethod {
            externally_visible: true,
            name: "NewEnum".to_string(),
            kind: ProjectMemberKind::PropertyLet,
            proc: FuncId(0),
            dispid: Some(-4),
            vtable_slot: None,
            is_default_member: false,
            is_enumerator_member: true,
        });
        let errs = verify_program(&p).expect_err("enumerator cannot be a setter");
        assert!(
            errs.iter().any(|e| matches!(
                e,
                VerifyError::BadClassEnumeratorMemberKind {
                    class_index: 0,
                    method_index: 0,
                    name,
                    kind: ProjectMemberKind::PropertyLet,
                } if name == "NewEnum"
            )),
            "expected BadClassEnumeratorMemberKind, got {errs:?}"
        );
    }

    #[test]
    fn verifier_catches_class_enumerator_wrong_dispid() {
        let mut p = sample_class_field_program();
        p.funcs.push(class_receiver_func_with_kind(
            "NewEnum",
            ProcedureKind::PropertyGet,
        ));
        p.classes[0].methods.push(OxClassMethod {
            externally_visible: true,
            name: "NewEnum".to_string(),
            kind: ProjectMemberKind::PropertyGet,
            proc: FuncId(0),
            dispid: Some(7),
            vtable_slot: None,
            is_default_member: false,
            is_enumerator_member: true,
        });
        let errs = verify_program(&p).expect_err("enumerator dispid must be -4");
        assert!(
            errs.iter().any(|e| matches!(
                e,
                VerifyError::BadClassEnumeratorDispid {
                    class_index: 0,
                    method_index: 0,
                    name,
                    kind: ProjectMemberKind::PropertyGet,
                    dispid: 7,
                } if name == "NewEnum"
            )),
            "expected BadClassEnumeratorDispid, got {errs:?}"
        );
    }

    #[test]
    fn verifier_catches_class_enumerator_visible_params() {
        let mut p = sample_class_field_program();
        p.funcs.push(class_property_setter_func(
            "NewEnum",
            ProcedureKind::PropertyGet,
            false,
        ));
        p.classes[0].methods.push(OxClassMethod {
            externally_visible: true,
            name: "NewEnum".to_string(),
            kind: ProjectMemberKind::PropertyGet,
            proc: FuncId(0),
            dispid: Some(-4),
            vtable_slot: None,
            is_default_member: false,
            is_enumerator_member: true,
        });
        let errs = verify_program(&p).expect_err("enumerator target must be zero-arg");
        assert!(
            errs.iter().any(|e| matches!(
                e,
                VerifyError::BadClassEnumeratorVisibleParams {
                    class_index: 0,
                    method_index: 0,
                    proc: 0,
                    visible_params: 1,
                    param_count: 2,
                }
            )),
            "expected BadClassEnumeratorVisibleParams, got {errs:?}"
        );
    }

    #[test]
    fn verifier_catches_duplicate_class_method_dispatch_key() {
        let mut p = sample_class_field_program();
        let mut proc_program = sample_program();
        p.funcs.push(proc_program.funcs.remove(0));
        p.classes[0].methods.extend([
            OxClassMethod {
                externally_visible: true,
                name: "Value".to_string(),
                kind: ProjectMemberKind::PropertyGet,
                proc: FuncId(0),
                dispid: None,
                vtable_slot: None,
                is_default_member: false,
                is_enumerator_member: false,
            },
            OxClassMethod {
                externally_visible: true,
                name: "value".to_string(),
                kind: ProjectMemberKind::PropertyGet,
                proc: FuncId(0),
                dispid: None,
                vtable_slot: None,
                is_default_member: false,
                is_enumerator_member: false,
            },
        ]);
        let errs = verify_program(&p).expect_err("duplicate class method key");
        assert!(
            errs.iter().any(|e| matches!(
                e,
                VerifyError::DuplicateClassMethod {
                    class_index: 0,
                    method_index: 1,
                    name,
                    kind: ProjectMemberKind::PropertyGet,
                } if name == "value"
            )),
            "expected DuplicateClassMethod, got {errs:?}"
        );
    }

    // ── Typed COM model ──────────────────────────────────────────────────────

    use oxvba_com::{
        ComInterfaceIid, SourceTypeKind, TypeLibInterfaceMetadata, TypeLibMemberInvokeKind,
        TypeLibMemberMetadata, TypeLibParamType,
    };

    /// The canonical (reused) typed descriptor for `Excel.Range.Value` — a `[propget]`
    /// on a dual interface's vtable slot 7 returning a Variant, with no parameters.
    fn value_member(iid: ComInterfaceIid) -> TypeLibMemberMetadata {
        TypeLibMemberMetadata {
            name: "Value".to_string(),
            token: 6,
            vtable_slot: Some(7),
            requires_argument: false,
            invoke_kind: TypeLibMemberInvokeKind::PropertyGet,
            parameter_names: vec![],
            parameter_optional: vec![],
            parameter_optional_defaults: vec![],
            is_default_member: true,
            parameter_types: vec![],
            parameter_wire_types: vec![],
            parameter_iids: vec![],
            return_type: Some(TypeLibParamType::Variant),
            return_wire_type: None,
            callconv_is_stdcall: true,
            is_dual: true,
            interface_iid: Some(iid),
            source_typekind: Some(SourceTypeKind::Interface),
            vtable_slot_bound: Some(20),
        }
    }

    /// A small program exercising the typed COM table: `Dim r As Excel.Range`,
    /// `result = r.Value`, with `Value` resolved through the reused
    /// `TypeLibInterfaceMetadata`/`TypeLibMemberMetadata` descriptors.
    fn sample_com_program() -> OxProgram {
        let recv = LocalId(0);
        let result = LocalId(1);

        // A plausible (not load-bearing) IID for the test.
        let iid = ComInterfaceIid {
            data1: 0x0002_0846,
            data2: 0x0000,
            data3: 0x0000,
            data4: [0xC0, 0, 0, 0, 0, 0, 0, 0x46],
        };

        let range_iface = ComInterface::Com(TypeLibInterfaceMetadata {
            name: "Excel.Range".to_string(),
            iid: Some(iid),
            members: vec![value_member(iid)],
        });

        let entry = OxBlock {
            id: BlockId(0),
            instrs: vec![
                OxInst::StmtBoundary {
                    stmt: 0,
                    clear_temps_from: 0,
                },
                OxInst::ComCallEarly {
                    dst: Some(OxPlace::Local(result)),
                    method: ComMethodRef {
                        iface: IfaceId(0),
                        member: 0,
                    },
                    invoke_kind: TypeLibMemberInvokeKind::PropertyGet,
                    recv: OxOperand::local(recv),
                    args: vec![],
                },
            ],
            fault_target: Some(BlockId(1)),
            terminator: OxTerminator::Return,
        };
        let landing = OxBlock::new(BlockId(1), OxTerminator::Return);

        let main = OxFunc {
            name: "Main".to_string(),
            kind: ProcedureKind::Sub,
            locals: vec![
                OxLocal {
                    name: "r".to_string(),
                    ty: OxTy::Object(ObjClass::ComIface(IfaceId(0))),
                    array_element: None,
                    param: None,
                    escaped: false,
                },
                OxLocal {
                    name: "result".to_string(),
                    ty: OxTy::Variant,
                    array_element: None,
                    param: None,
                    escaped: false,
                },
            ],
            temps: Vec::new(),
            param_count: 0,
            return_local: None,
            blocks: vec![entry, landing],
            entry: BlockId(0),
        };

        OxProgram {
            funcs: vec![main],
            entry: Some(FuncId(0)),
            unit_name: "ComSample".to_string(),
            com_interfaces: vec![range_iface],
            ..OxProgram::empty()
        }
    }

    #[test]
    fn com_program_verifies_and_resolves_member() {
        let p = sample_com_program();
        assert_eq!(verify_program(&p), Ok(()));
        // The call-site key resolves to the reused, fully-typed descriptor.
        let m = p
            .com_method(ComMethodRef {
                iface: IfaceId(0),
                member: 0,
            })
            .expect("ComMethodRef resolves");
        assert_eq!(m.name, "Value");
        assert_eq!(m.return_type, Some(TypeLibParamType::Variant));
        assert_eq!(m.vtable_slot, Some(7));
    }

    #[test]
    fn com_program_round_trips_through_json() {
        let p = sample_com_program();
        let json = serde_json::to_string(&p).expect("serialize");
        let back: OxProgram = serde_json::from_str(&json).expect("deserialize");
        assert_eq!(p, back, "typed COM table must round-trip structurally");
    }

    #[test]
    fn verifier_catches_dangling_com_interface() {
        let mut p = sample_com_program();
        p.funcs[0].blocks[0].instrs[1] = OxInst::ComCallEarly {
            dst: Some(OxPlace::Local(LocalId(1))),
            method: ComMethodRef {
                iface: IfaceId(9),
                member: 0,
            },
            invoke_kind: TypeLibMemberInvokeKind::PropertyGet,
            recv: OxOperand::local(LocalId(0)),
            args: vec![],
        };
        let errs = verify_program(&p).expect_err("dangling interface must be rejected");
        assert!(
            errs.iter()
                .any(|e| matches!(e, VerifyError::BadComIfaceRef { iface: 9, .. })),
            "expected BadComIfaceRef, got {errs:?}"
        );
    }

    #[test]
    fn verifier_catches_bad_com_member() {
        let mut p = sample_com_program();
        p.funcs[0].blocks[0].instrs[1] = OxInst::ComCallEarly {
            dst: Some(OxPlace::Local(LocalId(1))),
            method: ComMethodRef {
                iface: IfaceId(0),
                member: 99,
            },
            invoke_kind: TypeLibMemberInvokeKind::PropertyGet,
            recv: OxOperand::local(LocalId(0)),
            args: vec![],
        };
        let errs = verify_program(&p).expect_err("out-of-range member must be rejected");
        assert!(
            errs.iter()
                .any(|e| matches!(e, VerifyError::BadComMemberRef { member: 99, .. })),
            "expected BadComMemberRef, got {errs:?}"
        );
    }

    #[test]
    fn verifier_catches_early_call_on_project_interface() {
        let mut p = sample_com_program();
        // Swap the COM interface for a project `Implements` interface; the early-bound
        // call now targets a non-COM interface and must be rejected.
        p.com_interfaces[0] = ComInterface::Project(ProjectInterface {
            name: "IShape".to_string(),
            methods: vec![ProjectIfaceMethod {
                name: "Value".to_string(),
                kind: ProjectMemberKind::PropertyGet,
            }],
        });
        let errs =
            verify_program(&p).expect_err("early call on a project interface must be rejected");
        assert!(
            errs.iter()
                .any(|e| matches!(e, VerifyError::ComCallEarlyOnProjectIface { iface: 0, .. })),
            "expected ComCallEarlyOnProjectIface, got {errs:?}"
        );
    }
}
