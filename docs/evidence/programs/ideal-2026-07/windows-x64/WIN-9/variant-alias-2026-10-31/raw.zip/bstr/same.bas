Option Explicit
Private Declare PtrSafe Function NativeAlias Lib "C:/Work/DnaCalc/codex-runs/calcvba-2-variant-alias/bstr/native_variant_alias.dll" Alias "AliasVariantString" (ByRef first As Variant, ByRef second As Variant) As Long

Public Function RunProbe() As String
    Dim value As Variant
    Dim result As Long
    Dim savedError As Long
    value = "old owned string"
    result = NativeAlias(value, value)
    savedError = Err.LastDllError
    RunProbe = CStr(result) & "|" & CStr(Len(value)) & "|" & Replace(value, Chr(0), ":") & "|" & CStr(savedError)
End Function