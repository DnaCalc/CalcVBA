from pathlib import Path
import hashlib,json,re,subprocess,zipfile
repo=Path.cwd(); root=repo/'docs/evidence/programs/ideal-2026-07/core/CORE-7'
archive=root/'run12-native-long-callbacks.zip'; manifest=root/'run12-native-long-callbacks.json'
files=set(subprocess.check_output(['git','diff','HEAD','--name-only'],text=True).splitlines())
files.update(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines())
files={p for p in files if not p.startswith('.beads/') or p=='.beads/issues.jsonl'}
files.update(['Cargo.toml','Cargo.lock','.cargo/config.toml','crates/oxvba-com/src/typed_slots/factory.rs','crates/oxvba-rt-abi/src/host_entry/activation.rs','crates/oxvba-embed/tests/support/prebound_dispatch.rs','scripts/run-excel-vba-oracle.ps1','scripts/excel-vba-oracle-worker.ps1','scripts/excel-vba-oracle-guardian.ps1','scripts/run-typed-prebound-oracle.ps1'])
files.update('formal/lean/OxVba/'+n+'.lean' for n in ['RefCount','TypedContinuation','TypedReentry','ProcedureHandles'])
for folder in ['temp/calcvba12/oracle/calcvba12-native-long-callback','temp/calcvba12/oracle/calcvba12-prebound-postsync','temp/calcvba12/oracle/calcvba12-prebound-postsync-final','temp/calcvba12/native-long-callback']:
 files.update(str(p.relative_to(repo)).replace('\\','/') for p in (repo/folder).rglob('*') if p.is_file())
files.update(str(p.relative_to(repo)).replace('\\','/') for p in (repo/'temp/calcvba12').glob('byref-*') if p.is_file())
files.update(['temp/calcvba12/native-regression-next.patch','temp/calcvba12/archive-native.py'])
files={p for p in files if (repo/p).is_file() and (repo/p) not in [archive,manifest]}
check=(repo/'temp/calcvba12/byref-meta.log').read_text(); assert '[oxvba] meta check complete' in check
rows=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',check)
counts={'passed':sum(int(r[0]) for r in rows),'failed':sum(int(r[1]) for r in rows),'ignored':sum(int(r[2]) for r in rows),'suites':len(rows)}
assert counts['failed']==0
oracle=json.loads((repo/'temp/calcvba12/oracle/calcvba12-native-long-callback/results.json').read_text(encoding='utf-8-sig'))['cases'][0]
assert oracle['compile_status']=='ok' and oracle['run_status']=='ok' and oracle['run_value']=='13:13'
prebound=json.loads((repo/'temp/calcvba12/oracle/calcvba12-prebound-postsync-final/windows-scalar-interop/engine-prebound-test.json').read_text(encoding='utf-8-sig')); assert prebound['exit_code']==0
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for name in sorted(files): z.write(repo/name,name)
 z.writestr('source.patch',subprocess.check_output(['git','diff','HEAD','--binary','--','.',':(exclude)'+archive.relative_to(repo).as_posix(),':(exclude)'+manifest.relative_to(repo).as_posix()]))
manifest.write_bytes((json.dumps({'schema':'oxvba.run12.native-long-callback.development-evidence.v1','delivery':'bd-59co.2.9.20','base_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'archive':archive.name,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files_sha256':{n:hashlib.sha256((repo/n).read_bytes()).hexdigest() for n in sorted(files)},'check':counts,'oracle_value':oracle['run_value'],'owned_excel_pid':oracle['owned_excel_pid'],'prebound_test':prebound,'backends':['VM3 owning typed','native JIT owning typed'],'transports':['native vtable','prebound Invoke'],'scope':'exact native Long before/after synchronous callback synchronization; retained global/private/error/nested regressions','residuals':['bd-59co.3.5.3','bd-59co.3.6.4','bd-59co.3.5.10'],'formal':'four installed Lean abstractions pass; concrete TLS/caller/native provenance unproved; no native formal credit','certification_credit':False},indent=2)+'\n').encode())
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for n in files: assert hashlib.sha256(z.read(n)).hexdigest()==hashlib.sha256((repo/n).read_bytes()).hexdigest()
print(json.dumps(counts)); print('archive verified')
