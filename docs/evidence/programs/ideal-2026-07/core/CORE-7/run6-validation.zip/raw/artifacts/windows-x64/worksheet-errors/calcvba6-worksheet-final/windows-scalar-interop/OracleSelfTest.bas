Option Explicit

Public Function RaiseMismatch() As Variant
    Err.Raise 13
End Function

Public Function DivideByZero(ByVal divisor As Double) As Double
    DivideByZero = 1 / divisor
End Function

Public Function UntypedPlus(value)
    UntypedPlus = value + 1
End Function

Public Function UntypedTimes(value)
    UntypedTimes = value * 2
End Function

Public Function UntypedIdentity(value) As String
    UntypedIdentity = TypeName(value) & ":" & CStr(VarType(value))
End Function

' Exists only for supervisor macro-presence checks. The worker never runs it:
' worksheet formulas are calculated from COM while VBA is idle.
Public Function RunProbe() As String
    RunProbe = "worksheet-idle-probe"
End Function

