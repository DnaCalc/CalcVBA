use crate::{
    Decimal96, VarType, Variant, VbaRecord, VbaRecordLayout,
    bstr::{BStr, borrow_raw_bstr},
    object_ref::{ObjectRef, RawRuntimeIUnknown},
};
use core::ptr::NonNull;
use std::sync::Arc;

pub const ARRAY_TAG_BASE: i32 = -1_000_000_000;
pub const ARRAY_TAG_LIMIT: i32 = ARRAY_TAG_BASE + 1_000_000;
const DISPATCH_ARRAY_PAYLOAD_BASE: i32 = 20_000;

pub const VT_I2_VALUE: u16 = 0x0002;
pub const VT_I4_VALUE: u16 = 0x0003;
pub const VT_R4_VALUE: u16 = 0x0004;
pub const VT_R8_VALUE: u16 = 0x0005;
pub const VT_CY_VALUE: u16 = 0x0006;
pub const VT_DATE_VALUE: u16 = 0x0007;
pub const VT_BSTR_VALUE: u16 = 0x0008;
pub const VT_DISPATCH_VALUE: u16 = 0x0009;
pub const VT_BOOL_VALUE: u16 = 0x000B;
pub const VT_VARIANT_VALUE: u16 = 0x000C;
pub const VT_UNKNOWN_VALUE: u16 = 0x000D;
pub const VT_DECIMAL_VALUE: u16 = 0x000E;
pub const VT_I1_VALUE: u16 = 0x0010;
pub const VT_UI1_VALUE: u16 = 0x0011;
pub const VT_UI2_VALUE: u16 = 0x0012;
pub const VT_UI4_VALUE: u16 = 0x0013;
pub const VT_I8_VALUE: u16 = 0x0014;
pub const VT_UI8_VALUE: u16 = 0x0015;
pub const VT_INT_VALUE: u16 = 0x0016;
pub const VT_UINT_VALUE: u16 = 0x0017;
pub const VT_RECORD_VALUE: u16 = 0x0024;

pub const FADF_HAVEVARTYPE_VALUE: u16 = 0x0080;
pub const FADF_RECORD_VALUE: u16 = 0x0020;
/// `FADF_FIXEDSIZE` (0x0010): the SAFEARRAY may not be resized or reallocated.
/// VBA sets this on a fixed-size array (`Dim a(1 To 3)`), where `Erase`
/// reinitializes each element to its type default and keeps the array, in
/// contrast to a dynamic array (`Dim a()` + `ReDim`) whose `Erase` deallocates.
pub const FADF_FIXEDSIZE_VALUE: u16 = 0x0010;
pub const FADF_BSTR_VALUE: u16 = 0x0100;
pub const FADF_UNKNOWN_VALUE: u16 = 0x0200;
pub const FADF_DISPATCH_VALUE: u16 = 0x0400;
pub const FADF_VARIANT_VALUE: u16 = 0x0800;
const OXVBA_SAFEARRAY_OWNER_MAGIC: u32 = u32::from_le_bytes(*b"OVSA");
const OXVBA_SAFEARRAY_OWNER_VERSION: u16 = 1;

#[cfg(test)]
std::thread_local! {
    static PAYLOAD_ALLOCATION_EVENTS: core::cell::Cell<(usize, usize)> = const {
        core::cell::Cell::new((0, 0))
    };
}

#[cfg(test)]
fn note_payload_allocation() {
    PAYLOAD_ALLOCATION_EVENTS.with(|events| {
        let (allocated, freed) = events.get();
        events.set((allocated + 1, freed));
    });
}

#[cfg(test)]
fn note_payload_free() {
    PAYLOAD_ALLOCATION_EVENTS.with(|events| {
        let (allocated, freed) = events.get();
        events.set((allocated, freed + 1));
    });
}

#[cfg(test)]
fn payload_allocation_events() -> (usize, usize) {
    PAYLOAD_ALLOCATION_EVENTS.with(core::cell::Cell::get)
}

#[repr(C)]
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct SafeArrayBound {
    pub count: u32,
    pub lower: i32,
}

#[repr(C, align(8))]
struct RawSafeArrayOwnerPrefix {
    // COM Automation stores HAVEVARTYPE metadata adjacent to the descriptor.
    // The public descriptor pointer still starts at RawSafeArray.
    magic: u32,
    version: u16,
    element_vt: u16,
    // Non-null only for OxVba-owned native record SAFEARRAYs. This is not an
    // IRecordInfo pointer and must not be projected as one at COM boundaries.
    record_layout: *const VbaRecordLayout,
}

#[repr(C)]
struct RawSafeArray {
    c_dims: u16,
    f_features: u16,
    cb_elements: u32,
    c_locks: u32,
    pv_data: *mut core::ffi::c_void,
    rgsabound: [SafeArrayBound; 1],
}

#[repr(C)]
#[derive(Clone, Copy)]
struct RawDecimalArrayElement {
    reserved: u16,
    scale: u8,
    sign: u8,
    hi32: u32,
    lo32: u32,
    mid32: u32,
}

impl RawDecimalArrayElement {
    fn from_decimal96(value: Decimal96) -> Self {
        Self {
            reserved: 0,
            scale: value.scale(),
            sign: if value.is_negative() { 0x80 } else { 0 },
            hi32: value.hi,
            lo32: value.lo,
            mid32: value.mid,
        }
    }

    fn to_decimal96(self) -> Decimal96 {
        Decimal96::from_scale_sign(
            self.lo32,
            self.mid32,
            self.hi32,
            (u16::from(self.sign) << 8) | u16::from(self.scale),
        )
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum SafeArrayElementKind {
    Variant,
    I1,
    Ui1,
    I2,
    Ui2,
    I4,
    Ui4,
    I8,
    Ui8,
    Int,
    UInt,
    R4,
    R8,
    Currency,
    Date,
    Bool,
    BStr,
    Dispatch,
    Unknown,
    Decimal,
}

impl SafeArrayElementKind {
    fn from_vartype(value: u16) -> Option<Self> {
        match value {
            VT_VARIANT_VALUE => Some(Self::Variant),
            VT_I1_VALUE => Some(Self::I1),
            VT_UI1_VALUE => Some(Self::Ui1),
            VT_I2_VALUE => Some(Self::I2),
            VT_UI2_VALUE => Some(Self::Ui2),
            VT_I4_VALUE => Some(Self::I4),
            VT_UI4_VALUE => Some(Self::Ui4),
            VT_I8_VALUE => Some(Self::I8),
            VT_UI8_VALUE => Some(Self::Ui8),
            VT_INT_VALUE => Some(Self::Int),
            VT_UINT_VALUE => Some(Self::UInt),
            VT_R4_VALUE => Some(Self::R4),
            VT_R8_VALUE => Some(Self::R8),
            VT_CY_VALUE => Some(Self::Currency),
            VT_DATE_VALUE => Some(Self::Date),
            VT_BOOL_VALUE => Some(Self::Bool),
            VT_BSTR_VALUE => Some(Self::BStr),
            VT_DISPATCH_VALUE => Some(Self::Dispatch),
            VT_UNKNOWN_VALUE => Some(Self::Unknown),
            VT_DECIMAL_VALUE => Some(Self::Decimal),
            _ => None,
        }
    }

    fn element_size(self) -> usize {
        match self {
            Self::Variant => core::mem::size_of::<Variant>(),
            Self::I1 | Self::Ui1 => 1,
            Self::I2 | Self::Ui2 | Self::Bool => 2,
            Self::I4 | Self::Ui4 | Self::Int | Self::UInt | Self::R4 => 4,
            Self::I8
            | Self::Ui8
            | Self::R8
            | Self::Currency
            | Self::Date
            | Self::BStr
            | Self::Dispatch
            | Self::Unknown => 8,
            Self::Decimal => core::mem::size_of::<RawDecimalArrayElement>(),
        }
    }

    fn alignment(self) -> usize {
        match self {
            Self::Variant => core::mem::align_of::<Variant>(),
            Self::I1 | Self::Ui1 => core::mem::align_of::<u8>(),
            Self::I2 | Self::Ui2 | Self::Bool => core::mem::align_of::<u16>(),
            Self::I4 | Self::Ui4 | Self::Int | Self::UInt | Self::R4 => {
                core::mem::align_of::<u32>()
            }
            Self::I8
            | Self::Ui8
            | Self::R8
            | Self::Currency
            | Self::Date
            | Self::BStr
            | Self::Dispatch
            | Self::Unknown => core::mem::align_of::<u64>(),
            Self::Decimal => core::mem::align_of::<RawDecimalArrayElement>(),
        }
    }

    fn feature_flags(self) -> u16 {
        FADF_HAVEVARTYPE_VALUE
            | match self {
                Self::Variant => FADF_VARIANT_VALUE,
                Self::BStr => FADF_BSTR_VALUE,
                Self::Dispatch => FADF_DISPATCH_VALUE,
                Self::Unknown => FADF_UNKNOWN_VALUE,
                _ => 0,
            }
    }
}

#[repr(transparent)]
pub struct SafeArray(NonNull<RawSafeArray>);

// SAFETY: ASSUMPTION — `SafeArray` exclusively owns its descriptor and payload
// allocations (created by the payload guard and `alloc_header`, freed
// only in `Drop`), and scalar/BStr elements are plain data or independently
// owned allocations, so those move freely between threads. Object
// (VT_DISPATCH/VT_UNKNOWN) elements hold a retained reference whose
// AddRef/Release counter is an `AtomicU32`, but the FINAL release parks the
// object in a `thread_local!` termination queue and touches `Cell` state
// (`compat_release` in object_ref.rs), so soundness additionally requires that
// arrays holding object elements are dropped on the VM thread that manages
// those objects' lifecycle.
unsafe impl Send for SafeArray {}
// SAFETY: no `&self` method mutates the descriptor or payload (this module has
// no interior mutability; `c_locks` is never toggled after construction), so
// shared access performs only reads plus atomic AddRefs when object elements
// are cloned out — data-race-free.
unsafe impl Sync for SafeArray {}

unsafe fn free_raw_bstr(ptr: *mut u16) {
    // SAFETY: the caller transfers ownership of `ptr` (null or the raw BSTR a
    // SAFEARRAY slot owned, written there by `encode_element_variant`), which
    // is exactly `BStr::from_raw_bstr`'s contract; dropping the wrapper frees
    // the allocation exactly once.
    let _ = unsafe { BStr::from_raw_bstr(ptr) };
}

fn bounds_layout(dimensions: usize) -> Result<std::alloc::Layout, String> {
    if dimensions == 0 {
        return Err("SAFEARRAY must have at least one dimension".to_string());
    }
    let header = std::alloc::Layout::new::<RawSafeArray>();
    let extra = dimensions
        .checked_sub(1)
        .ok_or_else(|| "SAFEARRAY dimension underflow".to_string())?;
    let extra_bounds = std::alloc::Layout::array::<SafeArrayBound>(extra)
        .map_err(|_| "SAFEARRAY bounds layout overflow".to_string())?;
    header
        .extend(extra_bounds)
        .map(|(layout, _)| layout.pad_to_align())
        .map_err(|_| "SAFEARRAY header layout overflow".to_string())
}

fn owner_layout(dimensions: usize) -> Result<std::alloc::Layout, String> {
    let header = bounds_layout(dimensions)?;
    let total = core::mem::size_of::<RawSafeArrayOwnerPrefix>()
        .checked_add(header.size())
        .ok_or_else(|| "SAFEARRAY owner layout overflow".to_string())?;
    std::alloc::Layout::from_size_align(total, core::mem::align_of::<RawSafeArray>())
        .map_err(|_| "SAFEARRAY owner layout invalid".to_string())
}

fn payload_layout(kind: SafeArrayElementKind, count: usize) -> Result<std::alloc::Layout, String> {
    let size = kind
        .element_size()
        .checked_mul(count)
        .ok_or_else(|| "SAFEARRAY payload layout overflow".to_string())?;
    std::alloc::Layout::from_size_align(size.max(1), kind.alignment())
        .map_err(|_| "SAFEARRAY payload layout invalid".to_string())
}

fn record_payload_layout(
    layout: &VbaRecordLayout,
    count: usize,
) -> Result<std::alloc::Layout, String> {
    let size = layout
        .size()
        .checked_mul(count)
        .ok_or_else(|| "SAFEARRAY record payload layout overflow".to_string())?;
    std::alloc::Layout::from_size_align(size.max(1), layout.align())
        .map_err(|_| "SAFEARRAY record payload layout invalid".to_string())
}

fn default_bounds_for_len(len: usize) -> Result<Vec<SafeArrayBound>, String> {
    Ok(vec![SafeArrayBound {
        count: u32::try_from(len).map_err(|_| {
            format!("SAFEARRAY length {len} exceeds supported u32 element capacity")
        })?,
        lower: 0,
    }])
}

fn bounds_total_len(bounds: &[SafeArrayBound]) -> Result<usize, String> {
    let mut total = 1usize;
    for bound in bounds {
        total = total
            .checked_mul(bound.count as usize)
            .ok_or_else(|| "SAFEARRAY total element count overflowed".to_string())?;
    }
    Ok(total)
}

unsafe fn raw_bounds_slice<'a>(header: *const RawSafeArray) -> &'a [SafeArrayBound] {
    // SAFETY: callers pass a live descriptor allocated by this module. Reading
    // c_dims and forming the slice over the inline rgsabound tail mirrors
    // `SafeArray::raw_bounds` without allocating.
    let dims = unsafe { (*header).c_dims as usize };
    if dims == 0 {
        return &[];
    }
    // SAFETY: `alloc_header` initialized exactly `dims` bounds at rgsabound.
    let ptr = unsafe { core::ptr::addr_of!((*header).rgsabound).cast::<SafeArrayBound>() };
    // SAFETY: `ptr` addresses the first bound in the live descriptor allocation,
    // which `alloc_header` initialized with exactly `dims` contiguous entries.
    unsafe { core::slice::from_raw_parts(ptr, dims) }
}

fn header_prefix_ptr(header: *const RawSafeArray) -> *const RawSafeArrayOwnerPrefix {
    // SAFETY: every descriptor reaching this helper was allocated by
    // `alloc_header` with `owner_layout`, which places a
    // `RawSafeArrayOwnerPrefix` immediately before the `RawSafeArray` inside
    // the same allocation (callers adopting raw pointers promise OxVba
    // provenance per the `from_raw_*` contracts), so the `sub` stays in-bounds.
    unsafe {
        header
            .cast::<u8>()
            .sub(core::mem::size_of::<RawSafeArrayOwnerPrefix>())
            .cast::<RawSafeArrayOwnerPrefix>()
    }
}

unsafe fn validated_header_prefix(
    header: *const RawSafeArray,
) -> Option<*const RawSafeArrayOwnerPrefix> {
    let prefix = header_prefix_ptr(header);
    // SAFETY: callers guarantee `header` points at a live OxVba descriptor
    // allocated by `alloc_header`, whose owner allocation initializes the
    // prefix before the header pointer is published, so this read is in-bounds
    // and initialized for the duration of the borrow.
    let prefix_ref = unsafe { &*prefix };
    if prefix_ref.magic == OXVBA_SAFEARRAY_OWNER_MAGIC
        && prefix_ref.version == OXVBA_SAFEARRAY_OWNER_VERSION
    {
        Some(prefix)
    } else {
        None
    }
}

unsafe fn header_record_layout(header: *const RawSafeArray) -> Option<Arc<VbaRecordLayout>> {
    // SAFETY: forwards this fn's contract — `header` is a live OxVba descriptor, so
    // `validated_header_prefix` may inspect its owner prefix.
    let prefix = unsafe { validated_header_prefix(header)? };
    // SAFETY: `validated_header_prefix` returned `Some`, so `prefix` points at the
    // live, initialized owner prefix; reading its `record_layout` field is in-bounds.
    let raw = unsafe { (*prefix).record_layout };
    if raw.is_null() {
        return None;
    }
    // SAFETY: non-null record_layout pointers are stored from Arc::into_raw in
    // alloc_header and released when the SAFEARRAY descriptor is dropped.
    unsafe { Arc::increment_strong_count(raw) };
    // SAFETY: `raw` came from `Arc::into_raw` for `VbaRecordLayout`; we just bumped
    // the strong count, so reconstituting an owning `Arc` balances that increment.
    Some(unsafe { Arc::from_raw(raw) })
}

fn payload_offset(kind: SafeArrayElementKind, index: usize) -> usize {
    kind.element_size() * index
}

fn record_payload_offset(layout: &VbaRecordLayout, index: usize) -> usize {
    layout.size() * index
}

fn raw_iunknown_ptr_to_bytes(ptr: *mut RawRuntimeIUnknown) -> [u8; 8] {
    // Dispatch/Unknown SAFEARRAY elements have an exact eight-byte x64 pointer
    // carrier. Explicit exposure permits recovery after the representation is
    // copied as bytes, while the array's retained reference keeps the object live.
    u64::try_from(ptr.expose_provenance())
        .expect("SAFEARRAY object address must fit the x64 carrier")
        .to_le_bytes()
}

fn bytes_to_raw_iunknown(bytes: [u8; 8]) -> *mut RawRuntimeIUnknown {
    let address = usize::try_from(u64::from_le_bytes(bytes))
        .expect("SAFEARRAY x64 object carrier must fit the target address space");
    core::ptr::with_exposed_provenance_mut(address)
}

fn variant_i64(value: &Variant) -> Result<i64, String> {
    if matches!(value.vtype(), VarType::Empty) {
        return Ok(0);
    }
    value
        .as_i64()
        .or_else(|| value.as_i32().map(i64::from))
        .or_else(|| value.as_i16().map(i64::from))
        .or_else(|| value.as_u8().map(i64::from))
        .ok_or_else(|| format!("expected integer-compatible SAFEARRAY element, got {value:?}"))
}

fn variant_f64(value: &Variant) -> Result<f64, String> {
    value
        .as_f64()
        .or_else(|| value.as_f32().map(f64::from))
        .or_else(|| value.as_date_f64())
        .ok_or_else(|| format!("expected floating-point SAFEARRAY element, got {value:?}"))
}

unsafe fn decode_element_variant(
    kind: SafeArrayElementKind,
    payload: *const u8,
    index: usize,
) -> Result<Variant, String> {
    // SAFETY: the caller guarantees `payload` is the live element buffer built
    // by `prepare_payload_from_variants` for this same `kind`, holding more than
    // `index` fully initialized elements, so the offset stays inside that
    // allocation and `ptr` is aligned for the element type matched below.
    let ptr = unsafe { payload.add(payload_offset(kind, index)) };
    Ok(match kind {
        // SAFETY: kind == Variant, so this slot was initialized as a `Variant`
        // at encode time; it is only borrowed here long enough to clone.
        SafeArrayElementKind::Variant => unsafe { &*ptr.cast::<Variant>() }.try_clone()?,
        // SAFETY: kind == I1, so encode initialized this slot as an i8.
        SafeArrayElementKind::I1 => Variant::from_i16(i16::from(unsafe { *ptr.cast::<i8>() })),
        // SAFETY: kind == Ui1, so encode initialized this slot as a u8.
        SafeArrayElementKind::Ui1 => Variant::from_u8(unsafe { *ptr.cast::<u8>() }),
        // SAFETY: kind == I2, so encode initialized this slot as an i16.
        SafeArrayElementKind::I2 => Variant::from_i16(unsafe { *ptr.cast::<i16>() }),
        // SAFETY: kind == Ui2, so encode initialized this slot as a u16.
        SafeArrayElementKind::Ui2 => Variant::from_i32(i32::from(unsafe { *ptr.cast::<u16>() })),
        SafeArrayElementKind::I4 | SafeArrayElementKind::Int => {
            // SAFETY: kind == I4/Int, so encode initialized this slot as an i32.
            Variant::from_i32(unsafe { *ptr.cast::<i32>() })
        }
        SafeArrayElementKind::Ui4 | SafeArrayElementKind::UInt => {
            // SAFETY: kind == Ui4/UInt, so encode initialized this slot as a u32.
            Variant::from_i64(i64::from(unsafe { *ptr.cast::<u32>() }))
        }
        // SAFETY: kind == I8, so encode initialized this slot as an i64.
        SafeArrayElementKind::I8 => Variant::from_i64(unsafe { *ptr.cast::<i64>() }),
        SafeArrayElementKind::Ui8 => {
            // SAFETY: kind == Ui8, so encode initialized this slot as a u64.
            let value = unsafe { *ptr.cast::<u64>() };
            Variant::from_i64(i64::try_from(value).map_err(|_| {
                format!("VT_UI8 SAFEARRAY element {value} exceeds i64 carrier range")
            })?)
        }
        // SAFETY: kind == R4, so encode initialized this slot as an f32.
        SafeArrayElementKind::R4 => Variant::from_f32(unsafe { *ptr.cast::<f32>() }),
        // SAFETY: kind == R8, so encode initialized this slot as an f64.
        SafeArrayElementKind::R8 => Variant::from_f64(unsafe { *ptr.cast::<f64>() }),
        SafeArrayElementKind::Currency => {
            // SAFETY: kind == Currency, so encode initialized this slot as the
            // scaled-i64 currency carrier.
            Variant::from_currency_scaled_i64(unsafe { *ptr.cast::<i64>() })
        }
        // SAFETY: kind == Date, so encode initialized this slot as an f64 date serial.
        SafeArrayElementKind::Date => Variant::from_date_f64(unsafe { *ptr.cast::<f64>() }),
        // SAFETY: kind == Bool, so encode initialized this slot as a VARIANT_BOOL i16.
        SafeArrayElementKind::Bool => Variant::from_bool(unsafe { *ptr.cast::<i16>() } != 0),
        SafeArrayElementKind::BStr => {
            // SAFETY: kind == BStr, so this slot holds the raw BSTR pointer the
            // array owns. BorrowedBStr has no destructor, so cloning cannot
            // consume the slot's allocation on error or unwind.
            Variant::from_string(
                unsafe { borrow_raw_bstr(*ptr.cast::<*mut u16>()) }.try_to_owned()?,
            )
        }
        SafeArrayElementKind::Dispatch | SafeArrayElementKind::Unknown => {
            // SAFETY: kind == Dispatch/Unknown, so encode stored the 8
            // little-endian pointer bytes of a retained runtime IUnknown here.
            let raw = bytes_to_raw_iunknown(unsafe { *ptr.cast::<[u8; 8]>() });
            // SAFETY: `raw` is null or the runtime IUnknown the array still
            // holds its own retained reference on, so it is live here;
            // `from_raw_iunknown_addref` takes an additional independent
            // reference per its contract.
            let Some(object) = (unsafe { ObjectRef::from_raw_iunknown_addref(raw) }) else {
                return Err("SAFEARRAY object element carried null IUnknown pointer".to_string());
            };
            Variant::from_object_ref(object)
        }
        SafeArrayElementKind::Decimal => {
            // SAFETY: kind == Decimal, so encode initialized this slot as a
            // plain-data RawDecimalArrayElement.
            Variant::from_decimal96(unsafe { *ptr.cast::<RawDecimalArrayElement>() }.to_decimal96())
        }
    })
}

unsafe fn encode_element_variant(
    kind: SafeArrayElementKind,
    payload: *mut u8,
    index: usize,
    value: &Variant,
) -> Result<(), String> {
    // SAFETY: the caller guarantees `payload` is an allocation laid out by
    // `payload_layout(kind, len)` with `index < len`, so the offset stays
    // in-bounds and `ptr` is aligned for `kind`'s element type.
    let ptr = unsafe { payload.add(payload_offset(kind, index)) };
    if kind == SafeArrayElementKind::Variant {
        // SAFETY: kind == Variant, so the in-bounds slot computed above has
        // `Variant` size/alignment; the slot is written exactly once into the
        // fresh zeroed buffer, so `write` correctly skips dropping old contents.
        unsafe { ptr.cast::<Variant>().write(value.try_clone()?) };
        return Ok(());
    }
    match kind {
        SafeArrayElementKind::Variant => unreachable!("handled above"),
        // SAFETY: kind == I1 sized/aligned the slot for i8; plain-data write,
        // exactly once into the zeroed buffer.
        SafeArrayElementKind::I1 => unsafe {
            ptr.cast::<i8>()
                .write(i8::try_from(variant_i64(value)?).map_err(|_| {
                    format!("value {value:?} does not fit VT_I1 SAFEARRAY element")
                })?);
        },
        // SAFETY: kind == Ui1 sized/aligned the slot for u8; plain-data write,
        // exactly once into the zeroed buffer.
        SafeArrayElementKind::Ui1 => unsafe {
            ptr.cast::<u8>().write(
                u8::try_from(variant_i64(value)?).map_err(|_| {
                    format!("value {value:?} does not fit VT_UI1 SAFEARRAY element")
                })?,
            );
        },
        // SAFETY: kind == I2 sized/aligned the slot for i16; plain-data write,
        // exactly once into the zeroed buffer.
        SafeArrayElementKind::I2 => unsafe {
            ptr.cast::<i16>()
                .write(i16::try_from(variant_i64(value)?).map_err(|_| {
                    format!("value {value:?} does not fit VT_I2 SAFEARRAY element")
                })?);
        },
        // SAFETY: kind == Ui2 sized/aligned the slot for u16; plain-data write,
        // exactly once into the zeroed buffer.
        SafeArrayElementKind::Ui2 => unsafe {
            ptr.cast::<u16>().write(
                u16::try_from(variant_i64(value)?).map_err(|_| {
                    format!("value {value:?} does not fit VT_UI2 SAFEARRAY element")
                })?,
            );
        },
        // SAFETY: kind == I4/Int sized/aligned the slot for i32; plain-data
        // write, exactly once into the zeroed buffer.
        SafeArrayElementKind::I4 | SafeArrayElementKind::Int => unsafe {
            ptr.cast::<i32>()
                .write(i32::try_from(variant_i64(value)?).map_err(|_| {
                    format!("value {value:?} does not fit VT_I4 SAFEARRAY element")
                })?);
        },
        // SAFETY: kind == Ui4/UInt sized/aligned the slot for u32; plain-data
        // write, exactly once into the zeroed buffer.
        SafeArrayElementKind::Ui4 | SafeArrayElementKind::UInt => unsafe {
            ptr.cast::<u32>().write(
                u32::try_from(variant_i64(value)?).map_err(|_| {
                    format!("value {value:?} does not fit VT_UI4 SAFEARRAY element")
                })?,
            );
        },
        // SAFETY: kind == I8 sized/aligned the slot for i64; plain-data write,
        // exactly once into the zeroed buffer.
        SafeArrayElementKind::I8 => unsafe {
            ptr.cast::<i64>().write(variant_i64(value)?);
        },
        // SAFETY: kind == Ui8 sized/aligned the slot for u64; plain-data write,
        // exactly once into the zeroed buffer.
        SafeArrayElementKind::Ui8 => unsafe {
            ptr.cast::<u64>().write(
                u64::try_from(variant_i64(value)?).map_err(|_| {
                    format!("value {value:?} does not fit VT_UI8 SAFEARRAY element")
                })?,
            );
        },
        // SAFETY: kind == R4 sized/aligned the slot for f32; plain-data write,
        // exactly once into the zeroed buffer.
        SafeArrayElementKind::R4 => unsafe {
            ptr.cast::<f32>().write(variant_f64(value)? as f32);
        },
        // SAFETY: kind == R8 sized/aligned the slot for f64; plain-data write,
        // exactly once into the zeroed buffer.
        SafeArrayElementKind::R8 => unsafe {
            ptr.cast::<f64>().write(variant_f64(value)?);
        },
        // SAFETY: kind == Currency sized/aligned the slot for the scaled-i64
        // currency carrier; plain-data write, exactly once into the zeroed buffer.
        SafeArrayElementKind::Currency => unsafe {
            ptr.cast::<i64>().write(
                value
                    .as_currency_scaled_i64()
                    .ok_or_else(|| format!("expected Currency SAFEARRAY element, got {value:?}"))?,
            );
        },
        // SAFETY: kind == Date sized/aligned the slot for the f64 date serial;
        // plain-data write, exactly once into the zeroed buffer.
        SafeArrayElementKind::Date => unsafe {
            ptr.cast::<f64>().write(
                value
                    .as_date_f64()
                    .or_else(|| value.as_f64())
                    .ok_or_else(|| format!("expected Date SAFEARRAY element, got {value:?}"))?,
            );
        },
        // SAFETY: kind == Bool sized/aligned the slot for the VARIANT_BOOL i16;
        // plain-data write, exactly once into the zeroed buffer.
        SafeArrayElementKind::Bool => unsafe {
            ptr.cast::<i16>().write(
                if value
                    .as_bool()
                    .ok_or_else(|| format!("expected Bool SAFEARRAY element, got {value:?}"))?
                {
                    -1
                } else {
                    0
                },
            );
        },
        // SAFETY: kind == BStr sized/aligned the slot for a pointer; ownership
        // of the freshly allocated raw BSTR transfers into the slot, to be
        // freed exactly once by `drop_element`.
        SafeArrayElementKind::BStr => unsafe {
            let text = value
                .try_as_bstr()?
                .ok_or_else(|| format!("expected String SAFEARRAY element, got {value:?}"))?;
            ptr.cast::<*mut u16>().write(text.into_raw_bstr());
        },
        // SAFETY: kind == Dispatch/Unknown sized/aligned the slot for the
        // 8 pointer bytes; `into_raw_iunknown` transfers the ObjectRef's retained
        // reference into the slot, so the array owns exactly one IUnknown
        // reference, released by `drop_element`.
        SafeArrayElementKind::Dispatch | SafeArrayElementKind::Unknown => unsafe {
            let object = value
                .as_object_ref()
                .ok_or_else(|| format!("expected Object SAFEARRAY element, got {value:?}"))?;
            let raw = object.into_raw_iunknown();
            ptr.cast::<[u8; 8]>().write(raw_iunknown_ptr_to_bytes(raw));
        },
        // SAFETY: kind == Decimal sized/aligned the slot for the plain-data
        // RawDecimalArrayElement; written exactly once into the zeroed buffer.
        SafeArrayElementKind::Decimal => unsafe {
            ptr.cast::<RawDecimalArrayElement>()
                .write(RawDecimalArrayElement::from_decimal96(
                    value.as_decimal96().ok_or_else(|| {
                        format!("expected Decimal SAFEARRAY element, got {value:?}")
                    })?,
                ));
        },
    }
    Ok(())
}

/// # Safety
/// `payload` must point at this array's element buffer holding more than `index`
/// initialized elements of `kind`, so the `index`-th slot is live and writable.
unsafe fn replace_element_variant(
    kind: SafeArrayElementKind,
    payload: *mut u8,
    index: usize,
    value: &Variant,
) -> Result<(), String> {
    // SAFETY: `payload_offset` is `element_size(kind) * index`, and the contract
    // guarantees `index` is in range, so this lands on the `index`-th element slot.
    let ptr = unsafe { payload.add(payload_offset(kind, index)) };
    match kind {
        SafeArrayElementKind::Variant => {
            // SAFETY: kind == Variant, so the slot holds an initialized `Variant`;
            // `replace` writes the new clone and yields the old value to drop.
            let old = unsafe { ptr.cast::<Variant>().replace(value.try_clone()?) };
            drop(old);
        }
        // SAFETY: kind == I1, so the slot is a live, aligned `i8` scalar.
        SafeArrayElementKind::I1 => unsafe {
            *ptr.cast::<i8>() = i8::try_from(variant_i64(value)?)
                .map_err(|_| format!("value {value:?} does not fit VT_I1 SAFEARRAY element"))?;
        },
        // SAFETY: kind == Ui1, so the slot is a live, aligned `u8` scalar.
        SafeArrayElementKind::Ui1 => unsafe {
            *ptr.cast::<u8>() = u8::try_from(variant_i64(value)?)
                .map_err(|_| format!("value {value:?} does not fit VT_UI1 SAFEARRAY element"))?;
        },
        // SAFETY: kind == I2, so the slot is a live, aligned `i16` scalar.
        SafeArrayElementKind::I2 => unsafe {
            *ptr.cast::<i16>() = i16::try_from(variant_i64(value)?)
                .map_err(|_| format!("value {value:?} does not fit VT_I2 SAFEARRAY element"))?;
        },
        // SAFETY: kind == Ui2, so the slot is a live, aligned `u16` scalar.
        SafeArrayElementKind::Ui2 => unsafe {
            *ptr.cast::<u16>() = u16::try_from(variant_i64(value)?)
                .map_err(|_| format!("value {value:?} does not fit VT_UI2 SAFEARRAY element"))?;
        },
        // SAFETY: kind == I4/Int, so the slot is a live, aligned `i32` scalar.
        SafeArrayElementKind::I4 | SafeArrayElementKind::Int => unsafe {
            *ptr.cast::<i32>() = i32::try_from(variant_i64(value)?)
                .map_err(|_| format!("value {value:?} does not fit VT_I4 SAFEARRAY element"))?;
        },
        // SAFETY: kind == Ui4/UInt, so the slot is a live, aligned `u32` scalar.
        SafeArrayElementKind::Ui4 | SafeArrayElementKind::UInt => unsafe {
            *ptr.cast::<u32>() = u32::try_from(variant_i64(value)?)
                .map_err(|_| format!("value {value:?} does not fit VT_UI4 SAFEARRAY element"))?;
        },
        // SAFETY: kind == I8, so the slot is a live, aligned `i64` scalar.
        SafeArrayElementKind::I8 => unsafe {
            *ptr.cast::<i64>() = variant_i64(value)?;
        },
        // SAFETY: kind == Ui8, so the slot is a live, aligned `u64` scalar.
        SafeArrayElementKind::Ui8 => unsafe {
            *ptr.cast::<u64>() = u64::try_from(variant_i64(value)?)
                .map_err(|_| format!("value {value:?} does not fit VT_UI8 SAFEARRAY element"))?;
        },
        // SAFETY: kind == R4, so the slot is a live, aligned `f32` scalar.
        SafeArrayElementKind::R4 => unsafe {
            *ptr.cast::<f32>() = variant_f64(value)? as f32;
        },
        // SAFETY: kind == R8, so the slot is a live, aligned `f64` scalar.
        SafeArrayElementKind::R8 => unsafe {
            *ptr.cast::<f64>() = variant_f64(value)?;
        },
        // SAFETY: kind == Currency, stored as a scaled `i64`; slot is an aligned `i64`.
        SafeArrayElementKind::Currency => unsafe {
            *ptr.cast::<i64>() = value
                .as_currency_scaled_i64()
                .ok_or_else(|| format!("expected Currency SAFEARRAY element, got {value:?}"))?;
        },
        // SAFETY: kind == Date, stored as an `f64` serial; slot is an aligned `f64`.
        SafeArrayElementKind::Date => unsafe {
            *ptr.cast::<f64>() = value
                .as_date_f64()
                .or_else(|| value.as_f64())
                .ok_or_else(|| format!("expected Date SAFEARRAY element, got {value:?}"))?;
        },
        // SAFETY: kind == Bool, stored as a VBA `i16` (-1/0); slot is an aligned `i16`.
        SafeArrayElementKind::Bool => unsafe {
            *ptr.cast::<i16>() = if value
                .as_bool()
                .ok_or_else(|| format!("expected Bool SAFEARRAY element, got {value:?}"))?
            {
                -1
            } else {
                0
            };
        },
        // SAFETY: kind == BStr, so the slot owns a BSTR carrier pointer; replace it
        // with the freshly allocated BSTR and free the previous one.
        SafeArrayElementKind::BStr => unsafe {
            let text = value
                .try_as_bstr()?
                .ok_or_else(|| format!("expected String SAFEARRAY element, got {value:?}"))?;
            let old = ptr.cast::<*mut u16>().replace(text.into_raw_bstr());
            free_raw_bstr(old);
        },
        // SAFETY: kind == Dispatch/Unknown, so the slot owns a raw IUnknown pointer
        // (as 8 bytes); store the new owned reference and release the previous one.
        SafeArrayElementKind::Dispatch | SafeArrayElementKind::Unknown => unsafe {
            let object = value
                .as_object_ref()
                .ok_or_else(|| format!("expected Object SAFEARRAY element, got {value:?}"))?;
            let raw = object.into_raw_iunknown();
            let old = ptr
                .cast::<[u8; 8]>()
                .replace(raw_iunknown_ptr_to_bytes(raw));
            if let Some(object) = ObjectRef::from_raw_iunknown_owned(bytes_to_raw_iunknown(old)) {
                drop(object);
            }
        },
        // SAFETY: kind == Decimal, so the slot is a live, aligned `RawDecimalArrayElement`.
        SafeArrayElementKind::Decimal => unsafe {
            *ptr.cast::<RawDecimalArrayElement>() = RawDecimalArrayElement::from_decimal96(
                value
                    .as_decimal96()
                    .ok_or_else(|| format!("expected Decimal SAFEARRAY element, got {value:?}"))?,
            );
        },
    }
    Ok(())
}

unsafe fn drop_element(kind: SafeArrayElementKind, payload: *mut u8, index: usize) {
    // SAFETY: the caller guarantees `payload` holds more than `index`
    // initialized elements of `kind` and visits each index at most once, so
    // the offset is in-bounds and the slot still owns its resource.
    let ptr = unsafe { payload.add(payload_offset(kind, index)) };
    match kind {
        // SAFETY: kind == Variant, so the slot holds an initialized, not yet
        // dropped `Variant` (callers drop each index exactly once).
        SafeArrayElementKind::Variant => unsafe { core::ptr::drop_in_place(ptr.cast::<Variant>()) },
        // SAFETY: kind == BStr, so the slot holds the array-owned raw BSTR
        // pointer written at encode time; ownership transfers to
        // `free_raw_bstr`, which frees it exactly once.
        SafeArrayElementKind::BStr => unsafe { free_raw_bstr(*ptr.cast::<*mut u16>()) },
        // SAFETY: kind == Dispatch/Unknown, so the slot holds the pointer bytes
        // of the array's single retained IUnknown reference (taken at encode
        // time); `from_raw_iunknown_owned` adopts and releases exactly that
        // reference, per its ownership-transfer contract.
        SafeArrayElementKind::Dispatch | SafeArrayElementKind::Unknown => unsafe {
            let raw = bytes_to_raw_iunknown(*ptr.cast::<[u8; 8]>());
            if let Some(object) = ObjectRef::from_raw_iunknown_owned(raw) {
                drop(object);
            }
        },
        _ => {}
    }
}

unsafe fn free_payload(kind: SafeArrayElementKind, payload: *mut core::ffi::c_void, count: usize) {
    if payload.is_null() || count == 0 {
        return;
    }
    let raw = payload.cast::<u8>();
    let mut index = 0usize;
    while index < count {
        // SAFETY: `payload` was checked non-null above and the caller passes
        // the same `kind`/`count` the buffer was built with, so every
        // `index < count` names an initialized element, dropped exactly once here.
        unsafe { drop_element(kind, raw, index) };
        index += 1;
    }
    if let Ok(layout) = payload_layout(kind, count) {
        // SAFETY: `raw` was returned by `alloc_zeroed` with this same
        // `payload_layout(kind, count)`; all elements were dropped above and
        // nothing reads the buffer after this point.
        unsafe { std::alloc::dealloc(raw, layout) };
        #[cfg(test)]
        note_payload_free();
    }
}

enum PayloadConstructionKind {
    Intrinsic(SafeArrayElementKind),
    Record(Arc<VbaRecordLayout>),
}

/// Owns a raw SAFEARRAY payload from allocation until descriptor adoption.
///
/// `initialized` advances only after a complete element clone. Drop therefore
/// destroys exactly the live prefix and deallocates the payload on every returned
/// error or unwind, including one that occurs after the payload is complete but
/// before `alloc_header` adopts its pointer.
struct PayloadConstructionGuard {
    raw: NonNull<u8>,
    allocation: std::alloc::Layout,
    kind: PayloadConstructionKind,
    initialized: usize,
    armed: bool,
}

impl PayloadConstructionGuard {
    fn intrinsic(kind: SafeArrayElementKind, count: usize) -> Result<Self, String> {
        let allocation = payload_layout(kind, count)?;
        Self::allocate(
            allocation,
            PayloadConstructionKind::Intrinsic(kind),
            "safearray-intrinsic-payload-allocation",
            "failed to allocate SAFEARRAY payload",
        )
    }

    fn record(layout: &Arc<VbaRecordLayout>, count: usize) -> Result<Self, String> {
        let allocation = record_payload_layout(layout, count)?;
        Self::allocate(
            allocation,
            PayloadConstructionKind::Record(Arc::clone(layout)),
            "safearray-record-payload-allocation",
            "failed to allocate SAFEARRAY record payload",
        )
    }

    fn allocate(
        allocation: std::alloc::Layout,
        kind: PayloadConstructionKind,
        boundary: &'static str,
        allocation_error: &'static str,
    ) -> Result<Self, String> {
        crate::vba_record::owning_boundary(boundary)?;
        // SAFETY: both payload layout helpers return a non-zero-size layout;
        // the null allocation result is converted to a deterministic error.
        let raw = unsafe { std::alloc::alloc_zeroed(allocation) };
        let raw = NonNull::new(raw).ok_or_else(|| allocation_error.to_string())?;
        #[cfg(test)]
        note_payload_allocation();
        Ok(Self {
            raw,
            allocation,
            kind,
            initialized: 0,
            armed: true,
        })
    }

    fn payload_ptr(&self) -> *mut core::ffi::c_void {
        self.raw.as_ptr().cast()
    }

    fn mark_initialized(&mut self) {
        self.initialized += 1;
    }

    fn mark_all_initialized(&mut self, count: usize) {
        self.initialized = count;
    }

    fn disarm(mut self) {
        self.armed = false;
    }
}

impl Drop for PayloadConstructionGuard {
    fn drop(&mut self) {
        if !self.armed {
            return;
        }
        match &self.kind {
            PayloadConstructionKind::Intrinsic(kind) => {
                for index in 0..self.initialized {
                    // SAFETY: only completely encoded elements increment
                    // `initialized`; each prefix element is dropped once here.
                    unsafe { drop_element(*kind, self.raw.as_ptr(), index) };
                }
            }
            PayloadConstructionKind::Record(layout) => {
                for index in 0..self.initialized {
                    // SAFETY: only complete `clone_into_raw` results increment the
                    // prefix, so this is one drop of each live same-layout record.
                    unsafe {
                        VbaRecord::drop_raw(
                            self.raw.as_ptr().add(record_payload_offset(layout, index)),
                            layout,
                        )
                    };
                }
            }
        }
        // SAFETY: this armed guard uniquely owns the allocation; every initialized
        // element was dropped above and the pointer has not been adopted by a header.
        unsafe { std::alloc::dealloc(self.raw.as_ptr(), self.allocation) };
        #[cfg(test)]
        note_payload_free();
    }
}

fn prepare_payload_from_variants(
    kind: SafeArrayElementKind,
    values: &[Variant],
) -> Result<Option<PayloadConstructionGuard>, String> {
    if values.is_empty() {
        return Ok(None);
    }
    let mut payload = PayloadConstructionGuard::intrinsic(kind, values.len())?;
    for (index, value) in values.iter().enumerate() {
        crate::vba_record::owning_boundary("safearray-intrinsic-element-clone")?;
        // SAFETY: the guard allocation has `values.len()` slots of `kind`; this
        // index is written exactly once and counted only after complete success.
        unsafe { encode_element_variant(kind, payload.raw.as_ptr(), index, value)? };
        payload.mark_initialized();
    }
    Ok(Some(payload))
}

fn prepare_record_payload_from_records(
    layout: &Arc<VbaRecordLayout>,
    values: &[VbaRecord],
) -> Result<Option<PayloadConstructionGuard>, String> {
    if values.is_empty() {
        return Ok(None);
    }
    let mut payload = PayloadConstructionGuard::record(layout, values.len())?;
    for (index, value) in values.iter().enumerate() {
        if value.layout().as_ref() != layout.as_ref() {
            return Err("SAFEARRAY record element layout mismatch".to_string());
        }
        crate::vba_record::owning_boundary("safearray-record-element-clone")?;
        // SAFETY: this is the in-bounds uninitialized `index`-th same-layout
        // record slot. `clone_into_raw` leaves it untouched on failure.
        unsafe {
            value.clone_into_raw(
                payload
                    .raw
                    .as_ptr()
                    .add(record_payload_offset(layout, index)),
            )?
        };
        payload.mark_initialized();
    }
    Ok(Some(payload))
}

/// # Safety
/// `payload` must be a `record_payload_layout(layout, count)` allocation holding
/// `count` initialized records of `layout` (or null), freed exactly once here.
unsafe fn free_record_payload(
    layout: &VbaRecordLayout,
    payload: *mut core::ffi::c_void,
    count: usize,
) {
    let raw = payload.cast::<u8>();
    if raw.is_null() {
        return;
    }
    let mut index = 0usize;
    while index < count {
        // SAFETY: every `index < count` names an initialized record at its
        // `layout.size()`-strided offset, dropped exactly once on this free.
        unsafe { VbaRecord::drop_raw(raw.add(record_payload_offset(layout, index)), layout) };
        index += 1;
    }
    if let Ok(payload_layout) = record_payload_layout(layout, count) {
        // SAFETY: `raw` came from `alloc_zeroed` with this same `payload_layout`;
        // all records were dropped above and nothing reads the buffer afterward.
        unsafe { std::alloc::dealloc(raw, payload_layout) };
        #[cfg(test)]
        note_payload_free();
    }
}

fn alloc_header(
    bounds: &[SafeArrayBound],
    element_vt: u16,
    cb_elements: usize,
    pv_data: *mut core::ffi::c_void,
    record_layout: Option<Arc<VbaRecordLayout>>,
) -> Result<NonNull<RawSafeArray>, String> {
    let c_dims = u16::try_from(bounds.len())
        .map_err(|_| "SAFEARRAY dimension count exceeds u16 capacity".to_string())?;
    let cb_elements = u32::try_from(cb_elements)
        .map_err(|_| "SAFEARRAY cbElements exceeds u32 capacity".to_string())?;
    let f_features = if element_vt == VT_RECORD_VALUE {
        FADF_HAVEVARTYPE_VALUE | FADF_RECORD_VALUE
    } else {
        SafeArrayElementKind::from_vartype(element_vt)
            .map(SafeArrayElementKind::feature_flags)
            .unwrap_or(FADF_HAVEVARTYPE_VALUE)
    };
    let layout = owner_layout(bounds.len())?;
    crate::vba_record::owning_boundary("safearray-header-adoption")?;
    // SAFETY: `layout` has non-zero size (owner prefix plus at least the
    // RawSafeArray header), satisfying `alloc_zeroed`; allocation failure is
    // handled by the NonNull check below.
    let raw_owner = unsafe { std::alloc::alloc_zeroed(layout) };
    let Some(raw_owner) = NonNull::new(raw_owner) else {
        return Err("failed to allocate SAFEARRAY header".to_string());
    };
    crate::live_counters::safearray_allocated();
    // SAFETY: `raw_owner` is a fresh zeroed allocation of
    // `owner_layout(bounds.len())`: a RawSafeArrayOwnerPrefix followed by a
    // RawSafeArray header with `bounds.len()` bounds entries (one inline plus
    // `bounds.len() - 1` trailing). All writes below stay inside that
    // allocation, the size-derived prefix offset keeps the header aligned, `bounds`
    // provides exactly `bounds.len()` entries for the non-overlapping copy
    // into the fresh allocation, and the header pointer offsets a NonNull base
    // by a constant within the allocation — justifying `new_unchecked`.
    unsafe {
        raw_owner
            .cast::<RawSafeArrayOwnerPrefix>()
            .as_ptr()
            .write(RawSafeArrayOwnerPrefix {
                magic: OXVBA_SAFEARRAY_OWNER_MAGIC,
                version: OXVBA_SAFEARRAY_OWNER_VERSION,
                element_vt,
                record_layout: record_layout
                    .map(Arc::into_raw)
                    .unwrap_or(core::ptr::null()),
            });
        let header = raw_owner
            .as_ptr()
            .add(core::mem::size_of::<RawSafeArrayOwnerPrefix>())
            .cast::<RawSafeArray>();
        (*header).c_dims = c_dims;
        (*header).f_features = f_features;
        (*header).cb_elements = cb_elements;
        (*header).c_locks = 0;
        (*header).pv_data = pv_data;
        let dst = core::ptr::addr_of_mut!((*header).rgsabound).cast::<SafeArrayBound>();
        core::ptr::copy_nonoverlapping(bounds.as_ptr(), dst, bounds.len());
        Ok(NonNull::new_unchecked(header))
    }
}

impl SafeArray {
    pub fn supports_intrinsic_element_vartype(element_vt: u16) -> bool {
        SafeArrayElementKind::from_vartype(element_vt).is_some()
    }

    fn supports_zeroed_scalar_payload(kind: SafeArrayElementKind) -> bool {
        matches!(
            kind,
            SafeArrayElementKind::I1
                | SafeArrayElementKind::Ui1
                | SafeArrayElementKind::I2
                | SafeArrayElementKind::Ui2
                | SafeArrayElementKind::I4
                | SafeArrayElementKind::Ui4
                | SafeArrayElementKind::I8
                | SafeArrayElementKind::Ui8
                | SafeArrayElementKind::Int
                | SafeArrayElementKind::UInt
                | SafeArrayElementKind::R4
                | SafeArrayElementKind::R8
                | SafeArrayElementKind::Currency
                | SafeArrayElementKind::Date
                | SafeArrayElementKind::Bool
                | SafeArrayElementKind::Decimal
        )
    }

    fn from_bounds_and_variants(
        bounds: Vec<SafeArrayBound>,
        element_vt: u16,
        values: Option<Vec<Variant>>,
    ) -> Result<Self, String> {
        let kind = SafeArrayElementKind::from_vartype(element_vt).ok_or_else(|| {
            format!("unsupported intrinsic SAFEARRAY element vartype 0x{element_vt:04X}")
        })?;
        let expected_len = bounds_total_len(&bounds)?;
        let payload = match values {
            Some(values) => {
                if values.len() != expected_len {
                    return Err(format!(
                        "SAFEARRAY payload length {} does not match shape length {}",
                        values.len(),
                        expected_len
                    ));
                }
                prepare_payload_from_variants(kind, &values)?
            }
            None => None,
        };
        let pv_data = payload
            .as_ref()
            .map_or(core::ptr::null_mut(), PayloadConstructionGuard::payload_ptr);
        let header = alloc_header(&bounds, element_vt, kind.element_size(), pv_data, None)?;
        if let Some(payload) = payload {
            payload.disarm();
        }
        Ok(Self(header))
    }

    pub fn from_vba_records_nd(
        bounds: Vec<SafeArrayBound>,
        layout: Arc<VbaRecordLayout>,
        values: Vec<VbaRecord>,
    ) -> Result<Self, String> {
        let expected_len = bounds_total_len(&bounds)?;
        if values.len() != expected_len {
            return Err(format!(
                "SAFEARRAY payload length {} does not match shape length {}",
                values.len(),
                expected_len
            ));
        }
        let payload = prepare_record_payload_from_records(&layout, &values)?;
        let pv_data = payload
            .as_ref()
            .map_or(core::ptr::null_mut(), PayloadConstructionGuard::payload_ptr);
        let header = alloc_header(
            &bounds,
            VT_RECORD_VALUE,
            layout.size(),
            pv_data,
            Some(layout.clone()),
        )?;
        if let Some(payload) = payload {
            payload.disarm();
        }
        Ok(Self(header))
    }

    pub fn vector(len: usize) -> Self {
        Self::from_bounds_and_variants(
            default_bounds_for_len(len).expect("vector bounds should fit SAFEARRAY capacity"),
            VT_VARIANT_VALUE,
            None,
        )
        .expect("shape-only SAFEARRAY allocation should succeed")
    }

    pub fn from_shape(bounds: Vec<SafeArrayBound>) -> Result<Self, String> {
        Self::from_bounds_and_variants(bounds, VT_VARIANT_VALUE, None)
    }

    pub fn from_shape_typed(bounds: Vec<SafeArrayBound>, element_vt: u16) -> Result<Self, String> {
        Self::from_bounds_and_variants(bounds, element_vt, None)
    }

    pub fn from_zeroed_typed_scalars_nd(
        bounds: Vec<SafeArrayBound>,
        element_vt: u16,
    ) -> Result<Self, String> {
        let kind = SafeArrayElementKind::from_vartype(element_vt).ok_or_else(|| {
            format!("unsupported intrinsic SAFEARRAY element vartype 0x{element_vt:04X}")
        })?;
        if !Self::supports_zeroed_scalar_payload(kind) {
            return Err(format!(
                "SAFEARRAY element vartype 0x{element_vt:04X} cannot be defaulted by zeroed scalar payload"
            ));
        }
        let expected_len = bounds_total_len(&bounds)?;
        let payload = if expected_len == 0 {
            None
        } else {
            let mut payload = PayloadConstructionGuard::intrinsic(kind, expected_len)?;
            // All admitted scalar kinds have a complete all-zero default, so the
            // entire prefix is live immediately after the zeroed allocation.
            payload.mark_all_initialized(expected_len);
            Some(payload)
        };
        let pv_data = payload
            .as_ref()
            .map_or(core::ptr::null_mut(), PayloadConstructionGuard::payload_ptr);
        let header = alloc_header(&bounds, element_vt, kind.element_size(), pv_data, None)?;
        if let Some(payload) = payload {
            payload.disarm();
        }
        Ok(Self(header))
    }

    pub fn from_variants(values: Vec<Variant>) -> Self {
        let len = values.len();
        Self::from_bounds_and_variants(
            default_bounds_for_len(len).expect("value bounds should fit SAFEARRAY capacity"),
            VT_VARIANT_VALUE,
            Some(values),
        )
        .expect("SAFEARRAY payload allocation should succeed for supported canonical variants")
    }

    pub fn from_variants_nd(bounds: Vec<SafeArrayBound>, values: Vec<Variant>) -> Self {
        Self::from_bounds_and_variants(bounds, VT_VARIANT_VALUE, Some(values)).expect(
            "SAFEARRAY nd payload allocation should succeed for supported canonical variants",
        )
    }

    pub fn from_typed_variants(element_vt: u16, values: Vec<Variant>) -> Result<Self, String> {
        let len = values.len();
        Self::from_bounds_and_variants(default_bounds_for_len(len)?, element_vt, Some(values))
    }

    pub fn from_typed_variants_nd(
        bounds: Vec<SafeArrayBound>,
        element_vt: u16,
        values: Vec<Variant>,
    ) -> Result<Self, String> {
        Self::from_bounds_and_variants(bounds, element_vt, Some(values))
    }

    pub fn from_shape_and_variants(
        bounds: Vec<SafeArrayBound>,
        values: Vec<Variant>,
    ) -> Result<Self, String> {
        Self::from_bounds_and_variants(bounds, VT_VARIANT_VALUE, Some(values))
    }

    pub fn dimensions(&self) -> u8 {
        // SAFETY: `self.0` is the descriptor `alloc_header` produced and this
        // value owns until `Drop`, so reading its `c_dims` field is valid.
        unsafe { (*self.0.as_ptr()).c_dims as u8 }
    }

    pub fn element_vartype(&self) -> u16 {
        // SAFETY: `self.0` was produced by `alloc_header` (the only
        // construction path), which placed and initialized the owner prefix
        // immediately before the header in the same allocation, exactly what
        // `validated_header_prefix` requires of its caller.
        let prefix = unsafe { validated_header_prefix(self.0.as_ptr()) }
            .expect("SAFEARRAY descriptor is not owned by OxVba");
        // SAFETY: `prefix` was just validated against this value's live owner
        // allocation, so reading `element_vt` is in-bounds and initialized.
        unsafe { (*prefix).element_vt }
    }

    pub fn feature_flags(&self) -> u16 {
        // SAFETY: `self.0` is this value's live descriptor (allocated by
        // `alloc_header`, freed only in `Drop`), so reading `f_features` is valid.
        unsafe { (*self.0.as_ptr()).f_features }
    }

    /// Whether this SAFEARRAY carries `FADF_FIXEDSIZE` — i.e. it is a fixed-size
    /// array (`Dim a(1 To 3)`) whose `Erase` resets elements rather than freeing
    /// the storage. The bit lives in the descriptor's `fFeatures`, so it travels
    /// with [`Clone`] and across the COM boundary exactly like the other FADF
    /// flags.
    pub fn is_fixed_size(&self) -> bool {
        self.feature_flags() & FADF_FIXEDSIZE_VALUE != 0
    }

    /// Set or clear the descriptor's `FADF_FIXEDSIZE` bit in place.
    pub fn set_fixed_size(&mut self, fixed: bool) {
        // SAFETY: `self.0` is this value's live descriptor and `&mut self`
        // guarantees exclusive access, so toggling the `f_features` bit is a
        // sound in-bounds write.
        unsafe {
            let header = self.0.as_ptr();
            if fixed {
                (*header).f_features |= FADF_FIXEDSIZE_VALUE;
            } else {
                (*header).f_features &= !FADF_FIXEDSIZE_VALUE;
            }
        }
    }

    /// Consume `self`, setting/clearing `FADF_FIXEDSIZE`, and return it — a
    /// builder-style convenience over [`Self::set_fixed_size`].
    #[must_use]
    pub fn with_fixed_size(mut self, fixed: bool) -> Self {
        self.set_fixed_size(fixed);
        self
    }

    fn element_kind(&self) -> SafeArrayElementKind {
        SafeArrayElementKind::from_vartype(self.element_vartype())
            .expect("internal SAFEARRAY element vartype should remain supported")
    }

    pub fn vba_record_layout(&self) -> Option<Arc<VbaRecordLayout>> {
        if self.element_vartype() != VT_RECORD_VALUE {
            return None;
        }
        // SAFETY: `self.0` is this value's own live OxVba descriptor, satisfying
        // `header_record_layout`'s contract.
        unsafe { header_record_layout(self.0.as_ptr()) }
    }

    fn raw_bounds(&self) -> Vec<SafeArrayBound> {
        // SAFETY: `self.0` is this value's live descriptor; the helper only
        // borrows the initialized inline bounds tail.
        unsafe { raw_bounds_slice(self.0.as_ptr()) }.to_vec()
    }

    pub fn len(&self) -> usize {
        // SAFETY: `self.0` is this value's live descriptor; the helper only
        // borrows the initialized inline bounds tail.
        bounds_total_len(unsafe { raw_bounds_slice(self.0.as_ptr()) }).unwrap_or(0)
    }

    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    pub fn effective_len(&self) -> usize {
        self.len()
    }

    pub fn bounds(&self) -> Option<Vec<SafeArrayBound>> {
        let bounds = self.raw_bounds();
        if bounds.is_empty() {
            return None;
        }
        Some(bounds)
    }

    fn bounds_for_shape(&self) -> Vec<SafeArrayBound> {
        self.bounds()
            .unwrap_or_else(|| default_bounds_for_len(self.len()).unwrap_or_default())
    }

    pub fn variant_elements(&self) -> Option<Vec<Variant>> {
        self.try_variant_elements()
            .expect("SAFEARRAY payload should decode into canonical Variants")
    }

    pub(crate) fn try_variant_elements(&self) -> Result<Option<Vec<Variant>>, String> {
        // SAFETY: `self.0` is this value's live descriptor, so reading
        // `pv_data` is valid; the null (shape-only) case is handled just below.
        let data = unsafe { (*self.0.as_ptr()).pv_data.cast::<u8>() };
        if data.is_null() {
            return Ok(None);
        }
        let len = self.len();
        if let Some(layout) = self.vba_record_layout() {
            let mut values = Vec::with_capacity(len);
            let mut index = 0usize;
            while index < len {
                // SAFETY: `data` is the record payload of `self.len()` records strided
                // by `layout.size()`, and `index < self.len()`, so this is in-bounds.
                let ptr = unsafe { data.add(record_payload_offset(&layout, index)) };
                values.push(Variant::from_vba_record(
                    // SAFETY: `ptr` references the live `index`-th record payload laid
                    // out by `layout`; `clone_from_raw` deep-copies without consuming it.
                    unsafe { VbaRecord::clone_from_raw(ptr, layout.clone()) }?,
                ));
                index += 1;
            }
            return Ok(Some(values));
        }
        let kind = self.element_kind();
        let mut values = Vec::with_capacity(len);
        let mut index = 0usize;
        while index < len {
            // SAFETY: `data` is the non-null payload built by
            // `prepare_payload_from_variants` for exactly `self.len()` initialized
            // elements of this descriptor's `kind`, and `index < self.len()`.
            values.push(unsafe { decode_element_variant(kind, data, index) }?);
            index += 1;
        }
        Ok(Some(values))
    }

    pub fn variant_element(&self, index: usize) -> Result<Variant, String> {
        let len = self.len();
        if index >= len {
            return Err(format!(
                "SAFEARRAY index {index} out of range for length {len}"
            ));
        }
        // SAFETY: `self.0` is this value's live descriptor; reading `pv_data` is
        // valid, and the null (shape-only) case is handled immediately below.
        let data = unsafe { (*self.0.as_ptr()).pv_data.cast::<u8>() };
        if data.is_null() {
            return Err("SAFEARRAY has no materialized element payload".to_string());
        }
        if let Some(layout) = self.vba_record_layout() {
            // SAFETY: `index < self.len()` (checked above) and `data` is the record
            // payload strided by `layout.size()`, so this offset is in-bounds.
            let ptr = unsafe { data.add(record_payload_offset(&layout, index)) };
            // SAFETY: `ptr` references the live `index`-th record payload of `layout`.
            return Ok(Variant::from_vba_record(unsafe {
                VbaRecord::clone_from_raw(ptr, layout)
            }?));
        }
        // SAFETY: `data` is the non-null intrinsic payload of `self.len()` elements of
        // this descriptor's kind, and `index < self.len()`, so the slot is in-bounds.
        unsafe { decode_element_variant(self.element_kind(), data, index) }
    }

    pub fn replace_variant_elements(&self, values: Vec<Variant>) -> Result<Self, String> {
        Self::from_bounds_and_variants(
            self.bounds_for_shape(),
            self.element_vartype(),
            Some(values),
        )
    }

    pub fn set_variant_element(&mut self, index: usize, value: &Variant) -> Result<(), String> {
        let len = self.len();
        if index >= len {
            return Err(format!(
                "SAFEARRAY index {index} out of range for length {len}"
            ));
        }
        // SAFETY: `self.0` is this value's live descriptor; reading `pv_data` is
        // valid, and the null (shape-only) case is handled immediately below.
        let data = unsafe { (*self.0.as_ptr()).pv_data.cast::<u8>() };
        if data.is_null() {
            return Err("SAFEARRAY has no materialized element payload".to_string());
        }
        if let Some(layout) = self.vba_record_layout() {
            let Some(source) = value.vba_record_ref() else {
                return Err(format!(
                    "expected VBA record SAFEARRAY element, got {:?}",
                    value.vtype()
                ));
            };
            if source.layout().as_ref() != layout.as_ref() {
                return Err("VBA record SAFEARRAY element layout mismatch".to_string());
            }
            let mut replacement = source.try_clone()?;
            // SAFETY: `index < self.len()` (checked above) and `data` is the record
            // payload strided by `layout.size()`, so this offset is the in-bounds slot.
            let ptr = unsafe { data.add(record_payload_offset(&layout, index)) };
            // SAFETY: replacement is a complete same-layout owner and `ptr` is the
            // live `index`-th record. The byte swap cannot fail; replacement then
            // drops the prior element after the array already owns the new payload.
            unsafe { replacement.swap_with_raw(ptr) };
            return Ok(());
        }
        // SAFETY: `data` is the non-null intrinsic payload of `self.len()` elements of
        // this descriptor's kind, and `index < self.len()`, so the slot is writable.
        unsafe { replace_element_variant(self.element_kind(), data, index, value) }
    }

    pub fn i32_element(&self, index: usize) -> Result<Option<i32>, String> {
        let Some(kind @ (SafeArrayElementKind::I4 | SafeArrayElementKind::Int)) =
            SafeArrayElementKind::from_vartype(self.element_vartype())
        else {
            return Ok(None);
        };
        let len = self.len();
        if index >= len {
            return Err(format!(
                "SAFEARRAY index {index} out of range for length {len}"
            ));
        }
        // SAFETY: `self.0` is this value's live descriptor; reading `pv_data` is valid.
        let data = unsafe { (*self.0.as_ptr()).pv_data.cast::<u8>() };
        if data.is_null() {
            return Err("SAFEARRAY has no materialized element payload".to_string());
        }
        // SAFETY: kind/len checks above prove this is an in-bounds i32 slot.
        let ptr = unsafe { data.add(payload_offset(kind, index)) };
        // SAFETY: I4/Int selects a four-byte-aligned `i32` payload layout;
        // the checked index identifies a live slot inside the non-null payload.
        Ok(Some(unsafe { *ptr.cast::<i32>() }))
    }

    pub fn set_i32_element(&mut self, index: usize, value: i32) -> Result<bool, String> {
        let Some(kind @ (SafeArrayElementKind::I4 | SafeArrayElementKind::Int)) =
            SafeArrayElementKind::from_vartype(self.element_vartype())
        else {
            return Ok(false);
        };
        let len = self.len();
        if index >= len {
            return Err(format!(
                "SAFEARRAY index {index} out of range for length {len}"
            ));
        }
        // SAFETY: `self.0` is this value's live descriptor; reading `pv_data` is valid.
        let data = unsafe { (*self.0.as_ptr()).pv_data.cast::<u8>() };
        if data.is_null() {
            return Err("SAFEARRAY has no materialized element payload".to_string());
        }
        // SAFETY: kind/len checks above prove this is an in-bounds writable i32 slot.
        let ptr = unsafe { data.add(payload_offset(kind, index)) };
        // SAFETY: I4/Int selects a four-byte-aligned `i32` payload layout;
        // the checked index and exclusive `&mut self` make this a unique live slot.
        unsafe { *ptr.cast::<i32>() = value };
        Ok(true)
    }

    pub fn raw_safearray_ptr(&self) -> *mut core::ffi::c_void {
        self.0.as_ptr().cast()
    }

    /// Transfer this canonical descriptor to an owner that will eventually use
    /// from_raw_safearray_owned to release it on the owning thread.
    pub fn into_raw_safearray_ptr(self) -> *mut core::ffi::c_void {
        let owner = core::mem::ManuallyDrop::new(self);
        owner.0.as_ptr().cast()
    }

    pub fn clone_raw_safearray_ptr(&self) -> *mut core::ffi::c_void {
        self.clone().into_raw_safearray_ptr()
    }

    /// Construct an immediately destructor-suppressed view of a raw descriptor.
    ///
    /// # Safety
    /// `raw` must remain a live OxVba-owned descriptor for the complete returned
    /// view lifetime, with shared or exclusive access appropriate to its use.
    unsafe fn borrow_raw_safearray(
        raw: *mut core::ffi::c_void,
    ) -> Option<core::mem::ManuallyDrop<Self>> {
        // SAFETY: forwards this function's live OxVba descriptor contract.
        unsafe { Self::borrow_raw_safearray_result(raw) }.ok()
    }

    /// Result-returning counterpart that preserves the public raw-helper
    /// distinction between a null pointer and a non-OxVba descriptor.
    ///
    /// # Safety
    /// Same as [`Self::borrow_raw_safearray`].
    unsafe fn borrow_raw_safearray_result(
        raw: *mut core::ffi::c_void,
    ) -> Result<core::mem::ManuallyDrop<Self>, String> {
        let header = NonNull::new(raw.cast::<RawSafeArray>())
            .ok_or_else(|| "SAFEARRAY raw pointer is null".to_string())?;
        // SAFETY: forwards this function's live OxVba descriptor contract.
        unsafe { validated_header_prefix(header.as_ptr()) }
            .ok_or_else(|| "SAFEARRAY raw pointer is not OxVba-owned".to_string())?;
        Ok(core::mem::ManuallyDrop::new(Self(header)))
    }

    /// Takes ownership of a raw SAFEARRAY descriptor produced by this runtime.
    ///
    /// # Safety
    ///
    /// `raw` must be a descriptor pointer previously returned by
    /// [`Self::clone_raw_safearray_ptr`] or by moving a [`SafeArray`] into a
    /// [`Variant`](crate::Variant). This is not an external COM
    /// `SafeArrayDestroy` adapter; non-OxVba descriptors are rejected when the
    /// local owner prefix provenance marker is absent.
    pub unsafe fn from_raw_safearray_owned(raw: *mut core::ffi::c_void) -> Option<Self> {
        let header = NonNull::new(raw.cast::<RawSafeArray>())?;
        // SAFETY: this function's contract requires `raw` to be a descriptor
        // produced by this runtime, so an owner prefix precedes the header in
        // the same allocation; the magic/version check then rejects anything
        // that lost OxVba provenance before ownership is adopted.
        unsafe { validated_header_prefix(header.as_ptr()) }?;
        Some(Self(header))
    }

    /// Clones a raw SAFEARRAY descriptor produced by this runtime.
    ///
    /// # Safety
    ///
    /// `raw` must point at a live OxVba-owned descriptor. The clone receives
    /// independent descriptor/payload storage; ownership of `raw` is unchanged.
    pub unsafe fn clone_from_raw_safearray(raw: *mut core::ffi::c_void) -> Option<Self> {
        // SAFETY: forwards this public helper's raw descriptor contract.
        unsafe { Self::try_clone_from_raw_safearray(raw) }
            .expect("cloning a live canonical SAFEARRAY should succeed")
    }

    pub(crate) unsafe fn try_clone_from_raw_safearray(
        raw: *mut core::ffi::c_void,
    ) -> Result<Option<Self>, String> {
        // SAFETY: forwards this function's raw descriptor contract; the returned
        // ManuallyDrop view cannot claim source ownership during error or unwind.
        let Some(borrowed) = (unsafe { Self::borrow_raw_safearray(raw) }) else {
            return Ok(None);
        };
        crate::vba_record::owning_boundary("borrowed-safearray-clone")?;
        Ok(Some(borrowed.try_clone()?))
    }

    /// Mutates one element of a raw SAFEARRAY descriptor produced by this runtime.
    ///
    /// # Safety
    ///
    /// `raw` must point at a live OxVba-owned descriptor, and the caller must
    /// have exclusive access to that descriptor for the duration of this call.
    pub unsafe fn set_raw_safearray_variant_element(
        raw: *mut core::ffi::c_void,
        index: usize,
        value: &Variant,
    ) -> Result<(), String> {
        // SAFETY: forwards this function's exclusive raw descriptor contract.
        let mut borrowed = unsafe { Self::borrow_raw_safearray_result(raw) }?;
        crate::vba_record::owning_boundary("borrowed-safearray-variant-set")?;
        borrowed.set_variant_element(index, value)
    }

    /// Reads one element of a raw SAFEARRAY descriptor produced by this runtime
    /// **without cloning the array** — O(1) in array length (mirrors
    /// [`Self::set_raw_safearray_variant_element`]). This is the read primitive
    /// that keeps `arr(i)` element access constant-time instead of deep-cloning
    /// the whole backing store per access.
    ///
    /// # Safety
    ///
    /// `raw` must point at a live OxVba-owned descriptor, and the caller must
    /// have shared access to that descriptor for the duration of this call.
    pub unsafe fn raw_safearray_variant_element(
        raw: *mut core::ffi::c_void,
        index: usize,
    ) -> Result<Variant, String> {
        // SAFETY: forwards this function's shared raw descriptor contract.
        let borrowed = unsafe { Self::borrow_raw_safearray_result(raw) }?;
        crate::vba_record::owning_boundary("borrowed-safearray-variant-read")?;
        borrowed.variant_element(index)
    }

    /// Reads an I4/Int element from a raw SAFEARRAY descriptor produced by this runtime.
    ///
    /// # Safety
    ///
    /// `raw` must point at a live OxVba-owned descriptor, and the caller must
    /// have shared access to that descriptor for the duration of this call.
    /// Ownership of the descriptor remains with the caller.
    pub unsafe fn raw_safearray_i32_element(
        raw: *mut core::ffi::c_void,
        index: usize,
    ) -> Result<Option<i32>, String> {
        // SAFETY: forwards this function's shared raw descriptor contract.
        let borrowed = unsafe { Self::borrow_raw_safearray_result(raw) }?;
        crate::vba_record::owning_boundary("borrowed-safearray-i32-read")?;
        borrowed.i32_element(index)
    }

    /// Mutates an I4/Int element of a raw SAFEARRAY descriptor produced by this runtime.
    ///
    /// # Safety
    ///
    /// `raw` must point at a live OxVba-owned descriptor, and the caller must
    /// have exclusive access to that descriptor for the duration of this call.
    /// Ownership of the descriptor remains with the caller.
    pub unsafe fn set_raw_safearray_i32_element(
        raw: *mut core::ffi::c_void,
        index: usize,
        value: i32,
    ) -> Result<bool, String> {
        // SAFETY: forwards this function's exclusive raw descriptor contract.
        let mut borrowed = unsafe { Self::borrow_raw_safearray_result(raw) }?;
        crate::vba_record::owning_boundary("borrowed-safearray-i32-set")?;
        borrowed.set_i32_element(index, value)
    }

    /// Reads the bounds and element count of a raw SAFEARRAY descriptor **without
    /// cloning the element payload** — O(rank). Used with
    /// [`Self::raw_safearray_variant_element`] to bounds-check and index an array
    /// in place.
    ///
    /// # Safety
    ///
    /// Same contract as [`Self::raw_safearray_variant_element`].
    pub unsafe fn raw_safearray_bounds_len(
        raw: *mut core::ffi::c_void,
    ) -> Option<(Vec<SafeArrayBound>, usize)> {
        // SAFETY: forwards this function's shared raw descriptor contract.
        let borrowed = unsafe { Self::borrow_raw_safearray(raw) }?;
        crate::vba_record::owning_boundary("borrowed-safearray-bounds").ok()?;
        let bounds = borrowed.raw_bounds();
        let len = bounds_total_len(&bounds).ok()?;
        if bounds.is_empty() {
            None
        } else {
            Some((bounds, len))
        }
    }

    pub(crate) fn try_clone(&self) -> Result<Self, String> {
        // Rebuild from bounds + element vartype + values, deriving canonical
        // feature flags and then restoring the descriptor's fixed-size bit.
        let fixed = self.is_fixed_size();
        let bounds = self.bounds_for_shape();
        if let Some(layout) = self.vba_record_layout() {
            let len = self.len();
            // SAFETY: this descriptor is live for the shared borrow.
            let data = unsafe { (*self.0.as_ptr()).pv_data.cast::<u8>() };
            if data.is_null() && len != 0 {
                return Err("record SAFEARRAY has no materialized element payload".to_string());
            }
            let mut values = Vec::with_capacity(len);
            for index in 0..len {
                // SAFETY: non-null `data` holds `len` records with this layout;
                // `index < len` selects one live record copied without consuming it.
                values.push(unsafe {
                    VbaRecord::clone_from_raw(
                        data.add(record_payload_offset(&layout, index)),
                        Arc::clone(&layout),
                    )
                }?);
            }
            return Ok(Self::from_vba_records_nd(bounds, layout, values)?.with_fixed_size(fixed));
        }
        Ok(match self.try_variant_elements()? {
            Some(values) => {
                Self::from_bounds_and_variants(bounds, self.element_vartype(), Some(values))?
            }
            None => Self::from_bounds_and_variants(bounds, self.element_vartype(), None)?,
        }
        .with_fixed_size(fixed))
    }
}

impl Clone for SafeArray {
    fn clone(&self) -> Self {
        self.try_clone()
            .expect("cloning canonical SAFEARRAY should succeed")
    }
}

impl Drop for SafeArray {
    fn drop(&mut self) {
        let len = self.len();
        // SAFETY: `self.0` is the live descriptor this value owns; reading
        // `pv_data` is valid until the deallocation below.
        let data = unsafe { (*self.0.as_ptr()).pv_data };
        if let Some(layout) = self.vba_record_layout() {
            // SAFETY: `data` is null or the payload built by
            // `prepare_record_payload_from_records` with this descriptor's
            // layout and exactly `len` initialized elements.
            unsafe { free_record_payload(&layout, data, len) };
        } else {
            let kind = self.element_kind();
            // SAFETY: `data` is null or the payload built by
            // `prepare_payload_from_variants` with this descriptor's `kind` and
            // exactly `len` initialized elements; `drop` runs at most once, so
            // the elements and the buffer are released exactly once.
            unsafe { free_payload(kind, data, len) };
        }
        if let Ok(layout) = owner_layout(self.dimensions() as usize) {
            // SAFETY: `self.0` is this value's own live OxVba descriptor allocated by
            // `alloc_header`, satisfying `validated_header_prefix`'s contract.
            let prefix = unsafe { validated_header_prefix(self.0.as_ptr()) };
            if let Some(prefix) = prefix {
                // SAFETY: `validated_header_prefix` returned `Some`, so `prefix` points
                // at the live owner prefix; reading `record_layout` is in-bounds.
                let record_layout = unsafe { (*prefix).record_layout };
                if !record_layout.is_null() {
                    // SAFETY: non-null record_layout pointers are stored from
                    // Arc::into_raw in alloc_header; this releases the owner
                    // prefix's strong reference exactly once.
                    unsafe { drop(Arc::from_raw(record_layout)) };
                }
            }
            // SAFETY: `alloc_header` placed the descriptor exactly
            // `size_of::<RawSafeArrayOwnerPrefix>()` bytes into the owner
            // allocation, so this `sub` recovers the allocation's base pointer
            // without leaving the allocation.
            let owner = unsafe {
                self.0
                    .as_ptr()
                    .cast::<u8>()
                    .sub(core::mem::size_of::<RawSafeArrayOwnerPrefix>())
            };
            crate::live_counters::safearray_freed();
            // SAFETY: `owner` is the pointer `alloc_zeroed` returned in
            // `alloc_header`, and `owner_layout(self.dimensions())` recomputes
            // the layout used there (`c_dims` was written from `bounds.len()`);
            // nothing touches the allocation after this point.
            unsafe { std::alloc::dealloc(owner, layout) };
        }
    }
}

impl core::fmt::Debug for SafeArray {
    fn fmt(&self, f: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        f.debug_struct("SafeArray")
            .field("dimensions", &self.dimensions())
            .field("len", &self.len())
            .field(
                "element_vartype",
                &format_args!("{:#06X}", self.element_vartype()),
            )
            .field("bounds", &self.bounds())
            .field("elements", &self.variant_elements())
            .finish()
    }
}

impl PartialEq for SafeArray {
    fn eq(&self, other: &Self) -> bool {
        self.dimensions() == other.dimensions()
            && self.len() == other.len()
            && self.element_vartype() == other.element_vartype()
            && self.bounds() == other.bounds()
            && self.variant_elements() == other.variant_elements()
    }
}

impl Eq for SafeArray {}

pub fn is_array_tag(value: i32) -> bool {
    (ARRAY_TAG_BASE..=ARRAY_TAG_LIMIT).contains(&value)
}

pub fn array_len_from_tag(value: i32) -> Option<usize> {
    if !is_array_tag(value) {
        return None;
    }
    let count = value.checked_sub(ARRAY_TAG_BASE)?;
    usize::try_from(count).ok()
}

pub fn safe_array_from_tag(value: i32) -> Option<SafeArray> {
    array_len_from_tag(value).map(SafeArray::vector)
}

pub fn array_tag_from_safe_array(array: &SafeArray) -> Option<i32> {
    if array.dimensions() == 0 {
        return None;
    }
    let len_i32 = i32::try_from(array.effective_len()).ok()?;
    ARRAY_TAG_BASE
        .checked_add(len_i32)
        .filter(|v| *v <= ARRAY_TAG_LIMIT)
}

pub fn marshal_dispatch_argument(value: i32) -> i32 {
    let Some(array) = safe_array_from_tag(value) else {
        return value;
    };
    match i32::try_from(array.len()) {
        Ok(len) => DISPATCH_ARRAY_PAYLOAD_BASE.saturating_add(len),
        Err(_) => DISPATCH_ARRAY_PAYLOAD_BASE,
    }
}

#[cfg(test)]
// Test-support code exercising the documented production raw-pointer paths.
#[allow(clippy::undocumented_unsafe_blocks)]
mod tests {
    use super::{
        ARRAY_TAG_BASE, FADF_BSTR_VALUE, FADF_DISPATCH_VALUE, FADF_HAVEVARTYPE_VALUE,
        FADF_UNKNOWN_VALUE, FADF_VARIANT_VALUE, RawSafeArray, SafeArray, SafeArrayBound,
        VT_BOOL_VALUE, VT_BSTR_VALUE, VT_CY_VALUE, VT_DATE_VALUE, VT_DECIMAL_VALUE,
        VT_DISPATCH_VALUE, VT_I2_VALUE, VT_I4_VALUE, VT_RECORD_VALUE, VT_UNKNOWN_VALUE,
        VT_VARIANT_VALUE, array_len_from_tag, array_tag_from_safe_array, header_prefix_ptr,
        marshal_dispatch_argument, payload_allocation_events, safe_array_from_tag,
    };
    use crate::live_counters::thread_live_handle_counts;
    use crate::vba_record::{
        OwningFailureMode, clear_owning_boundary_failure, inject_owning_boundary_failure,
        record_buffer_event_counts, take_owning_boundary_trace,
    };
    use crate::{
        Decimal96, ObjectRef, Variant, VbaRecord, VbaRecordFieldKind, VbaRecordFieldSpec,
        VbaRecordLayout, bstr::BStr,
    };
    use std::{
        panic::{AssertUnwindSafe, catch_unwind},
        sync::Arc,
    };

    fn offset_of<T, U>(field: fn(*const T) -> *const U) -> usize {
        let value = core::mem::MaybeUninit::<T>::uninit();
        let base = value.as_ptr();
        field(base) as usize - base as usize
    }

    fn transactional_record_layouts() -> (Arc<VbaRecordLayout>, Arc<VbaRecordLayout>) {
        let inner = Arc::new(
            VbaRecordLayout::new(vec![
                VbaRecordFieldSpec::named("InnerText", VbaRecordFieldKind::String),
                VbaRecordFieldSpec::named("InnerValue", VbaRecordFieldKind::Variant),
            ])
            .expect("transactional inner layout"),
        );
        let outer = Arc::new(
            VbaRecordLayout::new(vec![
                VbaRecordFieldSpec::named("Text", VbaRecordFieldKind::String),
                VbaRecordFieldSpec::named("Value", VbaRecordFieldKind::Variant),
                VbaRecordFieldSpec::named("Nested", VbaRecordFieldKind::Record(Arc::clone(&inner))),
            ])
            .expect("transactional record SAFEARRAY layout"),
        );
        (inner, outer)
    }

    fn transactional_record(
        inner_layout: &Arc<VbaRecordLayout>,
        outer_layout: &Arc<VbaRecordLayout>,
        label: &str,
        identity: i32,
    ) -> VbaRecord {
        let mut nested =
            VbaRecord::new_default(Arc::clone(inner_layout)).expect("nested record value");
        nested
            .write_field_variant(0, &Variant::from_string(format!("{label} nested")))
            .expect("nested String");
        nested
            .write_field_variant(
                1,
                &Variant::from_object_ref(ObjectRef::from_compat_identity(identity + 100)),
            )
            .expect("nested Variant");

        let mut record =
            VbaRecord::new_default(Arc::clone(outer_layout)).expect("outer record value");
        record
            .write_field_variant(0, &Variant::from_string(format!("{label} text")))
            .expect("outer String");
        record
            .write_field_variant(
                1,
                &Variant::from_object_ref(ObjectRef::from_compat_identity(identity)),
            )
            .expect("outer Variant");
        record
            .write_field_variant(2, &Variant::from_vba_record(nested))
            .expect("outer nested record");
        record
    }

    fn assert_transactional_record(value: &Variant, label: &str, identity: i32) {
        let record = value.vba_record_ref().expect("VBA record Variant");
        assert_eq!(
            record
                .read_field_variant(0)
                .expect("outer String read")
                .as_bstr()
                .expect("outer String")
                .as_str(),
            format!("{label} text")
        );
        assert_eq!(
            record
                .read_field_variant(1)
                .expect("outer Variant read")
                .as_object_ref()
                .expect("outer Object")
                .compat_identity(),
            identity
        );
        let nested = record.read_field_variant(2).expect("nested record read");
        let nested = nested.vba_record_ref().expect("nested VBA record");
        assert_eq!(
            nested
                .read_field_variant(0)
                .expect("nested String read")
                .as_bstr()
                .expect("nested String")
                .as_str(),
            format!("{label} nested")
        );
        assert_eq!(
            nested
                .read_field_variant(1)
                .expect("nested Variant read")
                .as_object_ref()
                .expect("nested Object")
                .compat_identity(),
            identity + 100
        );
    }

    fn transactional_record_array(
        inner_layout: &Arc<VbaRecordLayout>,
        outer_layout: &Arc<VbaRecordLayout>,
        label: &str,
        identity: i32,
    ) -> SafeArray {
        SafeArray::from_vba_records_nd(
            vec![SafeArrayBound { count: 1, lower: 7 }],
            Arc::clone(outer_layout),
            vec![transactional_record(
                inner_layout,
                outer_layout,
                label,
                identity,
            )],
        )
        .expect("record SAFEARRAY")
    }

    fn record_array_element_bytes(array: &SafeArray, layout: &VbaRecordLayout) -> Vec<u8> {
        // SAFETY: this helper is restricted to the one-element record SAFEARRAY
        // constructed above; its payload is non-null and exactly `layout.size()`.
        let data = unsafe { (*array.0.as_ptr()).pv_data.cast::<u8>() };
        assert!(!data.is_null());
        // SAFETY: the descriptor owns one initialized record of this exact layout.
        unsafe { core::slice::from_raw_parts(data, layout.size()) }.to_vec()
    }

    fn descriptor_fingerprint(
        array: &SafeArray,
    ) -> (usize, u16, u16, u32, u32, usize, Vec<SafeArrayBound>) {
        // SAFETY: `array.0` is its live descriptor for the duration of this borrow.
        let header = unsafe { &*array.0.as_ptr() };
        (
            array.0.as_ptr() as usize,
            header.c_dims,
            header.f_features,
            header.cb_elements,
            header.c_locks,
            header.pv_data as usize,
            array.raw_bounds(),
        )
    }

    fn assert_borrowed_bstr_array_source(
        array: &SafeArray,
        descriptor: &(usize, u16, u16, u32, u32, usize, Vec<SafeArrayBound>),
        expected: &[u8],
    ) {
        assert_eq!(&descriptor_fingerprint(array), descriptor);
        assert_eq!(
            array
                .variant_element(0)
                .expect("borrowed BSTR source remains readable")
                .string_bytes(),
            Some(expected.to_vec())
        );
        take_owning_boundary_trace();
    }

    fn assert_payload_event_balance(before: (usize, usize), label: &str) {
        let after = payload_allocation_events();
        assert_eq!(
            after.0 - before.0,
            after.1 - before.1,
            "{label} must free every raw payload allocation"
        );
    }

    fn assert_payload_constructor_sweep<T>(
        label: &str,
        make_values: impl Fn() -> T,
        construct: impl Fn(T) -> Result<SafeArray, String>,
        element_boundary: &'static str,
        expected_elements: usize,
    ) {
        let handles_before = thread_live_handle_counts();
        let payloads_before = payload_allocation_events();
        let values = make_values();
        take_owning_boundary_trace();
        let successful = construct(values).expect("uninjected SAFEARRAY payload construction");
        let success_trace = take_owning_boundary_trace();
        assert_eq!(successful.len(), expected_elements);
        assert_eq!(success_trace.last(), Some(&"safearray-header-adoption"));
        let element_boundaries = success_trace
            .iter()
            .filter(|boundary| **boundary == element_boundary)
            .count();
        assert!(
            element_boundaries >= expected_elements,
            "{label} trace must include every top-level element-clone boundary; \
             nested carrier clones may add more ({element_boundaries} observed)"
        );
        drop(successful);
        assert_eq!(
            thread_live_handle_counts(),
            handles_before,
            "uninjected {label} construction must balance every owned handle"
        );
        assert_payload_event_balance(payloads_before, label);

        for mode in [OwningFailureMode::Error, OwningFailureMode::Panic] {
            for nth in 0..success_trace.len() {
                let handles_before = thread_live_handle_counts();
                let payloads_before = payload_allocation_events();
                let values = make_values();
                inject_owning_boundary_failure(nth, mode);
                let outcome = catch_unwind(AssertUnwindSafe(|| construct(values)));
                clear_owning_boundary_failure();
                let failure_trace = take_owning_boundary_trace();
                assert_eq!(
                    failure_trace.as_slice(),
                    &success_trace[..=nth],
                    "{label} {mode:?} sweep missed boundary {nth}"
                );
                match (mode, outcome) {
                    (OwningFailureMode::Error, Ok(Err(error))) => assert!(
                        error.contains("injected owning clone/allocation failure"),
                        "unexpected {label} constructor error: {error}"
                    ),
                    (OwningFailureMode::Error, Err(_)) => {
                        panic!("fallible {label} constructor unexpectedly unwound")
                    }
                    (OwningFailureMode::Error, Ok(Ok(_))) => {
                        panic!("injected {label} constructor error unexpectedly succeeded")
                    }
                    (OwningFailureMode::Panic, Err(_)) => {}
                    (OwningFailureMode::Panic, Ok(result)) => {
                        panic!("injected {label} constructor panic did not unwind: {result:?}")
                    }
                }
                assert_eq!(
                    thread_live_handle_counts(),
                    handles_before,
                    "{label} {mode:?} boundary {nth} leaked an owned handle"
                );
                assert_payload_event_balance(
                    payloads_before,
                    &format!("{label} {mode:?} boundary {nth}"),
                );
            }
        }
        take_owning_boundary_trace();
    }

    #[test]
    fn safearray_descriptor_layout_matches_com_header_shape() {
        let pointer_sized_offsets = core::mem::size_of::<usize>() == 8;
        assert_eq!(core::mem::size_of::<SafeArrayBound>(), 8);
        assert_eq!(core::mem::align_of::<SafeArrayBound>(), 4);
        assert_eq!(
            core::mem::size_of::<RawSafeArray>(),
            if pointer_sized_offsets { 32 } else { 24 }
        );
        assert_eq!(
            core::mem::align_of::<RawSafeArray>(),
            core::mem::align_of::<*mut core::ffi::c_void>()
        );
        assert_eq!(
            offset_of::<RawSafeArray, _>(|base| unsafe { core::ptr::addr_of!((*base).c_dims) }),
            0
        );
        assert_eq!(
            offset_of::<RawSafeArray, _>(|base| unsafe { core::ptr::addr_of!((*base).f_features) }),
            2
        );
        assert_eq!(
            offset_of::<RawSafeArray, _>(|base| unsafe {
                core::ptr::addr_of!((*base).cb_elements)
            }),
            4
        );
        assert_eq!(
            offset_of::<RawSafeArray, _>(|base| unsafe { core::ptr::addr_of!((*base).c_locks) }),
            8
        );
        assert_eq!(
            offset_of::<RawSafeArray, _>(|base| unsafe { core::ptr::addr_of!((*base).pv_data) }),
            if pointer_sized_offsets { 16 } else { 12 }
        );
        assert_eq!(
            offset_of::<RawSafeArray, _>(|base| unsafe { core::ptr::addr_of!((*base).rgsabound) }),
            if pointer_sized_offsets { 24 } else { 16 }
        );
    }

    #[test]
    fn safe_array_tag_roundtrip_for_vector_shape() {
        let tag = ARRAY_TAG_BASE + 3;
        let array = safe_array_from_tag(tag).expect("array tag should decode");
        assert_eq!(array.len(), 3);
        assert_eq!(array.dimensions(), 1);
        assert_eq!(array.element_vartype(), VT_VARIANT_VALUE);
        assert_eq!(array_tag_from_safe_array(&array), Some(tag));
    }

    #[test]
    fn marshal_dispatch_argument_distinguishes_array_tags() {
        assert_eq!(marshal_dispatch_argument(9), 9);
        assert_eq!(marshal_dispatch_argument(ARRAY_TAG_BASE + 4), 20_004);
        assert_eq!(array_len_from_tag(ARRAY_TAG_BASE + 2), Some(2));
    }

    #[test]
    fn safe_array_from_values_preserves_owned_payload_shape() {
        let array = SafeArray::from_variants(vec![Variant::from_i32(4), Variant::from_i32(9)]);
        assert_eq!(array.dimensions(), 1);
        assert_eq!(array.len(), 2);
        assert_eq!(array.effective_len(), 2);
        assert_eq!(array.element_vartype(), VT_VARIANT_VALUE);
        assert_eq!(
            array.variant_elements(),
            Some(vec![Variant::from_i32(4), Variant::from_i32(9)])
        );
        assert_eq!(array_tag_from_safe_array(&array), Some(ARRAY_TAG_BASE + 2));
    }

    #[test]
    fn safe_array_variant_api_preserves_canonical_payload_shape() {
        let array = SafeArray::from_variants(vec![
            Variant::from_i32(4),
            Variant::from_string(BStr::from("A")),
        ]);
        let elements = array
            .variant_elements()
            .expect("variant SAFEARRAY should expose variants");
        assert_eq!(elements[0], Variant::from_i32(4));
        assert_eq!(elements[1], Variant::from_string(BStr::from("A")));
        let replaced = array
            .replace_variant_elements(vec![
                Variant::from_i32(9),
                Variant::from_string(BStr::from("B")),
            ])
            .expect("replace variant elements");
        assert_eq!(
            replaced.variant_elements(),
            Some(vec![
                Variant::from_i32(9),
                Variant::from_string(BStr::from("B"))
            ])
        );
    }

    #[test]
    fn safearray_descriptor_advertises_variant_vartype_metadata() {
        let array = SafeArray::from_variants(vec![Variant::from_i32(4)]);
        assert_eq!(array.element_vartype(), VT_VARIANT_VALUE);
        assert_eq!(
            array.feature_flags(),
            FADF_HAVEVARTYPE_VALUE | FADF_VARIANT_VALUE
        );
    }

    #[test]
    fn raw_safearray_adoption_requires_oxvba_owner_prefix() {
        let array = SafeArray::from_variants(vec![Variant::from_i32(4)]);
        let raw = array.clone_raw_safearray_ptr();
        let prefix = header_prefix_ptr(raw.cast());
        let original_magic = unsafe { (*prefix).magic };
        unsafe {
            (*prefix.cast_mut()).magic = 0;
        }
        assert!(unsafe { SafeArray::from_raw_safearray_owned(raw) }.is_none());
        unsafe {
            (*prefix.cast_mut()).magic = original_magic;
        }
        let adopted = unsafe { SafeArray::from_raw_safearray_owned(raw) }
            .expect("restored OxVba-owned SAFEARRAY should be adopted");
        assert_eq!(
            adopted.variant_elements().expect("elements"),
            vec![Variant::from_i32(4)]
        );
    }

    #[test]
    fn fixed_size_flag_surfaces_in_feature_flags_and_survives_clone() {
        use super::FADF_FIXEDSIZE_VALUE;

        let dynamic = SafeArray::from_variants(vec![Variant::from_i32(7)]);
        assert!(!dynamic.is_fixed_size());
        assert_eq!(dynamic.feature_flags() & FADF_FIXEDSIZE_VALUE, 0);

        let fixed = SafeArray::from_variants(vec![Variant::from_i32(7)]).with_fixed_size(true);
        assert!(fixed.is_fixed_size());
        assert_eq!(
            fixed.feature_flags() & FADF_FIXEDSIZE_VALUE,
            FADF_FIXEDSIZE_VALUE
        );
        // The non-fixed FADF metadata is untouched alongside the fixed bit.
        assert_eq!(
            fixed.feature_flags(),
            dynamic.feature_flags() | FADF_FIXEDSIZE_VALUE
        );

        // The descriptor flag travels with the value copy (Variant assignment,
        // ByVal/ByRef copies all clone the SafeArray).
        let cloned = fixed.clone();
        assert!(cloned.is_fixed_size());
        assert_eq!(cloned.variant_elements(), Some(vec![Variant::from_i32(7)]));

        // Clearing the bit is observable, and a cleared array clones as dynamic.
        let recleared = cloned.with_fixed_size(false);
        assert!(!recleared.is_fixed_size());
        assert!(!recleared.clone().is_fixed_size());
    }

    #[test]
    fn fixed_size_flag_travels_through_raw_descriptor_roundtrip() {
        let fixed = SafeArray::from_typed_variants(VT_I2_VALUE, vec![Variant::from_i16(3)])
            .expect("typed array")
            .with_fixed_size(true);
        let raw = fixed.clone_raw_safearray_ptr();
        let adopted = unsafe { SafeArray::from_raw_safearray_owned(raw) }
            .expect("OxVba-owned descriptor should adopt");
        assert!(adopted.is_fixed_size());
    }

    #[test]
    fn safe_array_from_values_nd_preserves_multi_dimensional_shape() {
        let bounds = vec![
            SafeArrayBound { lower: 1, count: 3 },
            SafeArrayBound { lower: 1, count: 2 },
        ];
        let values = vec![
            Variant::from_i32(1),
            Variant::from_i32(2),
            Variant::from_i32(3),
            Variant::from_i32(4),
            Variant::from_i32(5),
            Variant::from_i32(6),
        ];
        let array = SafeArray::from_variants_nd(bounds.clone(), values.clone());
        assert_eq!(array.dimensions(), 2);
        assert_eq!(array.len(), 6);
        assert_eq!(array.effective_len(), 6);
        assert_eq!(array.bounds().as_ref(), Some(&bounds));
        assert_eq!(array.variant_elements().as_ref(), Some(&values));
    }

    #[test]
    fn safe_array_vector_exposes_descriptor_bounds() {
        let array = SafeArray::vector(5);
        assert_eq!(array.dimensions(), 1);
        assert_eq!(
            array.bounds(),
            Some(vec![SafeArrayBound { lower: 0, count: 5 }])
        );
        assert_eq!(array.variant_elements(), None);
    }

    #[test]
    fn safe_array_zeroed_typed_scalar_payload_is_materialized_and_writable() {
        let mut array = SafeArray::from_zeroed_typed_scalars_nd(
            vec![SafeArrayBound {
                lower: -1,
                count: 3,
            }],
            VT_I4_VALUE,
        )
        .expect("zeroed Long payload");
        assert_eq!(
            array.variant_elements(),
            Some(vec![
                Variant::from_i32(0),
                Variant::from_i32(0),
                Variant::from_i32(0),
            ])
        );
        array
            .set_variant_element(1, &Variant::from_i32(42))
            .expect("write zeroed payload");
        assert_eq!(array.variant_element(1), Ok(Variant::from_i32(42)));
    }

    #[test]
    fn safe_array_replace_elements_preserves_shape() {
        let shape = SafeArray::from_shape(vec![
            SafeArrayBound { lower: 1, count: 2 },
            SafeArrayBound { lower: 4, count: 2 },
        ])
        .expect("shape");
        let replaced = shape
            .replace_variant_elements(vec![
                Variant::from_i32(1),
                Variant::from_i32(2),
                Variant::from_i32(3),
                Variant::from_i32(4),
            ])
            .expect("replace");
        assert_eq!(replaced.bounds(), shape.bounds());
        assert_eq!(replaced.variant_elements().expect("elements").len(), 4);
    }

    #[test]
    fn safe_array_set_variant_element_mutates_payload_without_rebuilding_descriptor() {
        let mut array = SafeArray::from_typed_variants(
            VT_I2_VALUE,
            vec![Variant::from_i16(4), Variant::from_i16(9)],
        )
        .expect("typed array");
        let raw = array.raw_safearray_ptr();

        array
            .set_variant_element(1, &Variant::from_i16(42))
            .expect("set element");

        assert_eq!(array.raw_safearray_ptr(), raw);
        assert_eq!(
            array.variant_elements(),
            Some(vec![Variant::from_i16(4), Variant::from_i16(42)])
        );
    }

    #[test]
    fn safe_array_set_variant_element_replaces_owned_bstr_payload() {
        let mut array =
            SafeArray::from_typed_variants(VT_BSTR_VALUE, vec![Variant::from_string("before")])
                .expect("typed bstr array");
        let raw = array.raw_safearray_ptr();

        array
            .set_variant_element(0, &Variant::from_string("after"))
            .expect("set bstr element");

        assert_eq!(array.raw_safearray_ptr(), raw);
        assert_eq!(
            array.variant_elements(),
            Some(vec![Variant::from_string("after")])
        );
    }

    #[test]
    fn safe_array_set_variant_element_replaces_variant_payload() {
        let mut array = SafeArray::from_variants(vec![Variant::from_i32(1)]);
        let raw = array.raw_safearray_ptr();

        array
            .set_variant_element(0, &Variant::from_string("variant"))
            .expect("set variant element");

        assert_eq!(array.raw_safearray_ptr(), raw);
        assert_eq!(
            array.variant_elements(),
            Some(vec![Variant::from_string("variant")])
        );
    }

    #[test]
    fn native_record_safearray_stores_contiguous_record_payloads() {
        let layout = Arc::new(
            VbaRecordLayout::new(vec![VbaRecordFieldSpec::named(
                "Value",
                VbaRecordFieldKind::Long,
            )])
            .expect("layout"),
        );
        let make_record = |value: i32| {
            let mut record = VbaRecord::new_default(layout.clone()).expect("record");
            let field = record.field_handle(0).expect("record field handle");
            unsafe {
                record
                    .field_mut_ptr(&field)
                    .expect("record field pointer")
                    .cast::<i32>()
                    .write(value);
            }
            record
        };
        let mut array = SafeArray::from_vba_records_nd(
            vec![SafeArrayBound { count: 2, lower: 0 }],
            layout.clone(),
            vec![make_record(10), make_record(20)],
        )
        .expect("record array");

        assert_eq!(array.element_vartype(), VT_RECORD_VALUE);
        assert_eq!(
            array.feature_flags(),
            FADF_HAVEVARTYPE_VALUE | super::FADF_RECORD_VALUE
        );
        assert!(array.vba_record_layout().is_some());
        assert_eq!(
            array
                .variant_element(1)
                .expect("element")
                .as_vba_record()
                .expect("record")
                .read_field_variant(0)
                .expect("field")
                .as_i32(),
            Some(20)
        );

        array
            .set_variant_element(1, &Variant::from_vba_record(make_record(99)))
            .expect("replace record element");
        assert_eq!(
            array.variant_elements().expect("elements")[1]
                .as_vba_record()
                .expect("record")
                .read_field_variant(0)
                .expect("field")
                .as_i32(),
            Some(99)
        );
    }

    #[test]
    fn safe_array_record_transactional_write_preserves_element_and_descriptor_until_commit() {
        let before_buffers = record_buffer_event_counts();
        {
            let (inner_layout, outer_layout) = transactional_record_layouts();
            let replacement = Variant::from_vba_record(transactional_record(
                &inner_layout,
                &outer_layout,
                "new",
                72,
            ));

            let mut successful =
                transactional_record_array(&inner_layout, &outer_layout, "old", 71);
            let descriptor_before = descriptor_fingerprint(&successful);
            take_owning_boundary_trace();
            successful
                .set_variant_element(0, &replacement)
                .expect("uninjected record SAFEARRAY replacement");
            let success_trace = take_owning_boundary_trace();
            assert!(
                !success_trace.is_empty(),
                "record SAFEARRAY replacement must expose owning boundaries"
            );
            assert_eq!(descriptor_fingerprint(&successful), descriptor_before);
            assert_transactional_record(
                &successful.variant_element(0).expect("new array element"),
                "new",
                72,
            );
            drop(successful);

            for mode in [OwningFailureMode::Error, OwningFailureMode::Panic] {
                for nth in 0..success_trace.len() {
                    let mut target =
                        transactional_record_array(&inner_layout, &outer_layout, "old", 71);
                    let descriptor_before = descriptor_fingerprint(&target);
                    let element_before = record_array_element_bytes(&target, &outer_layout);
                    inject_owning_boundary_failure(nth, mode);
                    let outcome = catch_unwind(AssertUnwindSafe(|| {
                        target.set_variant_element(0, &replacement)
                    }));
                    clear_owning_boundary_failure();
                    let failure_trace = take_owning_boundary_trace();
                    assert_eq!(
                        failure_trace.as_slice(),
                        &success_trace[..=nth],
                        "injected {mode:?} failure missed SAFEARRAY boundary {nth}"
                    );
                    match (mode, outcome) {
                        (OwningFailureMode::Error, Ok(Err(error))) => assert!(
                            error.contains("injected owning clone/allocation failure"),
                            "unexpected record SAFEARRAY error: {error}"
                        ),
                        (OwningFailureMode::Error, Err(_)) => {
                            panic!("injected record SAFEARRAY error unexpectedly unwound")
                        }
                        (OwningFailureMode::Panic, Err(_)) => {}
                        (OwningFailureMode::Error, Ok(Ok(()))) => {
                            panic!("injected record SAFEARRAY error unexpectedly committed")
                        }
                        (OwningFailureMode::Panic, Ok(result)) => {
                            panic!("injected record SAFEARRAY panic did not unwind: {result:?}")
                        }
                    }
                    assert_eq!(descriptor_fingerprint(&target), descriptor_before);
                    assert_eq!(
                        record_array_element_bytes(&target, &outer_layout),
                        element_before,
                        "record SAFEARRAY element bytes changed after {mode:?} boundary {nth}"
                    );
                    assert_transactional_record(
                        &target
                            .variant_element(0)
                            .expect("old array element after failure"),
                        "old",
                        71,
                    );
                }
            }
        }
        clear_owning_boundary_failure();
        take_owning_boundary_trace();
        let after_buffers = record_buffer_event_counts();
        assert_eq!(
            after_buffers.0 - before_buffers.0,
            after_buffers.1 - before_buffers.1,
            "record SAFEARRAY success, error, and unwind paths must balance record owners"
        );
    }

    #[test]
    fn borrowed_carrier_unwind_safety_safearray_bstr_clone_read_and_set_helpers() {
        let handles_before = thread_live_handle_counts();
        {
            let original_bytes = vec![0x41, 0x00, 0x00, 0x42, 0x7f];
            let replacement_bytes = vec![0x52, 0x00, 0x00, 0x53, 0x7e];
            let mut source = SafeArray::from_typed_variants(
                VT_BSTR_VALUE,
                vec![Variant::from_bstr_bytes(&original_bytes)],
            )
            .expect("typed BSTR SAFEARRAY");
            let descriptor = descriptor_fingerprint(&source);
            let raw = source.raw_safearray_ptr();

            for mode in [OwningFailureMode::Error, OwningFailureMode::Panic] {
                inject_owning_boundary_failure(0, mode);
                let outcome = catch_unwind(AssertUnwindSafe(|| source.variant_element(0)));
                clear_owning_boundary_failure();
                assert_eq!(take_owning_boundary_trace(), vec!["borrowed-bstr-clone"]);
                match (mode, outcome) {
                    (OwningFailureMode::Error, Ok(Err(error))) => assert!(
                        error.contains("injected owning clone/allocation failure"),
                        "unexpected typed BSTR read error: {error}"
                    ),
                    (OwningFailureMode::Panic, Err(_)) => {}
                    (OwningFailureMode::Error, Err(_)) => {
                        panic!("fallible typed BSTR read unexpectedly unwound")
                    }
                    (OwningFailureMode::Error, Ok(Ok(_))) => {
                        panic!("injected typed BSTR read unexpectedly succeeded")
                    }
                    (OwningFailureMode::Panic, Ok(result)) => {
                        panic!("injected typed BSTR read panic did not unwind: {result:?}")
                    }
                }
                assert_borrowed_bstr_array_source(&source, &descriptor, &original_bytes);

                // Failure zero happens after the ManuallyDrop raw-descriptor view
                // exists; failure one reaches the nested destructor-free BSTR view.
                for nth in 0..=1 {
                    inject_owning_boundary_failure(nth, mode);
                    let outcome = catch_unwind(AssertUnwindSafe(|| {
                        // SAFETY: `raw` is the live descriptor owned by `source`.
                        unsafe { SafeArray::raw_safearray_variant_element(raw, 0) }
                    }));
                    clear_owning_boundary_failure();
                    let expected_trace = if nth == 0 {
                        vec!["borrowed-safearray-variant-read"]
                    } else {
                        vec!["borrowed-safearray-variant-read", "borrowed-bstr-clone"]
                    };
                    assert_eq!(take_owning_boundary_trace(), expected_trace);
                    match (mode, outcome) {
                        (OwningFailureMode::Error, Ok(Err(error))) => assert!(
                            error.contains("injected owning clone/allocation failure"),
                            "unexpected raw typed BSTR read error: {error}"
                        ),
                        (OwningFailureMode::Panic, Err(_)) => {}
                        (OwningFailureMode::Error, Err(_)) => {
                            panic!("fallible raw typed BSTR read unexpectedly unwound")
                        }
                        (OwningFailureMode::Error, Ok(Ok(_))) => {
                            panic!("injected raw typed BSTR read unexpectedly succeeded")
                        }
                        (OwningFailureMode::Panic, Ok(result)) => {
                            panic!("injected raw typed BSTR read panic did not unwind: {result:?}")
                        }
                    }
                    assert_borrowed_bstr_array_source(&source, &descriptor, &original_bytes);
                }

                for nth in 0..=1 {
                    inject_owning_boundary_failure(nth, mode);
                    let outcome = catch_unwind(AssertUnwindSafe(|| {
                        // SAFETY: `raw` remains a live shared descriptor for this clone.
                        unsafe { SafeArray::try_clone_from_raw_safearray(raw) }
                    }));
                    clear_owning_boundary_failure();
                    let expected_trace = if nth == 0 {
                        vec!["borrowed-safearray-clone"]
                    } else {
                        vec!["borrowed-safearray-clone", "borrowed-bstr-clone"]
                    };
                    assert_eq!(take_owning_boundary_trace(), expected_trace);
                    match (mode, outcome) {
                        (OwningFailureMode::Error, Ok(Err(error))) => assert!(
                            error.contains("injected owning clone/allocation failure"),
                            "unexpected raw SAFEARRAY clone error: {error}"
                        ),
                        (OwningFailureMode::Panic, Err(_)) => {}
                        (OwningFailureMode::Error, Err(_)) => {
                            panic!("fallible raw SAFEARRAY clone unexpectedly unwound")
                        }
                        (OwningFailureMode::Error, Ok(Ok(_))) => {
                            panic!("injected raw SAFEARRAY clone unexpectedly succeeded")
                        }
                        (OwningFailureMode::Panic, Ok(result)) => {
                            panic!("injected raw SAFEARRAY clone panic did not unwind: {result:?}")
                        }
                    }
                    assert_borrowed_bstr_array_source(&source, &descriptor, &original_bytes);
                }

                let replacement = Variant::from_bstr_bytes(&replacement_bytes);
                for nth in 0..=1 {
                    inject_owning_boundary_failure(nth, mode);
                    let outcome = catch_unwind(AssertUnwindSafe(|| {
                        // SAFETY: `raw` is the live, exclusively borrowed descriptor
                        // owned by `source` throughout this mutation attempt.
                        unsafe {
                            SafeArray::set_raw_safearray_variant_element(raw, 0, &replacement)
                        }
                    }));
                    clear_owning_boundary_failure();
                    let expected_trace = if nth == 0 {
                        vec!["borrowed-safearray-variant-set"]
                    } else {
                        vec!["borrowed-safearray-variant-set", "borrowed-bstr-clone"]
                    };
                    assert_eq!(take_owning_boundary_trace(), expected_trace);
                    match (mode, outcome) {
                        (OwningFailureMode::Error, Ok(Err(error))) => assert!(
                            error.contains("injected owning clone/allocation failure"),
                            "unexpected raw SAFEARRAY set error: {error}"
                        ),
                        (OwningFailureMode::Panic, Err(_)) => {}
                        (OwningFailureMode::Error, Err(_)) => {
                            panic!("fallible raw SAFEARRAY set unexpectedly unwound")
                        }
                        (OwningFailureMode::Error, Ok(Ok(()))) => {
                            panic!("injected raw SAFEARRAY set unexpectedly committed")
                        }
                        (OwningFailureMode::Panic, Ok(result)) => {
                            panic!("injected raw SAFEARRAY set panic did not unwind: {result:?}")
                        }
                    }
                    assert_borrowed_bstr_array_source(&source, &descriptor, &original_bytes);
                    assert_eq!(replacement.string_bytes(), Some(replacement_bytes.clone()));
                    take_owning_boundary_trace();
                }
            }

            source
                .set_variant_element(0, &Variant::from_bstr_bytes(&replacement_bytes))
                .expect("source remains mutable after injected failures");
            assert_eq!(
                source
                    .variant_element(0)
                    .expect("replacement read")
                    .string_bytes(),
                Some(replacement_bytes)
            );
            take_owning_boundary_trace();
        }
        clear_owning_boundary_failure();
        take_owning_boundary_trace();
        assert_eq!(
            thread_live_handle_counts(),
            handles_before,
            "SAFEARRAY BSTR clone/read/set failures and final drops must balance"
        );
    }

    #[test]
    fn borrowed_carrier_unwind_safety_safearray_scalar_and_composite_raw_helpers() {
        let handles_before = thread_live_handle_counts();
        {
            let mut scalars = SafeArray::from_typed_variants(
                VT_I4_VALUE,
                vec![Variant::from_i32(17), Variant::from_i32(29)],
            )
            .expect("typed I4 SAFEARRAY");
            let scalar_descriptor = descriptor_fingerprint(&scalars);
            let scalar_raw = scalars.raw_safearray_ptr();

            for mode in [OwningFailureMode::Error, OwningFailureMode::Panic] {
                inject_owning_boundary_failure(0, mode);
                let read = catch_unwind(AssertUnwindSafe(|| {
                    // SAFETY: the descriptor remains live and shared for this read.
                    unsafe { SafeArray::raw_safearray_i32_element(scalar_raw, 1) }
                }));
                clear_owning_boundary_failure();
                assert_eq!(
                    take_owning_boundary_trace(),
                    vec!["borrowed-safearray-i32-read"]
                );
                match (mode, read) {
                    (OwningFailureMode::Error, Ok(Err(error))) => assert!(
                        error.contains("injected owning clone/allocation failure"),
                        "unexpected raw I4 read error: {error}"
                    ),
                    (OwningFailureMode::Panic, Err(_)) => {}
                    (OwningFailureMode::Error, Err(_)) => {
                        panic!("fallible raw I4 read unexpectedly unwound")
                    }
                    (OwningFailureMode::Error, Ok(Ok(_))) => {
                        panic!("injected raw I4 read unexpectedly succeeded")
                    }
                    (OwningFailureMode::Panic, Ok(result)) => {
                        panic!("injected raw I4 read panic did not unwind: {result:?}")
                    }
                }
                assert_eq!(descriptor_fingerprint(&scalars), scalar_descriptor);
                assert_eq!(scalars.i32_element(1), Ok(Some(29)));

                inject_owning_boundary_failure(0, mode);
                let set = catch_unwind(AssertUnwindSafe(|| {
                    // SAFETY: the descriptor is exclusively borrowed through
                    // `scalars` for this attempted mutation.
                    unsafe { SafeArray::set_raw_safearray_i32_element(scalar_raw, 1, 99) }
                }));
                clear_owning_boundary_failure();
                assert_eq!(
                    take_owning_boundary_trace(),
                    vec!["borrowed-safearray-i32-set"]
                );
                match (mode, set) {
                    (OwningFailureMode::Error, Ok(Err(error))) => assert!(
                        error.contains("injected owning clone/allocation failure"),
                        "unexpected raw I4 set error: {error}"
                    ),
                    (OwningFailureMode::Panic, Err(_)) => {}
                    (OwningFailureMode::Error, Err(_)) => {
                        panic!("fallible raw I4 set unexpectedly unwound")
                    }
                    (OwningFailureMode::Error, Ok(Ok(_))) => {
                        panic!("injected raw I4 set unexpectedly committed")
                    }
                    (OwningFailureMode::Panic, Ok(result)) => {
                        panic!("injected raw I4 set panic did not unwind: {result:?}")
                    }
                }
                assert_eq!(descriptor_fingerprint(&scalars), scalar_descriptor);
                assert_eq!(scalars.i32_element(1), Ok(Some(29)));

                inject_owning_boundary_failure(0, mode);
                let bounds = catch_unwind(AssertUnwindSafe(|| {
                    // SAFETY: the descriptor remains live and shared for this query.
                    unsafe { SafeArray::raw_safearray_bounds_len(scalar_raw) }
                }));
                clear_owning_boundary_failure();
                assert_eq!(
                    take_owning_boundary_trace(),
                    vec!["borrowed-safearray-bounds"]
                );
                match (mode, bounds) {
                    (OwningFailureMode::Error, Ok(None)) => {}
                    (OwningFailureMode::Panic, Err(_)) => {}
                    (OwningFailureMode::Error, Err(_)) => {
                        panic!("fallible raw bounds query unexpectedly unwound")
                    }
                    (OwningFailureMode::Error, Ok(Some(result))) => {
                        panic!("injected raw bounds error returned a value: {result:?}")
                    }
                    (OwningFailureMode::Panic, Ok(result)) => {
                        panic!("injected raw bounds panic did not unwind: {result:?}")
                    }
                }
                assert_eq!(descriptor_fingerprint(&scalars), scalar_descriptor);
                assert_eq!(scalars.i32_element(1), Ok(Some(29)));
            }
            scalars
                .set_i32_element(1, 31)
                .expect("post-failure scalar mutation");
            assert_eq!(scalars.i32_element(1), Ok(Some(31)));

            let (inner_layout, outer_layout) = transactional_record_layouts();
            let composite = SafeArray::from_variants(vec![
                Variant::from_string("composite text"),
                Variant::from_object_ref(ObjectRef::from_compat_identity(631)),
                Variant::from_safearray(SafeArray::from_variants(vec![Variant::from_string(
                    "nested array text",
                )])),
                Variant::from_vba_record(transactional_record(
                    &inner_layout,
                    &outer_layout,
                    "composite record",
                    632,
                )),
            ]);
            let composite_descriptor = descriptor_fingerprint(&composite);
            let composite_raw = composite.raw_safearray_ptr();
            for mode in [OwningFailureMode::Error, OwningFailureMode::Panic] {
                inject_owning_boundary_failure(0, mode);
                let outcome = catch_unwind(AssertUnwindSafe(|| {
                    // SAFETY: `composite` owns this live descriptor throughout.
                    unsafe { SafeArray::try_clone_from_raw_safearray(composite_raw) }
                }));
                clear_owning_boundary_failure();
                assert_eq!(
                    take_owning_boundary_trace(),
                    vec!["borrowed-safearray-clone"]
                );
                match (mode, outcome) {
                    (OwningFailureMode::Error, Ok(Err(error))) => assert!(
                        error.contains("injected owning clone/allocation failure"),
                        "unexpected composite raw-clone error: {error}"
                    ),
                    (OwningFailureMode::Panic, Err(_)) => {}
                    (OwningFailureMode::Error, Err(_)) => {
                        panic!("fallible composite raw clone unexpectedly unwound")
                    }
                    (OwningFailureMode::Error, Ok(Ok(_))) => {
                        panic!("injected composite raw clone unexpectedly succeeded")
                    }
                    (OwningFailureMode::Panic, Ok(result)) => {
                        panic!("injected composite raw-clone panic did not unwind: {result:?}")
                    }
                }
                assert_eq!(descriptor_fingerprint(&composite), composite_descriptor);
                let values = composite
                    .variant_elements()
                    .expect("composite source remains readable");
                assert_eq!(
                    values[0].as_bstr().expect("String value").as_str(),
                    "composite text"
                );
                assert_eq!(
                    values[1]
                        .as_object_ref()
                        .expect("Object value")
                        .compat_identity(),
                    631
                );
                assert_eq!(
                    values[2]
                        .safearray_element(0)
                        .expect("nested SAFEARRAY")
                        .expect("nested element")
                        .as_bstr()
                        .expect("nested String")
                        .as_str(),
                    "nested array text"
                );
                assert_transactional_record(&values[3], "composite record", 632);
                take_owning_boundary_trace();
            }
        }
        clear_owning_boundary_failure();
        take_owning_boundary_trace();
        assert_eq!(
            thread_live_handle_counts(),
            handles_before,
            "scalar/composite raw-helper failures and final drops must balance every carrier"
        );
    }

    #[test]
    fn safe_array_payload_transactional_construction_cleans_prefix_and_header_failures() {
        let (inner_layout, outer_layout) = transactional_record_layouts();

        assert_payload_constructor_sweep(
            "record payload",
            || {
                vec![
                    transactional_record(&inner_layout, &outer_layout, "first", 81),
                    transactional_record(&inner_layout, &outer_layout, "second", 82),
                ]
            },
            |values| {
                SafeArray::from_vba_records_nd(
                    vec![SafeArrayBound {
                        count: 2,
                        lower: -1,
                    }],
                    Arc::clone(&outer_layout),
                    values,
                )
            },
            "safearray-record-element-clone",
            2,
        );

        assert_payload_constructor_sweep(
            "intrinsic Variant payload",
            || {
                vec![
                    Variant::from_string("prefix BSTR"),
                    Variant::from_object_ref(ObjectRef::from_compat_identity(91)),
                    Variant::from_safearray(SafeArray::from_variants(vec![
                        Variant::from_string("nested SAFEARRAY BSTR"),
                        Variant::from_object_ref(ObjectRef::from_compat_identity(92)),
                    ])),
                    Variant::from_vba_record(transactional_record(
                        &inner_layout,
                        &outer_layout,
                        "record Variant",
                        93,
                    )),
                ]
            },
            |values| {
                SafeArray::from_shape_and_variants(
                    vec![SafeArrayBound { count: 4, lower: 3 }],
                    values,
                )
            },
            "safearray-intrinsic-element-clone",
            4,
        );

        clear_owning_boundary_failure();
        take_owning_boundary_trace();
    }

    #[test]
    fn safe_array_variant_element_reads_one_typed_payload_slot() {
        let array = SafeArray::from_typed_variants(
            VT_I2_VALUE,
            vec![
                Variant::from_i16(4),
                Variant::from_i16(9),
                Variant::from_i16(16),
            ],
        )
        .expect("typed array");

        assert_eq!(
            array.variant_element(1).expect("element"),
            Variant::from_i16(9)
        );
        assert_eq!(
            array.variant_element(3).expect_err("out of range"),
            "SAFEARRAY index 3 out of range for length 3"
        );
    }

    #[test]
    fn safe_array_variant_element_reads_owned_bstr_payload_slot() {
        let array = SafeArray::from_typed_variants(
            VT_BSTR_VALUE,
            vec![
                Variant::from_string("first"),
                Variant::from_string("second"),
            ],
        )
        .expect("typed bstr array");

        assert_eq!(
            array.variant_element(1).expect("element"),
            Variant::from_string("second")
        );
    }

    #[test]
    fn typed_i2_safearray_preserves_intrinsic_element_vartype() {
        let array = SafeArray::from_typed_variants(
            VT_I2_VALUE,
            vec![Variant::from_i16(4), Variant::from_i16(9)],
        )
        .expect("typed array");
        assert_eq!(array.element_vartype(), VT_I2_VALUE);
        assert_eq!(array.feature_flags(), FADF_HAVEVARTYPE_VALUE);
        assert_eq!(
            array.variant_elements(),
            Some(vec![Variant::from_i16(4), Variant::from_i16(9)])
        );
    }

    #[test]
    fn safearray_descriptor_advertises_special_typed_element_metadata() {
        let bstr = SafeArray::from_typed_variants(
            VT_BSTR_VALUE,
            vec![Variant::from_string(BStr::from("Alpha"))],
        )
        .expect("typed bstr array");
        assert_eq!(
            bstr.feature_flags(),
            FADF_HAVEVARTYPE_VALUE | FADF_BSTR_VALUE
        );

        let dispatch = SafeArray::from_typed_variants(
            VT_DISPATCH_VALUE,
            vec![Variant::from_object_ref(ObjectRef::from_compat_identity(
                41,
            ))],
        )
        .expect("typed dispatch array");
        assert_eq!(
            dispatch.feature_flags(),
            FADF_HAVEVARTYPE_VALUE | FADF_DISPATCH_VALUE
        );

        let unknown = SafeArray::from_typed_variants(
            VT_UNKNOWN_VALUE,
            vec![Variant::from_object_ref(ObjectRef::from_compat_identity(
                77,
            ))],
        )
        .expect("typed unknown array");
        assert_eq!(
            unknown.feature_flags(),
            FADF_HAVEVARTYPE_VALUE | FADF_UNKNOWN_VALUE
        );
    }

    #[test]
    fn typed_safearray_variant_elements_preserve_intrinsic_carriers_before_projection() {
        let array = SafeArray::from_typed_variants(
            VT_I2_VALUE,
            vec![Variant::from_i16(4), Variant::from_i16(9)],
        )
        .expect("typed array");

        assert_eq!(
            array.variant_elements().expect("variant elements"),
            vec![Variant::from_i16(4), Variant::from_i16(9)]
        );
    }

    #[test]
    fn typed_safearray_variant_construction_encodes_intrinsic_carriers_directly() {
        let array = SafeArray::from_typed_variants(
            VT_I2_VALUE,
            vec![Variant::from_i16(4), Variant::from_i16(9)],
        )
        .expect("typed array from Variants");

        assert_eq!(array.element_vartype(), VT_I2_VALUE);
        assert_eq!(
            array.variant_elements().expect("variant elements"),
            vec![Variant::from_i16(4), Variant::from_i16(9)]
        );
    }

    #[test]
    fn typed_exact_safearray_carriers_preserve_intrinsic_payloads() {
        let currency = SafeArray::from_typed_variants(
            VT_CY_VALUE,
            vec![Variant::from_currency_scaled_i64(-42_500)],
        )
        .expect("typed currency array");
        assert_eq!(
            currency.variant_elements().expect("currency elements")[0].as_currency_scaled_i64(),
            Some(-42_500)
        );

        let decimal_value = Decimal96::from_parts(123_450, 0, 0, 3, true);
        let decimal = SafeArray::from_typed_variants(
            VT_DECIMAL_VALUE,
            vec![Variant::from_decimal96(decimal_value)],
        )
        .expect("typed decimal array");
        assert_eq!(
            decimal.variant_elements().expect("decimal elements")[0].as_decimal96(),
            Some(decimal_value)
        );

        let date =
            SafeArray::from_typed_variants(VT_DATE_VALUE, vec![Variant::from_date_f64(46_081.25)])
                .expect("typed date array");
        assert_eq!(
            date.variant_elements().expect("date elements")[0].as_date_f64(),
            Some(46_081.25)
        );

        let boolean = SafeArray::from_typed_variants(VT_BOOL_VALUE, vec![Variant::from_bool(true)])
            .expect("typed bool array");
        assert_eq!(
            boolean.variant_elements().expect("bool elements")[0].as_bool(),
            Some(true)
        );
    }

    #[test]
    fn typed_bstr_safearray_roundtrips_strings_without_variant_normalization() {
        let array = SafeArray::from_typed_variants(
            VT_BSTR_VALUE,
            vec![
                Variant::from_string(BStr::from("Alpha")),
                Variant::from_string(BStr::from("Beta")),
            ],
        )
        .expect("typed bstr array");
        assert_eq!(array.element_vartype(), VT_BSTR_VALUE);
        assert_eq!(
            array.variant_elements(),
            Some(vec![
                Variant::from_string(BStr::from("Alpha")),
                Variant::from_string(BStr::from("Beta")),
            ])
        );
    }

    #[test]
    fn typed_dispatch_safearray_preserves_intrinsic_object_payloads() {
        let object = ObjectRef::from_compat_identity(41);
        let array = SafeArray::from_typed_variants(
            VT_DISPATCH_VALUE,
            vec![Variant::from_object_ref(object.clone())],
        )
        .expect("typed dispatch array");
        assert_eq!(array.element_vartype(), VT_DISPATCH_VALUE);
        let elements = array.variant_elements().expect("typed dispatch elements");
        assert_eq!(elements.len(), 1);
        assert_eq!(elements[0], Variant::from_object_ref(object));
    }

    #[test]
    fn typed_unknown_safearray_preserves_intrinsic_object_payloads() {
        let object = ObjectRef::from_compat_identity(77);
        let array = SafeArray::from_typed_variants(
            VT_UNKNOWN_VALUE,
            vec![Variant::from_object_ref(object.clone())],
        )
        .expect("typed unknown array");
        assert_eq!(array.element_vartype(), VT_UNKNOWN_VALUE);
        let elements = array.variant_elements().expect("typed unknown elements");
        assert_eq!(elements.len(), 1);
        assert_eq!(elements[0], Variant::from_object_ref(object));
    }
}

#[cfg(test)]
mod proptests {
    use super::{ARRAY_TAG_BASE, ARRAY_TAG_LIMIT, array_tag_from_safe_array, safe_array_from_tag};
    use proptest::prelude::*;

    proptest! {
        #[test]
        fn prop_safe_array_tag_roundtrip(len in 0..=1_000_000usize) {
            let tag = ARRAY_TAG_BASE + len as i32;
            prop_assert!((ARRAY_TAG_BASE..=ARRAY_TAG_LIMIT).contains(&tag));

            let array = safe_array_from_tag(tag)
                .expect("tag in valid range should decode to SafeArray");
            prop_assert_eq!(array.len(), len);
            prop_assert_eq!(array.dimensions(), 1);

            let recovered_tag = array_tag_from_safe_array(&array)
                .expect("decoded SafeArray should encode back to a tag");
            prop_assert_eq!(recovered_tag, tag);
        }
    }
}
