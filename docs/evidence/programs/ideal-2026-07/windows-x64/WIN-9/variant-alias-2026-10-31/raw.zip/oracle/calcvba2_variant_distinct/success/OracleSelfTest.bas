Option Explicit
Private Declare PtrSafe Function NativeAlias Lib "C:/Work/DnaCalc/codex-runs/calcvba-2-variant-alias/native_variant_alias.dll" Alias "AliasVariant" (ByRef first As Variant, ByRef second As Variant) As Long

Public Function RunProbe() As String
    Dim first As Variant
    Dim second As Variant
    Dim result As Long
    Dim savedError As Long
    first = CInt(7)
    second = CInt(7)
    result = NativeAlias(first, second)
    savedError = Err.LastDllError
    RunProbe = CStr(result) & "|" & TypeName(first) & "|" & TypeName(second) & "|" & CStr(first = 19) & "|" & CStr(second = 42.5) & "|" & CStr(savedError)
End Function
