from pathlib import Path
import hashlib
import json
import re
import subprocess
import zipfile
from datetime import datetime, timezone

root = Path('C:/Work/DnaCalc/OxVba')
out = root / 'docs/evidence/programs/ideal-2026-07/core/CORE-7'
raw = root / 'artifacts/calcvba7'
digest = lambda data: hashlib.sha256(data).hexdigest()
source = json.loads((raw / 'source-frozen.json').read_text(encoding='utf-8'))
for path, expected in source.items():
    assert digest((root / path).read_bytes()) == expected, path

def counts(path, workspace=False):
    text = path.read_text(encoding='utf-8')
    if workspace:
        assert '[oxvba] meta check complete' in text
        text = text.split('[oxvba] cargo test', 1)[1]
    results = re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out', text)
    assert results and all(r[0] == 'ok' for r in results), path
    values = dict(zip(['passed', 'failed', 'ignored', 'measured', 'filtered'],
                      [sum(int(row[n]) for row in results) for n in range(1, 6)]))
    assert values['failed'] == 0
    return {'suites': len(results), **values}

workspace = counts(raw / 'meta-check-validated.log', True)
assert (raw / 'extra-complete.txt').exists()
miri = counts(raw / 'miri-callbacks-final.log')
assert miri['passed'] == 8
assert counts(raw / 'miri-prefix-final.log')['passed'] == 1
live_name = 'calcvba7-final-source-range'
live_root = root / 'artifacts/windows-x64/worksheet-errors' / live_name
results = json.loads((live_root / 'results.json').read_text(encoding='utf-8-sig'))
assert results['passed'] and len(results['cases']) == 1
case = results['cases'][0]
assert case['compile_status'] == case['run_status'] == 'ok'
assert case['cleanup_status'] == 'owned-process-zero'
engine = json.loads((live_root / 'windows-scalar-interop/engine-range-test.json').read_text(encoding='utf-8-sig'))
assert engine['exit_code'] == 0 and engine['excel_pid'] != 3144
assert digest(Path(engine['executable']).read_bytes()) == engine['sha256']
log = (live_root / 'windows-scalar-interop/engine-range-test.log').read_text(encoding='utf-8-sig')
assert 'Interpreter: real Range identity/default arithmetic passed' in log
assert 'Jit: real Range identity/default arithmetic passed' in log

members = {'source/' + path: (root / path).read_bytes() for path in source}
for path in sorted(raw.rglob('*')):
    if path.is_file() and path.suffix != '.olean':
        members['raw/' + path.relative_to(root).as_posix()] = path.read_bytes()
for folder in sorted((root / 'artifacts/windows-x64/worksheet-errors').glob('calcvba7*')):
    for path in sorted(folder.rglob('*')):
        if path.is_file():
            members['raw/' + path.relative_to(root).as_posix()] = path.read_bytes()
for name in ['calcvba7-extra-checks.ps1', 'archive-calcvba7.py']:
    members['harness/' + name] = (Path(__file__).parent / name).read_bytes()
members['build/Cargo.lock'] = (root / 'Cargo.lock').read_bytes()
members['context/SYNTHESIS.md'] = Path('C:/Work/DnaCalc/parked/arch-review/SYNTHESIS.md').read_bytes()
archive = out / 'run7-validation.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
    for name, data in sorted(members.items()):
        bundle.writestr(name, data)

manifest = {
    'schema': 'oxvba.run7.development-evidence.v1',
    'created_utc': datetime.now(timezone.utc).isoformat(),
    'baseline_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
    'bounded_delivery_beads': ['bd-59co.2.10.9', 'bd-59co.2.9.12', 'bd-59co.2.4.9'],
    'broader_open_beads': ['bd-59co.2.9.9', 'bd-59co.2.10.7', 'bd-59co.2.4.3', 'bd-59co.2.10.10', 'bd-59co.2.9.13'],
    'archive': archive.name, 'archive_sha256': digest(archive.read_bytes()),
    'source_sha256': source,
    'archive_members_sha256': {name: digest(data) for name, data in sorted(members.items())},
    'repository_check': {'command': './scripts/meta-check.ps1 -Fast -NoArtifacts -NoRegistry -RunId calcvba7-final-validated',
                         'log': 'raw/artifacts/calcvba7/meta-check-validated.log', 'result': 'passed', 'counts': workspace,
                         'registry_writing_fixtures_excluded': 4, 'excluded_passing_credit': False},
    'interpreter_only': counts(raw / 'no-jit.log'),
    'wasm': {'command': 'cargo check -p calcvba-host-api -p oxvba-embed --no-default-features --target wasm32-unknown-unknown', 'result': 'passed', 'runtime_credit': False},
    'miri': {'flags': '-Zmiri-strict-provenance', 'callbacks': miri, 'native_prefix_passed': 1, 'jit_machine_code_credit': False},
    'lean': {'version': '4.29.1', 'models_passed': 7, 'implementation_refinement_proved': False},
    'live_excel': {**engine, 'run_id': live_name, 'compile_status': case['compile_status'], 'cleanup_status': case['cleanup_status'], 'certification_credit': False},
    'timing': {'log': 'raw/artifacts/calcvba7/host-call-cost.log', 'samples': 7, 'calls_per_sample': 100000, 'warmups': 1000,
               'native_reference_excludes_provider_validation_budget_and_object_table': True, 'host_unpinned': True, 'performance_guarantee': False},
    'blind_witnesses': {'repository': 'OxFunc-Evidence', 'commits': ['99a5a2e4', 'cba2fac2'], 'answers': 38, 'prediction_files_opened': False,
                        'reader_commit': 'c62ffca1e48b61989e7b481f9243a44fb6576b50', 'source_edited': False},
    'failed_attempts_credit': False,
    'formal_backlog': 'docs/evidence/formal/EXTENDED_TODO.md',
    'formal_backlog_id': 'FTODO-TYPED-HOST-20261031-R7',
}
(out / 'run7-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Archive:', len(members), 'members,', archive.stat().st_size, 'bytes')
print('Workspace:', workspace)
print('Interpreter-only:', manifest['interpreter_only'])
