//! The expression binder: `bind_expr` walks every expression CST node, infers a
//! `VarTypeRef` bottom-up, and emits a `CoreValue` (plus a `CorePlace` when the
//! expression denotes an l-value).

use oxvba_bundle::NumericMode;
use oxvba_bundle::coreir::{CoreArg, CoreBinOp, CoreConst, CorePlace, CoreUnOp, CoreValue};
use oxvba_bundle::{BundleImport, ExportToken, ProjectMemberKind};
use oxvba_symbol::binding::DispatchRoute;
use oxvba_symbol::model::SymbolKind;
use oxvba_symbol::signature::{BuiltinType, VarTypeRef};
use oxvba_syntax::{SyntaxKind, SyntaxNode, SyntaxToken};

use crate::call::com_member_return_type;
use crate::error::BindError;
use crate::types;
use crate::{Bound, ProcLower};

pub(crate) fn builtin(b: BuiltinType) -> VarTypeRef {
    VarTypeRef::Builtin(b)
}

pub(crate) fn value_bound(value: CoreValue, ty: VarTypeRef) -> Bound {
    Bound {
        value,
        ty,
        place: None,
    }
}

impl<'a> ProcLower<'a> {
    pub(crate) fn bind_expr(&mut self, node: SyntaxNode<'_>) -> Result<Bound, BindError> {
        match node.kind() {
            SyntaxKind::LiteralExpr => self.bind_literal(node),
            SyntaxKind::IdentExpr => self.bind_ident(node),
            SyntaxKind::ParenExpr => {
                let inner = node
                    .paren_inner()
                    .ok_or_else(|| BindError::Malformed("empty ()".into()))?;
                self.bind_expr(inner)
            }
            SyntaxKind::UnaryExpr => self.bind_unary(node),
            SyntaxKind::BinaryExpr => self.bind_binary(node),
            SyntaxKind::IndexExpr => self.bind_index_or_call(node),
            SyntaxKind::MemberExpr => self.bind_member(node),
            SyntaxKind::NewExpr => self.bind_new(node),
            SyntaxKind::AddressOfExpr => self.bind_address_of(node),
            SyntaxKind::ErrorNode => Err(BindError::Malformed("error expression node".into())),
            other => Err(BindError::Unsupported(format!("expression {other:?}"))),
        }
    }

    fn bind_literal(&self, node: SyntaxNode<'_>) -> Result<Bound, BindError> {
        let tok = node
            .first_significant_token()
            .ok_or_else(|| BindError::Malformed("empty literal".into()))?;
        let (value, ty) = match tok.kind {
            SyntaxKind::IntLiteral => {
                let c = parse_int(tok.text)?;
                let ty = const_type(&c);
                (c, ty)
            }
            SyntaxKind::HexLiteral => {
                let c = parse_radix(tok.text, 16)?;
                let ty = radix_literal_type(&c);
                (c, ty)
            }
            SyntaxKind::OctLiteral => {
                let c = parse_radix(tok.text, 8)?;
                let ty = radix_literal_type(&c);
                (c, ty)
            }
            SyntaxKind::FloatLiteral => {
                // `@` → Currency, `!` → Single, `#`/none → Double (the trailing
                // type-declaration character; see `CoreConst::from_float_literal`).
                let c = CoreConst::from_float_literal(tok.text)
                    .ok_or_else(|| BindError::Malformed(format!("float literal `{}`", tok.text)))?;
                let ty = const_type(&c);
                (c, ty)
            }
            SyntaxKind::StringLiteral => (
                CoreConst::Str(unquote(tok.text)),
                builtin(BuiltinType::String),
            ),
            SyntaxKind::KwTrue => (CoreConst::Bool(true), builtin(BuiltinType::Boolean)),
            SyntaxKind::KwFalse => (CoreConst::Bool(false), builtin(BuiltinType::Boolean)),
            SyntaxKind::KwEmpty => (CoreConst::Empty, VarTypeRef::Variant),
            SyntaxKind::KwNull => (CoreConst::Null, VarTypeRef::Variant),
            SyntaxKind::KwNothing => (CoreConst::Nothing, VarTypeRef::Variant),
            SyntaxKind::DateLiteral => (
                CoreConst::Date(
                    oxvba_symbol::const_eval::date::parse_date_literal_serial_bits(tok.text)
                        .ok_or_else(|| {
                            BindError::Malformed(format!("date literal `{}`", tok.text))
                        })?,
                ),
                builtin(BuiltinType::Date),
            ),
            other => return Err(BindError::Unsupported(format!("literal {other:?}"))),
        };
        Ok(value_bound(CoreValue::Const(value), ty))
    }

    fn bind_ident(&mut self, node: SyntaxNode<'_>) -> Result<Bound, BindError> {
        let tok = node
            .ident_name_token()
            .ok_or_else(|| BindError::Malformed("identifier without name".into()))?;
        let name = tok.text;
        if node.ident_is_me() {
            let me = self
                .me_value()
                .ok_or_else(|| BindError::Malformed("`Me` outside a class module".into()))?;
            let ty = self
                .info
                .class_name
                .as_deref()
                .map(|n| VarTypeRef::Object(n.to_string()))
                .unwrap_or(VarTypeRef::Variant);
            let place = match &me {
                CoreValue::Load(p) => Some(p.clone()),
                _ => None,
            };
            return Ok(Bound {
                value: me,
                ty,
                place,
            });
        }
        // Reading the function's own name yields the result pseudo-variable.
        if let Some(rl) = self.return_target(name) {
            let place = CorePlace::Local(rl);
            return Ok(Bound {
                value: CoreValue::Load(place.clone()),
                ty: self.info.return_type.clone(),
                place: Some(place),
            });
        }
        let binding = match self.resolve_suffixed(node, name) {
            Some(b) => b,
            None => {
                // An unresolved bare name may still be a `VB_PredeclaredId` class
                // name (a referenced project's exposed predeclared instance is not a
                // global-namespace name, so it doesn't `resolve`).
                if let Some(bound) = self.bind_predeclared_instance(name)? {
                    return Ok(bound);
                }
                let (place, ty) = self.implicit_local(name)?;
                return Ok(Bound {
                    value: CoreValue::Load(place.clone()),
                    ty,
                    place: Some(place),
                });
            }
        };
        // A referenced project's published `Const`/`Enum` value carries its literal
        // in the route (surface-driven, no shared-symbol dependence).
        if let DispatchRoute::ConstValue(c) = &binding.route {
            return Ok(value_bound(CoreValue::Const(c.clone()), const_type(c)));
        }
        if let DispatchRoute::ComObjectRoot { type_name, prog_id } = &binding.route {
            let prog_id = prog_id.clone().unwrap_or_else(|| type_name.clone());
            let args = vec![CoreArg::ByVal(CoreValue::Const(CoreConst::Str(prog_id)))];
            return Ok(value_bound(
                CoreValue::Call {
                    callee: oxvba_bundle::coreir::CoreCallee::Native(
                        oxvba_bundle::native::NativeImplId::CreateObject,
                    ),
                    args,
                },
                VarTypeRef::Object(type_name.clone()),
            ));
        }
        // An active-project `Const`/`Enum` member: its value is folded once in the
        // symbol layer (the published type system's single source of truth).
        if let Some(sym) = binding.symbol
            && let Some(c) = self.g.env.const_value(sym)
        {
            return Ok(value_bound(CoreValue::Const(c.clone()), const_type(c)));
        }
        // A `Const`/`Enum` member that did not fold is unresolvable (e.g. a circular
        // `Const` dependency) — a hard error, as in VBA. (Folding is non-fatal in the
        // symbol layer so one bad const can't abort a whole closure's binding; the
        // error surfaces here, at the use site.)
        if let Some(sym) = binding.symbol
            && matches!(
                self.g.env.symbols.symbol(sym).map(|s| s.kind),
                Some(SymbolKind::Const | SymbolKind::EnumMember)
            )
        {
            return Err(BindError::Unsupported(format!(
                "`{name}` is not a resolvable constant"
            )));
        }
        // A plain variable read.
        if let DispatchRoute::Value = binding.route
            && let Some(sym) = binding.symbol
            && let Some((place, ty)) = self.place_for_symbol(sym)
        {
            return Ok(Bound {
                value: CoreValue::Load(place.clone()),
                ty,
                place: Some(place),
            });
        }
        // A `VB_PredeclaredId` class name (which resolves as a class type/module, not
        // a plain value) → its global singleton instance.
        if let Some(bound) = self.bind_predeclared_instance(name)? {
            return Ok(bound);
        }
        if self.binding_is_module(&binding) {
            return Err(self.module_as_value_error(name));
        }
        // Otherwise a constant or a 0-argument call.
        self.bind_call_route(name, &binding, None)
    }

    /// A `VB_PredeclaredId` class referenced by its name → its global singleton: an
    /// active-project class lowers to `CoreValue::Predeclared`; a referenced project's
    /// exposed predeclared class lowers to a cross-bundle `CoreValue::PredeclaredExtern`
    /// (registering a `Class` import). These are VBA's document/class predeclared
    /// instances — `ThisWorkbook`, `Sheet1`, `UserForm1`, … Returns `None` when `name`
    /// is not a predeclared class.
    pub(crate) fn bind_predeclared_instance(
        &mut self,
        name: &str,
    ) -> Result<Option<Bound>, BindError> {
        let folded = oxvba_symbol::model::fold_identifier(name);
        if let Some(&class_id) = self.g.ids.predeclared_class_of.get(&folded) {
            let class_name = self.g.ids.classes[class_id.0].name.clone();
            let place = CorePlace::Predeclared { class: class_id };
            return Ok(Some(Bound {
                value: CoreValue::Predeclared { class: class_id },
                ty: VarTypeRef::Object(class_name),
                place: Some(place),
            }));
        }
        if let Some((unit, class)) = self.g.env.resolve_extern_predeclared(name) {
            let import = self.g.intern_import(BundleImport {
                unit,
                token: ExportToken::Class {
                    name: class.clone(),
                },
            });
            let place = CorePlace::PredeclaredExtern { import };
            return Ok(Some(Bound {
                value: CoreValue::PredeclaredExtern { import },
                ty: VarTypeRef::Object(class),
                place: Some(place),
            }));
        }
        Ok(None)
    }

    fn bind_unary(&mut self, node: SyntaxNode<'_>) -> Result<Bound, BindError> {
        let op = node
            .unary_op_token()
            .ok_or_else(|| BindError::Malformed("unary without operator".into()))?;
        let operand_node = node
            .unary_operand()
            .ok_or_else(|| BindError::Malformed("unary without operand".into()))?;
        let operand = self.bind_expr(operand_node)?;
        match op.kind {
            SyntaxKind::Plus => Ok(operand),
            // Unary minus is fixed-typed arithmetic: `-ai` (Integer) overflows at
            // `-(-32768)`; the numeric regime rides on the op.
            SyntaxKind::Minus => {
                let ty = operand.ty.clone();
                let value = CoreValue::Unary {
                    op: CoreUnOp::Negate,
                    expr: Box::new(operand.value),
                    num: self.g.numeric_mode(&ty),
                };
                Ok(value_bound(value, ty))
            }
            SyntaxKind::KwNot => {
                let ty = if types::is_boolean(&operand.ty) {
                    builtin(BuiltinType::Boolean)
                } else if self.g.is_longlong(&operand.ty) {
                    builtin(BuiltinType::LongLong)
                } else {
                    builtin(BuiltinType::Long)
                };
                Ok(value_bound(
                    CoreValue::Unary {
                        op: CoreUnOp::Not,
                        expr: Box::new(operand.value),
                        num: NumericMode::Widening,
                    },
                    ty,
                ))
            }
            other => Err(BindError::Unsupported(format!("unary {other:?}"))),
        }
    }

    fn bind_binary(&mut self, node: SyntaxNode<'_>) -> Result<Bound, BindError> {
        if node.is_typeof() {
            let operand_node = node
                .typeof_operand()
                .ok_or_else(|| BindError::Malformed("TypeOf without operand".into()))?;
            let type_node = node
                .typeof_type()
                .ok_or_else(|| BindError::Malformed("TypeOf without type".into()))?;
            let operand = self.bind_expr(operand_node)?;
            return Ok(value_bound(
                CoreValue::TypeOfIs {
                    object: Box::new(operand.value),
                    type_name: type_node.text().trim().to_string(),
                },
                builtin(BuiltinType::Boolean),
            ));
        }

        let op_tok = node
            .binary_op_token()
            .ok_or_else(|| BindError::Malformed("binary without operator".into()))?;
        let op = core_binop(op_tok.kind)
            .ok_or_else(|| BindError::Unsupported(format!("operator {:?}", op_tok.kind)))?;
        let lhs_node = node
            .binary_lhs()
            .ok_or_else(|| BindError::Malformed("binary lhs".into()))?;
        let rhs_node = node
            .binary_rhs()
            .ok_or_else(|| BindError::Malformed("binary rhs".into()))?;
        let mut lhs = self.bind_expr(lhs_node)?;
        let mut rhs = self.bind_expr(rhs_node)?;
        if op != CoreBinOp::Is {
            lhs = self.bind_default_member_value_context(lhs, lhs_node.text().trim())?;
            rhs = self.bind_default_member_value_context(rhs, rhs_node.text().trim())?;
        }
        if op == CoreBinOp::Is && (!is_object_is_operand(&lhs.ty) || !is_object_is_operand(&rhs.ty))
        {
            return Err(BindError::TypeMismatch);
        }
        // `\` and `Mod` always yield an integer (`LongLong` when either side is 64-bit,
        // else `Long`); the VM rounds the operands. Every other op's result type comes
        // from the promotion lattice.
        let ty = if matches!(op, CoreBinOp::IntDiv | CoreBinOp::Mod) {
            if self.g.is_longlong(&lhs.ty) || self.g.is_longlong(&rhs.ty) {
                builtin(BuiltinType::LongLong)
            } else {
                builtin(BuiltinType::Long)
            }
        } else {
            self.g.result_type(op, &lhs.ty, &rhs.ty)
        };
        // The numeric regime (checked-fixed vs widening) rides on the op itself, so the
        // VM and the JIT type the arithmetic without a separate coercion node.
        let value = CoreValue::Binary {
            op,
            lhs: Box::new(lhs.value),
            rhs: Box::new(rhs.value),
            mode: self.info.compare_mode,
            num: self.g.numeric_mode(&ty),
        };
        Ok(value_bound(value, ty))
    }

    pub(crate) fn bind_index_or_call(&mut self, node: SyntaxNode<'_>) -> Result<Bound, BindError> {
        let base = node
            .index_base()
            .ok_or_else(|| BindError::Malformed("index without base".into()))?;
        // Decide array-index vs call by resolving the base name. A name that
        // resolves to a callable is a call even when it equals the enclosing
        // function's name (a recursive call `f(args)` — VBA does not allow
        // indexing the result pseudo-variable, so `f(i)` is always a call).
        if base.kind() == SyntaxKind::IdentExpr
            && let Some(tok) = base.ident_name_token()
        {
            match self.resolve_suffixed(base, tok.text) {
                Some(binding) => {
                    if self.binding_is_module(&binding) {
                        return Err(self.module_as_value_error(tok.text));
                    }
                    if !matches!(binding.route, DispatchRoute::Value) {
                        return self.bind_call_route(tok.text, &binding, node.index_arg_list());
                    }
                }
                None => {
                    return Err(self.unresolved(tok.text, "call statement"));
                }
            }
        }
        // `obj(i)` on an Object variable is a DEFAULT-MEMBER call (`obj.Item(i)` /
        // dispid-0), not an array subscript. VBA resolves `obj(…)` for an object
        // receiver through its default member. The gate is the receiver's static
        // type being a scalar `Object` (a typed COM coclass, `Dim As Object`, the
        // built-in `Collection`, or a referenced coclass). A declared array
        // (`VarTypeRef::Array`, including `Dim arr() As Object`) and an ambiguous
        // bare `Variant` (which a `ReDim`/`ParamArray` makes an array, decided at
        // run time) are NOT objects here and fall through to the array-index path.
        //   * a typed COM receiver whose default member resolves to a ComMember →
        //     early-bound dispatch by the default member's dispid;
        //   * any other late-bound Object → late dispatch of the dispid-0 default
        //     member, named "Item" (Collection/Dictionary's default).
        if base.kind() == SyntaxKind::IdentExpr
            && let Some(tok) = base.ident_name_token()
            && let Some(sym) = self.resolve(tok.text).and_then(|b| b.symbol)
            && let ty @ VarTypeRef::Object(_) = self.symbol_type(sym)
        {
            if let Some(binding) = self.resolve_default_member(&ty) {
                match &binding.route {
                    DispatchRoute::ProjectMember { kind } => {
                        let sym = binding
                            .symbol
                            .ok_or_else(|| self.unresolved(tok.text, "default member"))?;
                        let member = self
                            .symbol_display_name(sym)
                            .unwrap_or_else(|| tok.text.to_string());
                        let kind = match kind {
                            ProjectMemberKind::Method => ProjectMemberKind::Method,
                            _ => ProjectMemberKind::PropertyGet,
                        };
                        let signature =
                            self.project_property_accessor_signature(sym, kind, &member)?;
                        let args = self.bind_proc_args(node.index_arg_list(), &signature, sym)?;
                        let ret = signature.return_type.unwrap_or(VarTypeRef::Variant);
                        let dispatch = self.interface_dispatch_name(&ty, &member);
                        let recv = CoreValue::Load(self.place_by_name(tok.text)?);
                        return Ok(value_bound(
                            self.late_member_call(&dispatch, kind, recv, args),
                            ret,
                        ));
                    }
                    DispatchRoute::ComMember {
                        member_name,
                        member_kind,
                        interface_name,
                        member: com_member,
                        ..
                    } => {
                        // `obj(i)` is a value-context read: dispatch the default member as a
                        // Property Get (or Method), never its Let/Set variant (a default
                        // member that shares its dispid across get/put/putref can resolve to
                        // the writer by typelib order).
                        let member_kind = match member_kind {
                            ProjectMemberKind::Method => ProjectMemberKind::Method,
                            _ => ProjectMemberKind::PropertyGet,
                        };
                        let recv = CoreValue::Load(self.place_by_name(tok.text)?);
                        let args = self.bind_com_args(node.index_arg_list(), com_member)?;
                        return Ok(value_bound(
                            self.early_com_call(
                                member_name,
                                member_kind,
                                interface_name,
                                com_member,
                                recv,
                                args,
                            ),
                            com_member_return_type(com_member),
                        ));
                    }
                    DispatchRoute::ExternMember {
                        member,
                        kind,
                        param_types,
                        ..
                    } => {
                        let kind = match kind {
                            ProjectMemberKind::Method => ProjectMemberKind::Method,
                            _ => ProjectMemberKind::PropertyGet,
                        };
                        let recv = CoreValue::Load(self.place_by_name(tok.text)?);
                        let args = self.bind_extern_args(node.index_arg_list(), param_types)?;
                        return Ok(value_bound(
                            self.late_member_call(member, kind, recv, args),
                            VarTypeRef::Variant,
                        ));
                    }
                    _ => {}
                }
            }
            if self.is_late_bound_receiver(&ty) {
                let recv = CoreValue::Load(self.place_by_name(tok.text)?);
                let args = self.bind_extern_args(node.index_arg_list(), &[])?;
                return Ok(value_bound(
                    self.late_default_member_call(
                        oxvba_bundle::ProjectMemberKind::PropertyGet,
                        recv,
                        args,
                    ),
                    VarTypeRef::Variant,
                ));
            }
        }
        // `obj.Member(args)` — a method/property call, or an index into a member
        // array. The member binder decides by resolving the member.
        if base.kind() == SyntaxKind::MemberExpr {
            return self.bind_member_call(base, node.index_arg_list());
        }
        // `Func(args)(key)` / `obj.Factory()(key)` — index the default member of
        // a value produced by another expression. This is common for Dictionary
        // helpers that return an object and are immediately indexed.
        if base.kind() == SyntaxKind::IndexExpr {
            let recv = self.bind_expr(base)?;
            let args = self.bind_positional_values(
                node.index_arg_list()
                    .ok_or_else(|| BindError::Malformed("default member index".into()))?,
            )?;
            return Ok(value_bound(
                self.late_default_member_call(
                    oxvba_bundle::ProjectMemberKind::PropertyGet,
                    recv.value,
                    args.into_iter().map(CoreArg::ByVal).collect(),
                ),
                VarTypeRef::Variant,
            ));
        }
        // An array element read.
        let (place, ty) = self.bind_place(node)?;
        Ok(Bound {
            value: CoreValue::Load(place.clone()),
            ty,
            place: Some(place),
        })
    }

    fn bind_new(&mut self, node: SyntaxNode<'_>) -> Result<Bound, BindError> {
        let name = node
            .new_type_name()
            .ok_or_else(|| BindError::Malformed("New without a type".into()))?;
        let (value, ty) = self.new_value_for_type(&name)?;
        Ok(value_bound(value, ty))
    }

    /// Resolve `New <name>` to its instantiation value + inferred object type — the
    /// resolution ladder shared by the `New` expression and `Dim x As New Foo`
    /// auto-instantiation. A project class mints in-bundle; a referenced project's
    /// coclass mints cross-bundle; a COM coclass activates via `CreateObject`.
    pub(crate) fn new_value_for_type(
        &mut self,
        name: &str,
    ) -> Result<
        (
            oxvba_bundle::coreir::CoreValue,
            oxvba_symbol::signature::VarTypeRef,
        ),
        BindError,
    > {
        self.g.new_value_for_type(name)
    }

    /// `AddressOf proc` — resolve the operand to a standard-module procedure and
    /// emit a procedure reference. VBA forbids `AddressOf` of a class member (it
    /// has no standalone address), so reject that.
    fn bind_address_of(&mut self, node: SyntaxNode<'_>) -> Result<Bound, BindError> {
        let operand = node
            .first_expr_child()
            .ok_or_else(|| BindError::Malformed("AddressOf without an operand".into()))?;
        let name = match operand.kind() {
            SyntaxKind::IdentExpr => operand.ident_name_token().map(|t| t.text),
            SyntaxKind::MemberExpr => operand.member_name_token().map(|t| t.text),
            _ => None,
        }
        .ok_or_else(|| BindError::Unsupported("AddressOf requires a procedure name".into()))?;
        let binding = self
            .resolve(name)
            .ok_or_else(|| self.unresolved(name, "AddressOf operand"))?;
        let proc = binding
            .symbol
            .and_then(|s| self.g.ids.proc_of.get(&s).copied())
            .ok_or_else(|| {
                BindError::Unsupported(format!("AddressOf of `{name}` (not a project procedure)"))
            })?;
        if self.g.ids.procs[proc.0].class_name.is_some() {
            return Err(BindError::Unsupported(format!(
                "AddressOf of class member `{name}` is not allowed"
            )));
        }
        Ok(value_bound(
            CoreValue::AddressOf(proc),
            builtin(BuiltinType::Long),
        ))
    }
}

// ── Literal parsing ──────────────────────────────────────────────────────────

fn parse_int(text: &str) -> Result<CoreConst, BindError> {
    CoreConst::from_int_literal(text)
        .ok_or_else(|| BindError::Malformed(format!("integer literal `{text}`")))
}

fn parse_radix(text: &str, radix: u32) -> Result<CoreConst, BindError> {
    // `&H1F` / `&O17`, with the width-based two's-complement sign rule and an
    // optional `%`/`&`/`^` type character (MS-VBAL §3.3.2).
    CoreConst::from_vba_radix(text, radix)
        .ok_or_else(|| BindError::Malformed(format!("radix literal `{text}`")))
}

/// The declared type of a hex/oct literal follows its width carrier.
fn radix_literal_type(c: &CoreConst) -> VarTypeRef {
    match c {
        CoreConst::I16(_) => builtin(BuiltinType::Integer),
        CoreConst::I64(_) => builtin(BuiltinType::LongLong),
        _ => builtin(BuiltinType::Long),
    }
}

fn unquote(text: &str) -> String {
    let inner = text.strip_prefix('"').unwrap_or(text);
    let inner = inner.strip_suffix('"').unwrap_or(inner);
    inner.replace("\"\"", "\"")
}

fn is_object_is_operand(ty: &VarTypeRef) -> bool {
    matches!(ty, VarTypeRef::Object(_) | VarTypeRef::Variant)
}

/// The inferred type of a folded constant value.
pub(crate) fn const_type(c: &CoreConst) -> VarTypeRef {
    match c {
        CoreConst::I16(_) => builtin(BuiltinType::Integer),
        CoreConst::I32(_) => builtin(BuiltinType::Long),
        CoreConst::I64(_) => builtin(BuiltinType::LongLong),
        CoreConst::F64(_) => builtin(BuiltinType::Double),
        CoreConst::F32(_) => builtin(BuiltinType::Single),
        CoreConst::Currency(_) => builtin(BuiltinType::Currency),
        CoreConst::Str(_) => builtin(BuiltinType::String),
        CoreConst::Bool(_) => builtin(BuiltinType::Boolean),
        CoreConst::Date(_) => builtin(BuiltinType::Date),
        _ => VarTypeRef::Variant,
    }
}

fn core_binop(kind: SyntaxKind) -> Option<CoreBinOp> {
    Some(match kind {
        SyntaxKind::Plus => CoreBinOp::Add,
        SyntaxKind::Minus => CoreBinOp::Sub,
        SyntaxKind::Star => CoreBinOp::Mul,
        SyntaxKind::Slash => CoreBinOp::Div,
        SyntaxKind::Backslash => CoreBinOp::IntDiv,
        SyntaxKind::Caret => CoreBinOp::Pow,
        SyntaxKind::Ampersand => CoreBinOp::Concat,
        SyntaxKind::Eq => CoreBinOp::Eq,
        SyntaxKind::LtGt => CoreBinOp::Ne,
        SyntaxKind::Lt => CoreBinOp::Lt,
        SyntaxKind::LtEq => CoreBinOp::Le,
        SyntaxKind::Gt => CoreBinOp::Gt,
        SyntaxKind::GtEq => CoreBinOp::Ge,
        SyntaxKind::KwMod => CoreBinOp::Mod,
        SyntaxKind::KwAnd => CoreBinOp::And,
        SyntaxKind::KwOr => CoreBinOp::Or,
        SyntaxKind::KwXor => CoreBinOp::Xor,
        SyntaxKind::KwEqv => CoreBinOp::Eqv,
        SyntaxKind::KwImp => CoreBinOp::Imp,
        SyntaxKind::KwIs => CoreBinOp::Is,
        SyntaxKind::KwLike => CoreBinOp::Like,
        _ => return None,
    })
}

/// The comparison `CoreBinOp` for a `Case Is <op>` operator token.
pub(crate) fn comparison_binop(tok: SyntaxToken<'_>) -> Option<CoreBinOp> {
    match tok.kind {
        SyntaxKind::Eq => Some(CoreBinOp::Eq),
        SyntaxKind::LtGt => Some(CoreBinOp::Ne),
        SyntaxKind::Lt => Some(CoreBinOp::Lt),
        SyntaxKind::LtEq => Some(CoreBinOp::Le),
        SyntaxKind::Gt => Some(CoreBinOp::Gt),
        SyntaxKind::GtEq => Some(CoreBinOp::Ge),
        _ => None,
    }
}
