
/// Windows x64 VARIANT layout used by the independent alias fixture.
#[repr(C)]
pub struct NativeVariant {
    vt: u16,
    reserved: [u16; 3],
    data: [u64; 2],
}
const _: () = assert!(std::mem::size_of::<NativeVariant>() == 24);
#[link(name = "oleaut32")]
unsafe extern "system" {
    fn VariantClear(value: *mut NativeVariant) -> i32;
}

#[unsafe(no_mangle)]
pub unsafe extern "system" fn AliasVariant(first: *mut NativeVariant, second: *mut NativeVariant) -> i32 {
    // SAFETY: both pointers refer to live initialized writable Windows VARIANTs.
    // Raw access deliberately permits aliasing. VariantClear releases the old
    // owned payload before each replacement; no pointer escapes this call.
    unsafe {
        if VariantClear(first) < 0 { return -1001; }
        first.write(NativeVariant { vt: 3, reserved: [0; 3], data: [19, 0] });
        let shared = first == second && (*second).vt == 3 && (*second).data[0] == 19;
        if VariantClear(second) < 0 { return -1002; }
        second.write(NativeVariant { vt: 5, reserved: [0; 3], data: [42.5_f64.to_bits(), 0] });
        ALIAS_CALLS.fetch_add(1, std::sync::atomic::Ordering::Relaxed);
        SetLastError(4321);
        if shared { 42 } else { -1 }
    }
}
