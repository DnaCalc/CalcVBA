Public Function RunProbe() As String
    Dim target As Excel.Range, cell As Excel.Range
    Dim book As Excel.Workbook, sheet As Excel.Worksheet, added As Excel.Worksheet
    Dim text As String, count As Long
    Set target = ThisWorkbook.Worksheets(1).Range("F1:G2")
    target.Value2 = 1#
    For Each cell In target
        text = text & cell.Address(False, False) & ":" & cell.Value2 & ";"
        cell.Offset(0, 1).Value2 = cell.Value2 + 10#
    Next
    RunProbe = text & "last=" & cell.Address(False, False)
    ThisWorkbook.Worksheets(1).Name = "Run13First"
    Set added = ThisWorkbook.Worksheets.Add(After:=ThisWorkbook.Worksheets(1))
    added.Name = "Run13Second"
    text = ""
    For Each sheet In ThisWorkbook.Worksheets
        count = count + 1
        text = text & sheet.Name & ";"
    Next
    RunProbe = RunProbe & "|sheets=" & count & ":" & text & "last=" & sheet.Name
    count = 0
    For Each book In Application.Workbooks
        count = count + 1
    Next
    RunProbe = RunProbe & "|books=" & count & ":" & book.Name
    Set book = Application.Workbooks.Item(ThisWorkbook.Name)
    Set sheet = book.Worksheets.Item("Run13Second")
    RunProbe = RunProbe & "|items=" & sheet.Name
End Function

