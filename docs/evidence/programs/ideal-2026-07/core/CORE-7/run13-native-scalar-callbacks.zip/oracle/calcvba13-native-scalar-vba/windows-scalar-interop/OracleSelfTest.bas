Option Explicit
Private Declare PtrSafe Function MutateDoubleThenCall Lib "C:\Work\DnaCalc\OxVba\temp\calcvba13\native-scalar-callback\native-scalar-callback.dll" (ByRef value As Double, ByRef sameValue As Double, ByVal callback As LongPtr) As Double
Private Declare PtrSafe Function MutateBooleanThenCall Lib "C:\Work\DnaCalc\OxVba\temp\calcvba13\native-scalar-callback\native-scalar-callback.dll" (ByRef value As Boolean, ByRef sameValue As Boolean, ByVal callback As LongPtr) As Boolean
Private aliasValue As Double
Private aliasFlag As Boolean
Public Function CallbackValue() As Double
    aliasValue = aliasValue + 0.5
    CallbackValue = aliasValue
End Function
Public Function BooleanCallbackValue() As Boolean
    aliasFlag = Not aliasFlag
    BooleanCallbackValue = aliasFlag
End Function

Public Function RunProbe() As String
    Dim observed As Double, observedFlag As Boolean
    aliasValue = 2#
    observed = MutateDoubleThenCall(aliasValue, aliasValue, AddressOf CallbackValue)
    RunProbe = "double=" & observed & ":" & aliasValue
    aliasFlag = False
    observedFlag = MutateBooleanThenCall(aliasFlag, aliasFlag, AddressOf BooleanCallbackValue)
    RunProbe = RunProbe & ";boolean=" & observedFlag & ":" & aliasFlag
End Function

