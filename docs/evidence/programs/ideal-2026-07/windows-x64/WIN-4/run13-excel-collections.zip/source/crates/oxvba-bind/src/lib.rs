//! `oxvba-bind` — the binder.
//!
//! A single typed pass that walks the resolved `oxvba-syntax` CST, asks the
//! `oxvba-symbol` resolution environment what each name means, infers types,
//! inserts coercions, and emits the symbol-free `oxvba_bundle::coreir` Core IR
//! that `oxvba-oxir::elaborate` turns into typed OxIR for VM3 and the JIT. This
//! ties the clean path together: source → preprocessing/CST → symbol resolution
//! → Core IR → OxIR/OxImage → VM3/JIT.

mod call;
mod error;
mod expr;
mod ids;
mod place;
mod proc;
mod stmt;
mod types;

pub use error::BindError;

use std::cell::RefCell;
use std::collections::{HashMap, HashSet};

use oxvba_bundle::coreir::{
    CoreArg, CoreAsNew, CoreClass, CoreClassAsNewField, CoreConst, CoreLocal, CoreLongPtrWidth,
    CorePlace, CoreProc, CoreProgram, CoreValue, LabelId, LocalId, ProcId,
};
use oxvba_bundle::{
    BundleExport, BundleImport, ComClassExport, EventRoute, ExportTarget, ExportToken,
    ExternalCallDescriptor, ProcedureKind, StringCompareMode,
};
use oxvba_bundle::{coreir::CoreCallee, native::NativeImplId};
use oxvba_runtime::DynLinkSymbol;
use oxvba_symbol::binding::{Binding, DispatchRoute};
use oxvba_symbol::manifest::{ModuleKind, SymbolProjectManifest};
use oxvba_symbol::model::{
    ScopeId, SymbolId, SymbolImpl, SymbolKind, SymbolNamespace, fold_identifier,
};
use oxvba_symbol::provider::{ResolutionContext, ResolutionEnvironment};
use oxvba_symbol::signature::{BuiltinType, VarTypeRef};
use oxvba_symbol::surface::ProjectExportSurface;
use oxvba_symbol::surface::{MemberOrigin, SurfaceType, SurfaceTypeKind};
use oxvba_symbol::{
    TypeLibResolver, build_resolution_environment,
    build_resolution_environment_with_project_surfaces,
};
use oxvba_syntax::{SyntaxKind, SyntaxNode};

use crate::ids::{DefaultTypeRules, IdAllocator, ProcInfo};

/// Collects the cross-bundle imports a project's binding makes (deduped by
/// `(unit, token)`, case-insensitively). Lives on [`Lower`] behind a `RefCell` so
/// any proc body can `intern` an import during lowering; drained into
/// `CoreProgram.imports` afterward, with each `ExternProc`/`NewExtern` carrying its
/// returned index.
#[derive(Default)]
struct ImportCollector {
    imports: Vec<BundleImport>,
}

impl ImportCollector {
    /// Return the index of `import`, adding it if new (VBA-case-insensitive match).
    fn intern(&mut self, import: BundleImport) -> usize {
        if let Some(i) = self.imports.iter().position(|e| {
            e.unit.eq_ignore_ascii_case(&import.unit) && e.token.matches(&import.token)
        }) {
            return i;
        }
        self.imports.push(import);
        self.imports.len() - 1
    }
}

/// Bind a whole project: parse (once) + resolve + lower every active module's
/// CST to symbol-free Core IR.
pub fn bind_program(
    manifest: &SymbolProjectManifest,
    typelibs: &dyn TypeLibResolver,
) -> Result<CoreProgram, BindError> {
    let env = build_resolution_environment(manifest, typelibs)?;
    bind_one(&env, manifest)
}

/// Compiler-owned procedure identity for hosting. Includes project-private
/// modules and private declarations; hosts choose their exposure policy.
#[derive(Debug, Clone)]
pub struct ModuleProcedure {
    pub index: usize,
    pub module: String,
    pub name: String,
    pub visibility: oxvba_symbol::model::Visibility,
    pub option_private_module: bool,
}

/// Bind once and publish module-procedure facts from the very same resolved CST.
/// Unlike cross-project exports, this catalogue retains Option Private Module.
pub fn bind_program_with_procedures(
    manifest: &SymbolProjectManifest,
    typelibs: &dyn TypeLibResolver,
) -> Result<(CoreProgram, Vec<ModuleProcedure>), BindError> {
    use oxvba_symbol::{
        model::Visibility,
        scanner::{decl_visibility, option_private_module},
    };
    let env = build_resolution_environment(manifest, typelibs)?;
    let core = bind_one(&env, manifest)?;
    let mut procedures = Vec::new();
    let mut index = 0;
    for module in env.modules() {
        let private_module = option_private_module(module.syntax)
            || manifest
                .modules
                .iter()
                .find(|m| m.module_name.eq_ignore_ascii_case(module.module_name))
                .is_some_and(|m| m.attributes.option_private_module);
        for declaration in module.syntax.child_nodes().into_iter().filter(|node| {
            matches!(
                node.kind(),
                SyntaxKind::SubDecl | SyntaxKind::FunctionDecl | SyntaxKind::PropertyDecl
            ) && node.proc_name_token().is_some()
        }) {
            if module.module_kind == ModuleKind::Procedural {
                procedures.push(ModuleProcedure {
                    index,
                    module: module.module_name.into(),
                    name: core.procs[index].name.clone(),
                    visibility: decl_visibility(declaration, Visibility::Public),
                    option_private_module: private_module,
                });
            }
            index += 1;
        }
    }
    Ok((core, procedures))
}

/// Bind one source project against already-compiled referenced project
/// surfaces. The supplied surfaces are the source-less equivalent of
/// `manifest.reference_projects`: they publish names, callable signatures, and
/// class activation contracts, while their bodies are linked later as separate
/// compiled programs.
pub fn bind_program_with_project_surfaces(
    manifest: &SymbolProjectManifest,
    typelibs: &dyn TypeLibResolver,
    external_project_surfaces: &[ProjectExportSurface],
) -> Result<CoreProgram, BindError> {
    let env = build_resolution_environment_with_project_surfaces(
        manifest,
        typelibs,
        external_project_surfaces,
    )?;
    bind_one(&env, manifest)
}

/// Bind every referenced project plus the active project — the **whole transitive
/// closure**, leaf-first — into one `CoreProgram` per project (each a bundle). Each
/// project is bound from its own full [`SymbolProjectManifest`] (carrying its
/// flattened transitive reference source). The caller elaborates each to OxIR and links
/// them with `oxvba_vm3::Vm3::link` (entry last); the linker resolves each import by unit
/// name against any loaded program and rejects a duplicate unit, so a shared/diamond
/// dependency (`A→B→D`, `A→C→D`) appears — and links — exactly once.
///
/// `closure_leaf_first` lists every project in the closure in leaf-first order,
/// **deduped by unit name** (a project that several others reference is bound once).
/// The active (entry) project is last.
pub fn bind_projects(
    closure_leaf_first: &[SymbolProjectManifest],
    typelibs: &dyn TypeLibResolver,
) -> Result<Vec<CoreProgram>, BindError> {
    // The closure is already deduped by project FILE (path); two entries sharing a
    // unit NAME are therefore two *different* projects colliding on a name — bind
    // none silently (it would drop a project's bundle entirely, and `Vm::link`
    // rejects duplicate unit names anyway). Error loudly instead.
    let mut seen: std::collections::HashSet<String> = std::collections::HashSet::new();
    let mut programs = Vec::with_capacity(closure_leaf_first.len());
    for manifest in closure_leaf_first {
        if !seen.insert(fold_identifier(&manifest.project_name)) {
            return Err(BindError::Malformed(format!(
                "duplicate project unit name `{}` in the reference closure",
                manifest.project_name
            )));
        }
        let env = build_resolution_environment(manifest, typelibs)?;
        programs.push(bind_one(&env, manifest)?);
    }
    Ok(programs)
}

/// Bind one project (already-built environment) to its `CoreProgram` bundle.
fn bind_one(
    env: &ResolutionEnvironment,
    manifest: &SymbolProjectManifest,
) -> Result<CoreProgram, BindError> {
    let ids = IdAllocator::build(env, manifest)?;
    let lower = Lower {
        env,
        manifest,
        ids: &ids,
        type_ctx: types::TypeContext::from_target(manifest.conditional_compilation_target),
        imports: RefCell::new(ImportCollector::default()),
        retained_object_names: RefCell::default(),
    };

    // Proc decl nodes in the same order `ids.procs` was built (ProcId order). The
    // two are produced by the identical filter; guard against any future drift so
    // a body can never be bound against the wrong frame.
    let decls = collect_proc_decls(env);
    if ids.procs.len() != decls.len() {
        return Err(BindError::Malformed(format!(
            "proc-decl/frame count mismatch: {} frames vs {} decls",
            ids.procs.len(),
            decls.len()
        )));
    }
    let mut procs: Vec<CoreProc> = Vec::with_capacity(ids.procs.len());
    for (info, decl) in ids.procs.iter().zip(decls.iter()) {
        let bound_body = lower.bind_proc_body(info, *decl)?;
        procs.push(CoreProc {
            name: info.name.clone(),
            kind: info.kind,
            params: info.params.clone(),
            locals: bound_body.locals,
            return_local: info.return_local,
            label_lines: bound_body.label_lines,
            body: bound_body.body,
        });
    }

    // Module-level fixed-size array globals AND every proc's `Static` array/record
    // locals are allocated once per VM session. Keep them in a hidden initializer
    // proc rather than splicing into `Main`, because COM activation-style hosts can
    // enter directly through class members without running the top-level entry proc.
    let mut inits = lower.module_global_array_inits()?;
    inits.extend(lower.static_local_inits(&decls)?);
    let global_initializer = if inits.is_empty() {
        None
    } else {
        let proc = ProcId(procs.len());
        procs.push(CoreProc {
            name: "__vba_global_initialize".to_string(),
            kind: ProcedureKind::Sub,
            params: Vec::new(),
            locals: Vec::new(),
            return_local: None,
            label_lines: Vec::new(),
            body: inits,
        });
        Some(proc)
    };

    let mut classes = ids.classes.clone();
    // Hidden class initializers are wired only through class metadata; exports,
    // event routes, and source-proc maps continue to come from `ids`.
    lower.attach_synthetic_class_initializers(&mut classes, &mut procs)?;
    lower.attach_class_as_new_fields(&mut classes)?;

    // The active project's published surface → this bundle's exports (the contract
    // a referrer's imports resolve against). Imports were accumulated while lowering.
    let exports = build_exports(env, &ids);
    let imports = lower.imports.into_inner().imports;

    let mut object_names = lower.retained_object_names.into_inner();
    fn collect_object_names(
        ty: &oxvba_bundle::VarTypeRef,
        names: &mut std::collections::BTreeSet<String>,
    ) {
        use oxvba_bundle::VarTypeRef;
        match ty {
            VarTypeRef::Object(name) => {
                names.insert(name.clone());
            }
            VarTypeRef::Array(element) | VarTypeRef::FixedArray { element, .. } => {
                collect_object_names(element, names)
            }
            _ => {}
        }
    }
    for global in &ids.globals {
        collect_object_names(&global.ty, &mut object_names);
    }
    for proc in &procs {
        for param in &proc.params {
            collect_object_names(&param.ty, &mut object_names);
        }
        for local in &proc.locals {
            collect_object_names(&local.ty, &mut object_names);
        }
    }
    for class in &classes {
        for field in &class.fields {
            collect_object_names(&field.ty, &mut object_names);
        }
    }
    let object_interfaces = object_names
        .iter()
        .map(|name| name.to_ascii_lowercase())
        .collect::<std::collections::BTreeSet<_>>()
        .iter()
        .filter_map(|name| env.object_interface(name))
        .collect();

    Ok(CoreProgram {
        long_ptr_width: core_long_ptr_width(manifest.conditional_compilation_target),
        globals: ids.globals.clone(),
        procs,
        classes,
        object_interfaces,
        event_routes: build_event_routes(env, &ids)?,
        external_calls: build_external_calls(env),
        com_class_exports: build_com_class_exports(manifest),
        entry: ids.entry(),
        global_initializer,
        unit_name: manifest.project_name.clone(),
        exports,
        imports,
    })
}

fn core_long_ptr_width(
    target: oxvba_symbol::cond_comp::ConditionalCompilationTarget,
) -> CoreLongPtrWidth {
    match target.pointer_width {
        oxvba_symbol::cond_comp::ConditionalCompilationPointerWidth::Bits32 => {
            CoreLongPtrWidth::Bits32
        }
        oxvba_symbol::cond_comp::ConditionalCompilationPointerWidth::Bits64 => {
            CoreLongPtrWidth::Bits64
        }
    }
}

/// This bundle's export table: each public coclass → a `Class` token resolving to
/// its `ClassId`; each public hidden-module member → a `ModuleFunc` token resolving
/// to its proc/accessor `ProcId`. Built from the active export surface (the single
/// source of truth for what is published) so source- and compiled-form contracts
/// agree.
fn build_exports(env: &ResolutionEnvironment, ids: &IdAllocator) -> Vec<BundleExport> {
    let Some(active) = env.export_surfaces().first() else {
        return Vec::new();
    };
    let mut exports = Vec::new();
    for ty in &active.types {
        match &ty.kind {
            SurfaceTypeKind::Coclass { .. } => {
                if let Some(&class_id) = ids.class_of.get(&fold_identifier(&ty.name)) {
                    exports.push(BundleExport {
                        token: ExportToken::Class {
                            name: ty.name.clone(),
                        },
                        target: ExportTarget::Class(class_id.0),
                    });
                }
            }
            SurfaceTypeKind::Module => export_module_members(ids, ty, &mut exports),
        }
    }
    exports
}

/// A hidden module's public members → `ModuleFunc` export tokens. A member's
/// `ProcId` comes from `proc_of` (method) or `prop_accessor_of` (a property/field
/// accessor), keyed by its originating symbol + kind.
fn export_module_members(ids: &IdAllocator, ty: &SurfaceType, out: &mut Vec<BundleExport>) {
    for m in &ty.members {
        let proc = match m.origin {
            MemberOrigin::Proc => ids.proc_of.get(&m.symbol).copied(),
            MemberOrigin::PropertyAccessor | MemberOrigin::Field => ids
                .prop_accessor_of
                .get(&(m.symbol, m.member_kind))
                .copied(),
        };
        if let Some(proc) = proc {
            out.push(BundleExport {
                token: ExportToken::ModuleFunc {
                    module: ty.name.clone(),
                    member: m.name.clone(),
                    kind: m.member_kind,
                },
                target: ExportTarget::Proc(proc.0),
            });
        }
    }
}

/// Proc decl nodes across all active modules, in `ProcId` order (mirrors the
/// loop in [`IdAllocator::build`]).
fn collect_proc_decls<'a>(env: &'a ResolutionEnvironment) -> Vec<SyntaxNode<'a>> {
    let mut decls = Vec::new();
    for module in env.modules() {
        for node in module.syntax.child_nodes() {
            if matches!(
                node.kind(),
                SyntaxKind::SubDecl | SyntaxKind::FunctionDecl | SyntaxKind::PropertyDecl
            ) && node.proc_name_token().is_some()
            {
                decls.push(node);
            }
        }
    }
    decls
}

/// Resolve `WithEvents` sinks to event routes: for each `WithEvents` field
/// (binding token `T`, source class `C`) in a sink class, and each event `E` of
/// `C`, a handler proc named `<field>_<event>` in the sink class produces an
/// `EventRoute{ binding: T, event: index(E), handler }`. This is the table vm2
/// consults when a `RaiseEvent` fires (`event_routes[(binding, event)]`).
fn build_event_routes(
    env: &ResolutionEnvironment,
    ids: &IdAllocator,
) -> Result<Vec<EventRoute>, BindError> {
    let symbols = &env.symbols;
    let module_scope_by_name: HashMap<String, ScopeId> = env
        .modules()
        .map(|m| (fold_identifier(m.module_name), m.module_scope))
        .collect();
    let active_project_name = env
        .export_surfaces()
        .first()
        .map(|surface| fold_identifier(&surface.project_name));
    let mut routes = Vec::new();
    for (&field_sym, &binding) in &ids.withevents_binding_of {
        let Some(field) = symbols.symbol(field_sym) else {
            continue;
        };
        let sink_scope = field.scope;
        let Some(field_name) = symbols.name(field.name).map(|n| n.folded.clone()) else {
            continue;
        };
        // The source class is the WithEvents field's declared object type — an
        // active class OR a referenced one (resolved through its export surface).
        let SymbolImpl::DeclaredType(VarTypeRef::Object(source_name)) = &field.imp else {
            continue;
        };
        let Some(events) = source_events(
            env,
            ids,
            &module_scope_by_name,
            active_project_name.as_deref(),
            source_name,
        ) else {
            return Err(BindError::Unresolved {
                name: source_name.clone(),
                context: "WithEvents source type".to_string(),
            });
        };
        for (ev_name_folded, event) in events {
            let handler_name = format!("{field_name}_{ev_name_folded}");
            if let Ok(Some(handler_sym)) =
                symbols.find_in_scope(sink_scope, SymbolNamespace::Procedure, &handler_name)
                && let Some(&proc) = ids.proc_of.get(&handler_sym)
            {
                routes.push(EventRoute {
                    binding,
                    event,
                    handler: proc.0,
                });
            }
        }
    }
    // A COM coclass source reads LIBRARY-WIDE typelib events, so an event name shared
    // across source interfaces (e.g. `SheetChange` on both `AppEvents` and
    // `WorkbookEvents`, which Excel assigns the same dispid) yields one route per
    // occurrence — all with an identical `(binding, event, handler)`. Collapse those
    // duplicates so a `WithEvents` field is advised once per (binding, event).
    //
    // NOTE: `EventRoute` carries no connection-point IID, so this dedup cannot choose
    // BETWEEN distinct source interfaces that share a dispid — it only removes exact
    // duplicates. The runtime selects the actual connection point from the bound object's
    // own (coclass-scoped) `event_specs`. That is correct for the common single-source case
    // and for same-named shared-dispid events (identical handler => genuinely one route);
    // a coclass exposing two DIFFERENTLY-named events on one dispid would need the IID
    // carried here to disambiguate — see `event_specs_from_typelib_metadata`.
    let mut seen = std::collections::HashSet::new();
    routes.retain(|route| seen.insert((route.binding, route.event, route.handler)));
    Ok(routes)
}

/// The `(folded event name, event id)` list of a WithEvents source class. An
/// **active** source reads its `Event` symbols + `ids.event_index_of`; a
/// **referenced** source reads its export surface's `SurfaceEvent`s (whose
/// `event_id` equals the source bundle's own `event_index_of`, so a sink built here
/// routes the same id the source's `RaiseEvent` fires). A **COM coclass** source
/// (a referenced typelib coclass, e.g. `OxVba.TestEventServer`) reads the typelib's
/// source events via the `ComTypeLibProvider`, whose `event id` is the event's
/// dispid/token — exactly the value `subscribe_com_events` passes to
/// `subscribe_event`, so a delivered callback for that dispid routes to the handler.
/// `source_name` may be project-qualified (`Lib.Clock`).
fn source_events(
    env: &ResolutionEnvironment,
    ids: &IdAllocator,
    module_scope_by_name: &HashMap<String, ScopeId>,
    active_project_name: Option<&str>,
    source_name: &str,
) -> Option<Vec<(String, i32)>> {
    // Active project class.
    let source_name_folded = fold_identifier(source_name);
    let active_class_name = match source_name.split_once('.') {
        Some((project, class))
            if active_project_name.is_some_and(|active| fold_identifier(project) == active) =>
        {
            Some(fold_identifier(class))
        }
        Some(_) => None,
        None => Some(source_name_folded),
    };
    if let Some(source_class_name) = active_class_name
        && let Some(&source_scope) = module_scope_by_name.get(&source_class_name)
    {
        let symbols = &env.symbols;
        let mut out = Vec::new();
        for ev_sym in symbols.symbols_in_scope(source_scope).unwrap_or_default() {
            let Some(ev) = symbols.symbol(ev_sym) else {
                continue;
            };
            if ev.kind != SymbolKind::Event {
                continue;
            }
            let Some(&event) = ids.event_index_of.get(&ev_sym) else {
                continue;
            };
            let Some(ev_name) = symbols.name(ev.name).map(|n| n.folded.clone()) else {
                continue;
            };
            out.push((ev_name, event));
        }
        return Some(out);
    }
    // Referenced project class (possibly `Project.Class`). Search the referenced
    // surfaces (index 0 is the active project's own surface, skipped).
    let (proj, class) = match source_name.split_once('.') {
        Some((p, c)) => (Some(fold_identifier(p)), fold_identifier(c)),
        None => (None, fold_identifier(source_name)),
    };
    for surface in env.export_surfaces().iter().skip(1) {
        if proj
            .as_deref()
            .is_some_and(|p| fold_identifier(&surface.project_name) != p)
        {
            continue;
        }
        if let Some(ty) = surface
            .types
            .iter()
            .find(|t| fold_identifier(&t.name) == class)
        {
            return Some(
                ty.events
                    .iter()
                    .map(|e| (fold_identifier(&e.name), e.event_id))
                    .collect(),
            );
        }
    }
    // Referenced COM coclass (a typelib source). The `event id` is the event's
    // dispid/token — the runtime subscribe/poll key.
    if let Some(events) = env.com_source_events(source_name) {
        return Some(events);
    }
    None
}

/// Build the `Declare Lib` external-call descriptors from the scanned `Declare`
/// symbols. The source-declared fields come straight from the symbol model; the
/// runtime-resolution fields (`symbol`/`marshal_lane`/`selection_policy`) get the
/// loader's canonical defaults. ByRef write-back targets are the call-site
/// `CallArg::ByRef` slots, so the descriptor carries no write-back list.
///
/// `marshal_lane` is a **static** property of the target: a real library binds to
/// the native FFI lane (`m1-native-ffi`); the synthetic `host` library (the HAL's
/// `hostping`/`hostdouble` self-test symbols) stays on the deterministic lane. The
/// HAL decides at run time whether to actually call native code (it requires
/// `allow_dynamic_link` + a non-deterministic policy on a matching host profile),
/// so sandboxed/deterministic runs stay safe without any binder-side policy logic.
fn build_external_calls(env: &ResolutionEnvironment) -> Vec<ExternalCallDescriptor> {
    let mut out: Vec<ExternalCallDescriptor> = Vec::new();
    for sym in env.symbols.symbols() {
        let SymbolImpl::Declare(d) = &sym.imp else {
            continue;
        };
        let marshal_lane = if d.library.eq_ignore_ascii_case("host") {
            "m0-deterministic"
        } else {
            "m1-native-ffi"
        };
        out.push(ExternalCallDescriptor {
            descriptor_id: d.descriptor_id,
            declared_name: d.declared_name.clone(),
            library: d.library.clone(),
            alias: d
                .ordinal_value
                .map_or_else(|| d.alias.clone(), |ordinal| format!("#{ordinal}")),
            ordinal_alias: d.ordinal_alias,
            symbol: DynLinkSymbol::new(d.descriptor_id as i32),
            marshal_lane: marshal_lane.to_string(),
            calling_convention: "platform-default".to_string(),
            selection_policy: if d.ordinal_alias {
                "ordinal-literal-canonical".to_string()
            } else {
                "case-insensitive-canonical".to_string()
            },
            param_count: d.param_types.len(),
            param_types: d.param_types.clone(),
            param_by_ref: d.param_by_ref.clone(),
            return_type: d.return_type,
        });
    }
    out.sort_by_key(|d| d.descriptor_id);
    out.dedup_by_key(|d| d.descriptor_id);
    out
}

/// COM-server export metadata for each class module (hosting only; not used by
/// VM execution). `creatable`/`prog_id` come from the module's VB attributes.
fn build_com_class_exports(manifest: &SymbolProjectManifest) -> Vec<ComClassExport> {
    manifest
        .modules
        .iter()
        .filter(|m| m.module_kind == ModuleKind::Class)
        .map(|m| {
            let class_name = if m.attributes.vb_name.is_empty() {
                m.module_name.clone()
            } else {
                m.attributes.vb_name.clone()
            };
            ComClassExport {
                class_name,
                prog_id: m.attributes.prog_id.clone(),
                creatable: m.attributes.vb_creatable,
            }
        })
        .collect()
}

/// Project-wide immutable lowering context (resolution + id maps). The import
/// collector is interior-mutable so proc bodies can register cross-bundle imports.
struct Lower<'a> {
    env: &'a ResolutionEnvironment,
    manifest: &'a SymbolProjectManifest,
    ids: &'a IdAllocator,
    type_ctx: types::TypeContext,
    imports: RefCell<ImportCollector>,
    retained_object_names: RefCell<std::collections::BTreeSet<String>>,
}

impl Lower<'_> {
    /// Register a cross-bundle import and return its index in `CoreProgram.imports`.
    fn intern_import(&self, import: BundleImport) -> usize {
        self.imports.borrow_mut().intern(import)
    }

    fn coerce_store(&self, value: CoreValue, to: &VarTypeRef) -> CoreValue {
        types::coerce_store_with(self.type_ctx, value, to)
    }

    fn coerce(&self, value: CoreValue, from: &VarTypeRef, to: &VarTypeRef) -> CoreValue {
        types::coerce_with(self.type_ctx, value, from, to)
    }

    fn numeric_mode(&self, ty: &VarTypeRef) -> oxvba_bundle::NumericMode {
        types::numeric_mode_with(self.type_ctx, ty)
    }

    fn result_type(
        &self,
        op: oxvba_bundle::coreir::CoreBinOp,
        lhs: &VarTypeRef,
        rhs: &VarTypeRef,
    ) -> VarTypeRef {
        types::result_type_with(self.type_ctx, op, lhs, rhs)
    }

    fn is_longlong(&self, ty: &VarTypeRef) -> bool {
        types::is_longlong_with(self.type_ctx, ty)
    }

    /// Resolve `New <name>` to its instantiation value + inferred object type — the
    /// resolution ladder shared by the `New` expression and every `As New` slot.
    fn new_value_for_type(
        &self,
        name: &str,
    ) -> Result<(CoreValue, oxvba_symbol::signature::VarTypeRef), BindError> {
        let folded = oxvba_symbol::model::fold_identifier(name);
        if let Some(&class_id) = self.ids.class_of.get(&folded) {
            return Ok((
                CoreValue::New(class_id),
                VarTypeRef::Object(name.to_string()),
            ));
        }
        // A creatable coclass published by a referenced project.
        if let Some((unit, class)) = self.env.resolve_extern_coclass(name) {
            let import = self.intern_import(BundleImport {
                unit,
                token: ExportToken::Class {
                    name: class.clone(),
                },
            });
            return Ok((CoreValue::NewExtern { import }, VarTypeRef::Object(class)));
        }
        // A creatable COM coclass from a referenced typelib.
        if let Some(prog_id) = self.env.resolve_coclass(name) {
            let args = vec![CoreArg::ByVal(CoreValue::Const(CoreConst::Str(prog_id)))];
            return Ok((
                CoreValue::Call {
                    callee: CoreCallee::Native(NativeImplId::CreateObject),
                    args,
                },
                VarTypeRef::Object(name.to_string()),
            ));
        }
        Err(BindError::Unsupported(format!(
            "New {name} (only project classes are creatable)"
        )))
    }

    fn as_new_binding_for_type(&self, type_name: &str) -> Result<CoreAsNew, BindError> {
        let (value, _ty) = self.new_value_for_type(type_name)?;
        match value {
            CoreValue::New(class) => Ok(CoreAsNew::ProjectClass { class }),
            CoreValue::NewExtern { import } => Ok(CoreAsNew::ExternClass { import }),
            CoreValue::Call { callee, args } => match (callee, args.as_slice()) {
                (
                    CoreCallee::Native(NativeImplId::CreateObject),
                    [CoreArg::ByVal(CoreValue::Const(CoreConst::Str(prog_id)))],
                ) => Ok(CoreAsNew::ComClass {
                    prog_id: prog_id.clone(),
                }),
                _ => Err(BindError::Unsupported(format!(
                    "As New {type_name} (unsupported activation path)"
                ))),
            },
            _ => Err(BindError::Unsupported(format!(
                "As New {type_name} (unsupported activation path)"
            ))),
        }
    }

    fn attach_class_as_new_fields(&self, classes: &mut [CoreClass]) -> Result<(), BindError> {
        for module in self.env.modules() {
            let Some(display) = ids::class_name_for(self.manifest, module.module_name) else {
                continue;
            };
            let Some(&class_id) = self.ids.class_of.get(&fold_identifier(&display)) else {
                continue;
            };
            let class = classes
                .get_mut(class_id.0)
                .ok_or_else(|| BindError::Malformed(format!("unknown class `{display}`")))?;
            let mut as_new_fields = Vec::new();
            for node in module.syntax.child_nodes() {
                if node.kind() != SyntaxKind::DimStmt {
                    continue;
                }
                for declarator in node.declarators() {
                    if !declarator.is_new() {
                        continue;
                    }
                    let Some(name) = declarator.declarator_name() else {
                        continue;
                    };
                    let logical = name.text.trim_start_matches('[').trim_end_matches(']');
                    let sym = self
                        .env
                        .symbols
                        .find_in_scope(module.module_scope, SymbolNamespace::Member, logical)
                        .map_err(|e| BindError::Malformed(format!("{e:?}")))?
                        .ok_or_else(|| {
                            BindError::Malformed(format!("class field `{logical}` has no symbol"))
                        })?;
                    let field = *self.ids.field_token_of.get(&sym).ok_or_else(|| {
                        BindError::Malformed(format!("class field `{logical}` has no field token"))
                    })?;
                    let Some(symbol) = self.env.symbols.symbol(sym) else {
                        return Err(BindError::Malformed(format!(
                            "class field `{logical}` symbol is missing"
                        )));
                    };
                    if symbol.kind != SymbolKind::Field {
                        continue;
                    }
                    let SymbolImpl::DeclaredType(VarTypeRef::Object(type_name)) = &symbol.imp
                    else {
                        continue;
                    };
                    as_new_fields.push(CoreClassAsNewField {
                        field,
                        binding: self.as_new_binding_for_type(type_name)?,
                    });
                }
            }
            class.as_new_fields = as_new_fields;
        }
        Ok(())
    }

    /// A declared type name may be a class, a `Type` (UDT), or an `Enum`; the
    /// parser/scanner initially carries all user-defined names as `Object(name)`.
    /// Normalize the value-type cases wherever the binder reads a declared type.
    fn resolve_udt_type(&self, ty: VarTypeRef) -> VarTypeRef {
        match ty {
            VarTypeRef::Object(name) if self.env.is_udt(&name) => VarTypeRef::Udt(name),
            VarTypeRef::Object(name) if self.env.is_enum_type(&name) => {
                VarTypeRef::Builtin(oxvba_symbol::signature::BuiltinType::Long)
            }
            VarTypeRef::FixedArray { element, bounds } => VarTypeRef::FixedArray {
                element: Box::new(self.resolve_udt_type(*element)),
                bounds,
            },
            VarTypeRef::Array(element) => {
                VarTypeRef::Array(Box::new(self.resolve_udt_type(*element)))
            }
            other => other,
        }
    }

    /// The runtime array-element layout for a `ReDim`/`Erase` element type. Builtin
    /// elements map to their scalar tag; a **UDT element** becomes a recursive
    /// [`ArrayElementType::Record`] carrying each field's layout (so the VM seeds a
    /// default record per element, recursing into nested scalar-UDT subfields). A
    /// field that is itself an *array* (of UDT or otherwise) stays `Variant` —
    /// unallocated until its own `ReDim`. The recursion terminates because VBA
    /// forbids by-value self-referential UDTs.
    fn array_element_layout(&self, elem: &VarTypeRef) -> oxvba_bundle::ArrayElementType {
        match self.resolve_udt_type(elem.clone()) {
            VarTypeRef::Udt(udt) => {
                let fields = self
                    .env
                    .udt_field_list(&udt)
                    .map(|fs| {
                        fs.iter()
                            .map(|(_, ty)| self.array_field_layout(ty))
                            .collect()
                    })
                    .unwrap_or_default();
                oxvba_bundle::ArrayElementType::Record(fields)
            }
            other => crate::types::array_element_of_with(self.type_ctx, &other),
        }
    }

    /// The layout of one *record field* for [`Self::array_element_layout`]: a scalar
    /// UDT field is a nested `Record`; an array field (`Words() As OcrWord`) stays
    /// `Variant` (unallocated until `ReDim`); a builtin maps to its scalar tag.
    fn array_field_layout(&self, ty: &VarTypeRef) -> oxvba_bundle::ArrayElementType {
        match self.resolve_udt_type(ty.clone()) {
            VarTypeRef::Udt(_) => self.array_element_layout(ty),
            VarTypeRef::FixedString(len) => {
                oxvba_bundle::ArrayElementType::FixedString(len as usize)
            }
            VarTypeRef::FixedArray { element, bounds } => {
                oxvba_bundle::ArrayElementType::FixedArray {
                    element: Box::new(self.array_field_layout(&element)),
                    bounds,
                }
            }
            VarTypeRef::Array(_) => oxvba_bundle::ArrayElementType::Variant,
            other => crate::types::array_element_of_with(self.type_ctx, &other),
        }
    }
}

/// Per-procedure mutable lowering state.
struct ProcLower<'a> {
    g: &'a Lower<'a>,
    info: LowerContext,
    locals: Vec<CoreLocal>,
    implicit_local_of: HashMap<String, LocalId>,
    /// Active `With` receivers (for leading-dot member access).
    with_stack: Vec<Bound>,
    /// Source-level loop nesting used to validate `Exit For` / `Exit Do`.
    loop_stack: Vec<LoopContext>,
    next_with_temp: usize,
    /// Label name → its allocated id (allocated on first reference).
    labels: HashMap<String, LabelId>,
    label_order: Vec<String>,
    /// Labels actually *defined* (via a `LabelStmt`), as opposed to merely
    /// referenced (`GoTo`/`GoSub`/`On Error GoTo`/`Resume`). Used to reject a
    /// label defined more than once within the procedure — a VBA compile error
    /// ("Duplicate declaration in current scope"). Label scope is per-procedure,
    /// so this set is fresh per [`ProcLower`].
    defined_labels: HashSet<LabelId>,
    /// Numeric-line metadata parallel to `label_order`: `Some(n)` for a label
    /// definition whose source token is an integer line number.
    label_lines: Vec<Option<i32>>,
}

struct LowerContext {
    name: String,
    /// The symbol-model scope used for unqualified name resolution. Procedure
    /// bodies use their procedure scope; module-level declarations use the
    /// declaring module scope so `Private` globals resolve exactly as they do in
    /// VBA.
    proc_scope: ScopeId,
    local_of: HashMap<SymbolId, LocalId>,
    param_count: usize,
    return_local: Option<LocalId>,
    return_type: VarTypeRef,
    class_name: Option<String>,
    me_local: Option<LocalId>,
    compare_mode: StringCompareMode,
    option_base: i32,
    option_explicit: bool,
    default_types: DefaultTypeRules,
}

impl LowerContext {
    fn from_proc(info: &ProcInfo) -> Self {
        Self {
            name: info.name.clone(),
            proc_scope: info.proc_scope,
            local_of: info.local_of.clone(),
            param_count: info.params.len(),
            return_local: info.return_local,
            return_type: info.return_type.clone(),
            class_name: info.class_name.clone(),
            me_local: info.me_local,
            compare_mode: info.compare_mode,
            option_base: info.option_base,
            option_explicit: info.option_explicit,
            default_types: info.default_types.clone(),
        }
    }

    fn from_module(
        module_name: &str,
        module_scope: ScopeId,
        compare_mode: StringCompareMode,
        option_base: i32,
    ) -> Self {
        Self {
            name: module_name.to_string(),
            proc_scope: module_scope,
            local_of: HashMap::new(),
            param_count: 0,
            return_local: None,
            return_type: VarTypeRef::Variant,
            class_name: None,
            me_local: None,
            compare_mode,
            option_base,
            option_explicit: false,
            default_types: DefaultTypeRules::default(),
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum LoopContext {
    For,
    Do,
    While,
}

/// The result of binding an expression: its value, inferred type, and (when it
/// denotes an l-value) the place it reads from / writes to.
#[derive(Debug, Clone)]
struct Bound {
    value: CoreValue,
    ty: VarTypeRef,
    /// The l-value this expression denotes, when any. Consumed by the
    /// objects/COM phase (default-member application, `With`/member receivers)
    /// and by `udt_receiver_place` to reach a UDT `With`-receiver's record.
    place: Option<CorePlace>,
}

/// The builtin type a VBA type-declaration character denotes (`$`→String, `%`→
/// Integer, …). Used to tell a genuine type-suffixed variable/function reference
/// (which the suffix matches) from a `$`-variant library intrinsic shadowed by an
/// unrelated same-named member. Returns `None` for an unrecognized suffix.
fn type_decl_builtin(suffix: &str) -> Option<BuiltinType> {
    Some(match suffix {
        "%" => BuiltinType::Integer,
        "&" => BuiltinType::Long,
        "^" => BuiltinType::LongLong,
        "!" => BuiltinType::Single,
        "#" => BuiltinType::Double,
        "@" => BuiltinType::Currency,
        "$" => BuiltinType::String,
        _ => return None,
    })
}

impl<'a> ProcLower<'a> {
    // ── Resolution helpers ──────────────────────────────────

    fn resolve(&self, name: &str) -> Option<Binding> {
        self.g
            .env
            .resolve(&ResolutionContext::at(self.info.proc_scope), name)
    }

    /// Resolve a bare identifier that may carry a type-declaration suffix (`Left$`,
    /// `count%`). VBA treats the `$`/`%`/… variant of a library intrinsic (`Left$`,
    /// `Str$`, …) as an identifier *distinct* from the bare name: a type-declaration
    /// character denotes a variable/function/property only when that referent's type
    /// matches the character, so a `Left As Single` property can never be `Left$`. So
    /// when a
    /// suffix is present and the bare-name resolution would otherwise bind to a
    /// referent whose type is incompatible with the suffix — e.g. a control's
    /// `Left As Single` property (including the implicit-`Me` `Left` inside the very
    /// class that owns it) shadowing the `Left$` string intrinsic — fall through to
    /// the same-suffixed library intrinsic. The scope chain holds no symbol folded
    /// *with* a suffix, so re-resolving the suffixed name reaches the VBA library
    /// provider's `$`-variant entry (`name_to_intrinsic("Left$")`); if there is no
    /// such intrinsic it is an ordinary suffixed variable read and the bare
    /// resolution stands.
    fn resolve_suffixed(&self, node: SyntaxNode<'_>, name: &str) -> Option<Binding> {
        let bare = self.resolve(name);
        let Some(suffix) = node.type_suffix_token() else {
            return bare;
        };
        let Some(suffix_ty) = type_decl_builtin(suffix.text) else {
            return bare;
        };
        if let Some(binding) = &bare
            && self.suffix_matches_referent(binding, suffix_ty)
        {
            return bare;
        }
        self.resolve(&format!("{name}{}", suffix.text)).or(bare)
    }

    /// Does `binding`'s referent legitimately carry a type-declaration suffix
    /// denoting `suffix_ty`? A same-typed variable/const read, or a function /
    /// property whose value type matches, can; anything else (a mismatched
    /// property/method, or a library intrinsic) cannot — the suffix then denotes the
    /// library intrinsic instead.
    fn suffix_matches_referent(&self, binding: &Binding, suffix_ty: BuiltinType) -> bool {
        let want = VarTypeRef::Builtin(suffix_ty);
        match &binding.route {
            DispatchRoute::Value => binding
                .symbol
                .is_some_and(|sym| self.symbol_type(sym) == want),
            DispatchRoute::ProjectMember { kind } => {
                self.member_return_type(binding.symbol, *kind) == want
            }
            _ => false,
        }
    }

    fn binding_is_module(&self, binding: &Binding) -> bool {
        binding
            .symbol
            .and_then(|sym| self.g.env.symbols.symbol(sym))
            .is_some_and(|symbol| symbol.kind == SymbolKind::Module)
    }

    fn module_as_value_error(&self, name: &str) -> BindError {
        BindError::ExpectedVariableOrProcedureNotModule {
            name: name.to_string(),
        }
    }

    /// Member resolution against a typed receiver (`recv.name`).
    fn resolve_member(
        &self,
        recv: &VarTypeRef,
        name: &str,
        want: Option<oxvba_bundle::ProjectMemberKind>,
    ) -> Option<Binding> {
        self.g
            .env
            .resolve_member_from_scope(self.info.proc_scope, recv, name, want)
    }

    fn resolve_default_member(&self, recv: &VarTypeRef) -> Option<Binding> {
        self.g
            .env
            .resolve_default_member_from_scope(self.info.proc_scope, recv)
    }

    fn resolve_default_member_kind(
        &self,
        recv: &VarTypeRef,
        want: Option<oxvba_bundle::ProjectMemberKind>,
    ) -> Option<Binding> {
        self.g
            .env
            .resolve_default_member_kind_from_scope(self.info.proc_scope, recv, want)
    }

    /// The value of `Me` inside a class member — a `Load` of the implicit `Me`
    /// slot (synthetic parameter 0). `None` outside a class member.
    pub(crate) fn me_value(&self) -> Option<CoreValue> {
        self.info
            .me_local
            .map(|l| CoreValue::Load(CorePlace::Local(l)))
    }

    /// The declared type of a resolved symbol (Variant if it has no declared type).
    fn symbol_type(&self, sym: SymbolId) -> VarTypeRef {
        let ty = match self.g.env.symbols.symbol(sym).map(|s| &s.imp) {
            Some(SymbolImpl::DeclaredType(t)) => t.clone(),
            _ => VarTypeRef::Variant,
        };
        self.g.resolve_udt_type(ty)
    }

    /// The place + type for a resolved variable symbol: a local/param slot, a
    /// global slot, or — inside a class member — a per-instance field / WithEvents
    /// binding reached through `Me`.
    fn place_for_symbol(&self, sym: SymbolId) -> Option<(CorePlace, VarTypeRef)> {
        if let Some(&lid) = self.info.local_of.get(&sym) {
            return Some((CorePlace::Local(lid), self.symbol_type(sym)));
        }
        if let Some(&gid) = self.g.ids.global_of.get(&sym) {
            return Some((CorePlace::Global(gid), self.symbol_type(sym)));
        }
        if let Some(&field) = self.g.ids.field_token_of.get(&sym) {
            let me = self.me_value()?;
            return Some((
                CorePlace::Field {
                    object: Box::new(me),
                    field,
                },
                self.symbol_type(sym),
            ));
        }
        if let Some(&binding) = self.g.ids.withevents_binding_of.get(&sym) {
            let me = self.me_value()?;
            return Some((
                CorePlace::WithEvents {
                    owner: Box::new(me),
                    binding,
                },
                self.symbol_type(sym),
            ));
        }
        None
    }

    /// VBA without `Option Explicit` creates a procedure-local variable when an
    /// ordinary unresolved variable name is used, typed by the module's Def*
    /// directives or Variant by default. `Option Explicit` turns the same use
    /// into the compile diagnostic "Variable not defined".
    fn implicit_local(&mut self, name: &str) -> Result<(CorePlace, VarTypeRef), BindError> {
        let display = unbracket_identifier(name).to_string();
        if self.has_ambiguous_unqualified_name(&display) {
            return Err(BindError::AmbiguousName { name: display });
        }
        if self.info.option_explicit {
            return Err(BindError::VariableNotDefined {
                name: name.to_string(),
            });
        }
        let folded = fold_identifier(&display);
        if let Some(&local) = self.implicit_local_of.get(&folded) {
            let offset = local.0.checked_sub(self.info.param_count).ok_or_else(|| {
                BindError::Malformed(format!(
                    "implicit local `{display}` points outside procedure locals"
                ))
            })?;
            let ty = self
                .locals
                .get(offset)
                .ok_or_else(|| {
                    BindError::Malformed(format!("implicit local `{display}` has no local slot"))
                })?
                .ty
                .clone();
            Ok((CorePlace::Local(local), ty))
        } else {
            let ty = self
                .info
                .default_types
                .type_for(&display)
                .unwrap_or(VarTypeRef::Variant);
            let local = LocalId(self.info.param_count + self.locals.len());
            self.locals.push(CoreLocal {
                name: display,
                ty: ty.clone(),
                array_element: None,
            });
            self.implicit_local_of.insert(folded, local);
            Ok((CorePlace::Local(local), ty))
        }
    }

    /// `Some(return_local)` if `name` is the enclosing function's name (the
    /// function-result pseudo-variable).
    fn return_target(&self, name: &str) -> Option<LocalId> {
        if self.info.return_local.is_some()
            && fold_identifier(name) == fold_identifier(&self.info.name)
        {
            self.info.return_local
        } else {
            None
        }
    }

    /// Allocate (or reuse) the id for a label name.
    fn label_id(&mut self, name: &str) -> LabelId {
        let key = fold_identifier(name);
        if let Some(id) = self.labels.get(&key) {
            return *id;
        }
        let id = LabelId(self.label_order.len());
        self.labels.insert(key.clone(), id);
        self.label_order.push(key);
        self.label_lines.push(None);
        id
    }

    fn validate_label_refs(&self) -> Result<(), BindError> {
        for (idx, name) in self.label_order.iter().enumerate() {
            let id = LabelId(idx);
            if !self.defined_labels.contains(&id) {
                return Err(BindError::LabelNotDefined { name: name.clone() });
            }
        }
        Ok(())
    }

    fn unresolved(&self, name: &str, context: &str) -> BindError {
        if is_unqualified_name_context(context) && self.has_ambiguous_unqualified_name(name) {
            return BindError::AmbiguousName {
                name: unbracket_identifier(name).to_string(),
            };
        }
        if context == "call statement" {
            return BindError::SubOrFunctionNotDefined {
                name: name.to_string(),
            };
        }
        BindError::Unresolved {
            name: name.to_string(),
            context: context.to_string(),
        }
    }

    fn has_ambiguous_unqualified_name(&self, name: &str) -> bool {
        self.g
            .env
            .has_ambiguous_unqualified_name(unbracket_identifier(name))
    }
}

fn is_unqualified_name_context(context: &str) -> bool {
    matches!(
        context,
        "expression" | "call statement" | "assignment target" | "place" | "AddressOf operand"
    )
}

fn unbracket_identifier(name: &str) -> &str {
    name.strip_prefix('[')
        .and_then(|rest| rest.strip_suffix(']'))
        .unwrap_or(name)
}
