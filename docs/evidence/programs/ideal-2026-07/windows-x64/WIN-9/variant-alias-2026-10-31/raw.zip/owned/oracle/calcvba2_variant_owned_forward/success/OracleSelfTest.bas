Option Explicit
Private Declare PtrSafe Function NativeAlias Lib "C:/Work/DnaCalc/codex-runs/calcvba-2-variant-alias/owned/native_variant_alias.dll" Alias "AliasVariant" (ByRef first As Variant, ByRef second As Variant) As Long

Private Function Forward(ByRef first As Variant, ByRef second As Variant) As Long
    Forward = NativeAlias(first, second)
End Function

Public Function RunProbe() As String
    Dim value As Variant
    Dim result As Long
    Dim savedError As Long
    value = "owned string"
    result = Forward(value, value)
    savedError = Err.LastDllError
    RunProbe = CStr(result) & "|" & TypeName(value) & "|" & CStr(value = 42.5) & "|" & CStr(savedError)
End Function
